# -*- coding: utf-8 -*-
"""Autonomy settings (page/autonomy): validate + persist plugin config."""
from __future__ import annotations


class AutonomyError(Exception):
    def __init__(self, message, status=400):
        self.status = int(status)
        super().__init__(str(message))


def normalize(body) -> dict:
    data = body if isinstance(body, dict) else {}
    enabled = data.get("enabled", None)
    send = data.get("send", None)
    if enabled is not None and not isinstance(enabled, bool):
        raise AutonomyError("enabled must be boolean", 400)
    if send is not None and not isinstance(send, bool):
        raise AutonomyError("send must be boolean", 400)
    threshold = data.get("threshold", None)
    if threshold is not None:
        try:
            threshold = float(threshold)
        except Exception:
            raise AutonomyError("threshold must be number", 400)
        if not (0.0 <= threshold <= 1.0):
            raise AutonomyError("threshold out of range", 400)
    max_chars = data.get("max_chars", None)
    if max_chars is not None:
        try:
            max_chars = int(max_chars)
        except Exception:
            raise AutonomyError("max_chars must be int", 400)
        if not (20 <= max_chars <= 4000):
            raise AutonomyError("max_chars out of range", 400)
    return {"enabled": enabled, "send": send, "threshold": threshold, "max_chars": max_chars}


async def apply(plugin, body) -> dict:
    values = normalize(body)
    updates = {}
    if values["enabled"] is not None:
        updates["proactive_autonomy"] = bool(values["enabled"])
        try: plugin.proactive_autonomy = bool(values["enabled"])
        except Exception: pass
    if values["send"] is not None:
        updates["proactive_send"] = bool(values["send"])
        try: plugin.proactive_send = bool(values["send"])
        except Exception: pass
    if values["threshold"] is not None:
        updates["proactive_autonomy_threshold"] = float(values["threshold"])
    if values["max_chars"] is not None:
        updates["proactive_autonomy_max_chars"] = int(values["max_chars"])
    if updates:
        try:
            await plugin._persist_plugin_config(updates)
        except Exception as error:
            raise AutonomyError("save failed: " + type(error).__name__, 500)
    cfg = getattr(plugin, "config", None) or {}
    return {"ok": True, "values": {
        "enabled": bool(getattr(plugin, "proactive_autonomy", cfg.get("proactive_autonomy", False))),
        "send": bool(getattr(plugin, "proactive_send", cfg.get("proactive_send", False))),
        "threshold": float(cfg.get("proactive_autonomy_threshold", 0.6) or 0.6),
        "max_chars": int(cfg.get("proactive_autonomy_max_chars", 120) or 120),
    }}
