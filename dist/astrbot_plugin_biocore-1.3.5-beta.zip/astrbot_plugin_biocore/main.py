# -*- coding: utf-8 -*-
"""AstrBot BioCore plugin: a standalone biological emotion layer.

Independent copy. It does not import the Desktop companion project.
First run: read the current AstrBot persona, compile it once with the current
provider into a numeric profile, store it under this plugin's data dir.
Then on every LLM request: append a compact intent, on response: feedback.

Noise -> autonomy boundary (task-15): proactive_autonomy/proactive_send default
false. When off, readiness is not computed, no background task starts, no message
is sent, and the legacy noise/state trajectory is unchanged. All readiness math
lives in the L1 BioCore (autonomy_state); the plugin only feeds raw module deltas
and reads the resulting state for the command/UI. Group chats never trigger.

Task-35/36 wiring (2026-10-27): proposal-only hints (repair/empathy/pragmatics/
humor/tom/impression/diary/narrative) are consumed through ONE deterministic
[BC] hint line (interpretation.proposal_hint_block) only when their per-function
switch is ON; multihop recall (memory_chain_multihop), refusal brevity
(refusal_brevity_enabled), reply consistency (reply_consistency_enabled) and the
autonomy-loop workspace token are opt-in/default-OFF. LLM failure/fallback
telemetry and provider token usage are read-only projections.
Streaming limitation: this AstrBot build exposes no partial/streaming callback
to plugins (no on_streaming filter), so BioCore cannot consume chunked partial
replies; it only post-processes the final completion and does not fake streaming.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import os
import shutil
import asyncio
import base64
import io
import http.client
import socket
import ssl
import subprocess
import time
import types
import urllib.request
import zipfile
from collections import OrderedDict
from pathlib import Path
from urllib.parse import urlparse

from astrbot.api import logger
from astrbot.api.event import filter, AstrMessageEvent, MessageChain, MessageEventResult
from astrbot.api.message_components import Image, Plain, Reply, Record
from astrbot.api.provider import ProviderRequest, LLMResponse
from astrbot.api.star import Context, Star, register

try:
    from . import interpretation
except Exception:
    import interpretation

try:
    from . import memory_meta
except Exception:
    import memory_meta

try:
    from . import relationship_meta
except Exception:
    import relationship_meta
try:
    from . import homeostasis
except Exception:
    import homeostasis

try:
    from .biocore_model.core_bridge import CoreBridge
except Exception:
    try:
        from biocore_model.core_bridge import CoreBridge
    except Exception:  # pragma: no cover - bridge optional
        CoreBridge = None

try:
    from .biocore_model import render as _bc_render
    from .biocore_model import services as _bc_services
except Exception:
    try:
        from biocore_model import render as _bc_render
        from biocore_model import services as _bc_services
    except Exception:  # pragma: no cover - package ships with the plugin
        _bc_render = None
        _bc_services = None

_SERVICES = getattr(_bc_services, "SERVICES", None) if _bc_services is not None else None

def _sanitize_output(text) -> str:
    """Final exit guard (Phase 3): idempotent, never returns raw artefacts."""
    try:
        from biocore_model import sanitize as _san
        return _san.clean(text)
    except Exception:
        return str(text or "")


try:
    from biocore_memory import MemoryEngine, MemoryEvent
except Exception:  # pragma: no cover - package always ships
    try:
        from .biocore_memory import MemoryEngine, MemoryEvent
    except Exception:
        MemoryEngine = None
        MemoryEvent = None


PLUGIN_DIR = Path(__file__).resolve().parent
_LEGACY_DATA_DIR = PLUGIN_DIR / "data"
_BASE_DATA_DIR = PLUGIN_DIR.parents[1] if len(PLUGIN_DIR.parents) > 1 else PLUGIN_DIR
_PERSIST_DATA_DIR = _BASE_DATA_DIR / "plugin_data" / "astrbot_plugin_biocore"
_OLD_PERSIST_DATA_DIR = (_BASE_DATA_DIR / "plugin_data"
                         / "astrbot_plugin_biocore_standalone")


def _migrate_plugin_data_dir(old_dir: Path, new_dir: Path) -> bool:
    """First-run migration: copy old plugin_data dir to the new name.

    The old directory is KEPT as a backup; returns True only when a migration
    actually ran.
    """
    try:
        if old_dir.exists() and not new_dir.exists():
            new_dir.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(old_dir, new_dir)
            logger.warning("[biocore] data dir migrated: %s -> %s (old kept as backup)",
                           old_dir, new_dir)
            return True
    except Exception as exc:
        logger.warning("[biocore] data dir migration failed: %s", exc)
    return False


def _init_data_dir() -> Path:
    target = Path(os.getenv("BIOCORE_DATA_DIR", str(_PERSIST_DATA_DIR)))
    if not os.getenv("BIOCORE_DATA_DIR"):
        _migrate_plugin_data_dir(_OLD_PERSIST_DATA_DIR, _PERSIST_DATA_DIR)
    target.mkdir(parents=True, exist_ok=True)
    try:
        if _LEGACY_DATA_DIR.exists() and target.resolve() != _LEGACY_DATA_DIR.resolve():
            for src in _LEGACY_DATA_DIR.rglob("*"):
                if not src.is_file():
                    continue
                rel = src.relative_to(_LEGACY_DATA_DIR)
                dst = target / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                if not dst.exists():
                    shutil.copy2(src, dst)
    except Exception:
        pass
    return target


DATA_DIR = _init_data_dir()
PROFILE_PATH = DATA_DIR / "persona_profile.json"
API_CONFIG_PATH = DATA_DIR / "api_config.json"
STATE_DIR = DATA_DIR / "states"
MEMORY_DIR = DATA_DIR / "memory"
# Local image service paths/port are configured through _conf_schema.json.
# There are no machine-specific fallback paths baked into the plugin.
IMAGE_CACHE_PATH = DATA_DIR / "image_cache.json"
EVENT_ARCHIVE_DIR = DATA_DIR / "archives"
EVENT_SESSION_DIR = EVENT_ARCHIVE_DIR / "sessions"
EVENT_ARCHIVE_PATH = EVENT_ARCHIVE_DIR / "events.jsonl"
def canonical_session_key(raw) -> str:
    """Canonical session identity: platform:Type:id (colon form).

    Event archive keys use colons ("default:FriendMessage:123"), memory file
    stems use underscores ("default_FriendMessage_123"); both must compare
    equal for dedupe/dropdown unions (task-55/task-56). Mixed separators
    ("default:GroupMessage_664") and platform prefixes with underscores are
    accepted; ids are kept verbatim.
    """
    text = str(raw or "").strip()
    if not text:
        return ""
    match = re.search(
        r"(FriendMessage|GroupMessage|GuildMessage|TempMessage|OtherMessage)",
        text)
    if match:
        platform = text[:match.start()].strip(":_") or "default"
        ident = text[match.end():].strip(":_")
        return platform + ":" + match.group(1) + ":" + ident
    return text.replace("_", ":")


def event_effective_time(record) -> float:
    """Best-effort real event time for duplicate detection (task-56).

    A re-archived event may carry the archive time in ``ts`` while its
    ``time_span`` still points at the original conversation. Dedupe must
    compare the real event time, not the archival moment, or a re-archive
    days later looks like a different event.
    """
    if not isinstance(record, dict):
        return 0.0
    try:
        span = record.get("time_span")
        if isinstance(span, dict):
            for key in ("end_ts", "start_ts"):
                try:
                    value = float(span.get(key) or 0)
                except Exception:
                    value = 0.0
                if value > 0:
                    return value
        return float(record.get("ts", 0) or 0)
    except Exception:
        return 0.0


EVENT_SUMMARY_ACTIONS = ("regenerate", "update")
MEMORY_POINT_FEEDBACK_ACTIONS = ("important", "unimportant", "edit_label", "restore", "reevaluate")


def savings_overrides(base) -> dict:
    """task-37: optional 省钱模式 preset over effective caps (default OFF).

    Pure function so the preset can be eval-tested without building a plugin.
    It never changes accuracy-first defaults unless the user opts in.
    """
    out = dict(base or {})
    out["bc_budget_chars"] = min(int(out.get("bc_budget_chars", 700) or 700), 300)
    out["memory_recall_budget_enabled"] = True
    out["recall_top_k"] = min(int(out.get("recall_top_k", 3) or 3), 3)
    out["recall_single_chars"] = min(int(out.get("recall_single_chars", 100) or 100), 100)
    out["sentence_dedup_enabled"] = True
    out["bc_hints_enabled"] = False
    return out
EVENT_SUMMARY_HARD_MAX = 20000
EVENT_SUMMARY_SMALL_MAX = 80
EVENT_SUMMARY_HISTORY_MAX = 20
USER_DIR = DATA_DIR / "users"
SELF_MODEL_PATH = DATA_DIR / "self_model.json"
INSIGHT_ARCHIVE_PATH = EVENT_ARCHIVE_DIR / "insights.jsonl"
# M3/M4 embedding infrastructure (registered in
# docs/BIOCORE-ENGINEERING-APPROX-v1.md, "C-S1/C-S2" table): the cache key and
# the request payload share ONE truncation, the cache is a bounded process-local
# LRU, and a slow provider degrades to "no embedding" at a configurable timeout
# (embedding_timeout_ms, default 1500 ms) instead of blocking the reply loop.
# 300 ms is only appropriate once caller-side latency p95 is measured <200 ms.
EMBED_TEXT_MAX_CHARS = 2000
EMBED_CACHE_MAX = 512
EMBED_TIMEOUT_MS_DEFAULT = 1500
EMBED_TIMEOUT_S = EMBED_TIMEOUT_MS_DEFAULT / 1000.0  # seconds, legacy convenience
EMBED_CACHE = OrderedDict()
# C-S1 sentence dedup: deterministic char-bigram Jaccard threshold. The LIT's
# embedding-0.90 path and quote/code-block whitelist are NOT implemented (M5);
# this constant is the only live dedup threshold.
SENTENCE_DEDUP_THRESHOLD = 0.92

# Memory doc schema version: bumped when entry fields/migrations change.
# Old docs are upgraded lazily on load (additive defaults only).
MEMORY_SCHEMA_VERSION = 2

DEFAULT_PROFILE = {
    "O": 0.62, "C": 0.55, "E": 0.44, "A": 0.42, "N": 0.40,
    "stress_reactivity": 0.45, "recovery_rate": 0.62,
    "social_baseline": 0.44, "energy_baseline": 0.55,
    "curiosity_baseline": 0.60, "safety_baseline": 0.55,
    "da_baseline": 0.55, "oa_baseline": 0.40, "ht_baseline": 0.35,
    "autonomy_gain": 1.0, "contagion_gain": 0.10, "baseline_v": 0.05, "baseline_a": 0.40,
}

# G3: one-shot bounded seed of core.trust from the persisted user record
# (cold start / context rebuild only; never every turn, to avoid oscillation).
TRUST_SEED_WEIGHT = 0.2
TRUST_SEED_MAX_DELTA = 0.05

# D5: stable default shape for the page-status memory-trace projection.
DEFAULT_MEMORY_TRACE = {"count": 0, "valence": 0.0, "stress_delta": 0.0, "entry_ids": []}

# G15: reflection-tree nodes older than this are hidden on read (soft forget).
REFLECTION_TREE_TTL_DAYS = 90.0

# Task-15: noise -> autonomy (L1 computes; default OFF, private chat only).
NOISE_CLAMP = 0.30
AUTONOMY_ENTER = 0.72  # hysteresis: enter ready
AUTONOMY_EXIT = 0.60  # hysteresis: stay ready until below this
AUTONOMY_WEIGHTS = {
    "chaos": 0.22, "echo": 0.16, "stress_load": 0.18,
    "drive_dev": 0.16, "distrust": 0.14, "distance": 0.14,
}
AUTONOMY_THRESHOLD_MIN = 0.55
AUTONOMY_THRESHOLD_MAX = 0.90
AUTONOMY_MAX_CHARS_MIN = 60
AUTONOMY_MAX_CHARS_MAX = 240
AUTONOMY_COOLDOWN_SECONDS = 30 * 60
AUTONOMY_DAILY_CAP = 3
AUTONOMY_QUIET_START_HOUR = 0
AUTONOMY_QUIET_END_HOUR = 8
AUTONOMY_TICK_SECONDS = 300  # P0-1: autonomous generator interval (>=5min)

# Task-28: minimal autonomy loop (default OFF, private-only, token-only).
# Deterministic arbiter INSPIRED BY (not an implementation of) the papers below;
# it is NOT a global-workspace/consciousness implementation.
#   competition: Desimone & Duncan 1995 10.1146/annurev.ne.18.030195.001205;
#                Itti & Koch 2001 10.1038/35058500; Itti et al. 1998 10.1109/34.730558 (WTA+IOR)
#   goal gradient: Hull 1932 10.1037/h0072640; Kivetz 2006 10.1509/jmkr.43.1.39;
#                Koo & Fishbach 2010 10.1037/a0019443
#   delay discount: Mazur 1987 (book chapter, no DOI) + Green & Myerson 2004
#                10.1037/0033-2909.130.5.769
#   effort cost: Shenhav 2013 10.1016/j.neuron.2013.07.007; Kool & Botvinick 2014
#                10.1037/a0031048; Westbrook & Braver 2013 10.1017/s0140525x13001179
#   broadcast: Baars 1988 (book, no DOI); Dehaene & Naccache 2001
#                10.1016/S0010-0277(00)00123-2; Dehaene et al. 1998 10.1073/pnas.95.24.14529;
#                Mashour et al. 2020 10.1016/j.neuron.2020.01.026
AUTONOMY_LOOP_MODES = ("reach_out", "explore", "engage", "wait", "share", "withdraw")
AUTONOMY_LOOP_WEIGHTS = {"novelty": 0.20, "goal": 0.25, "relation": 0.20,
                         "affect": 0.20, "noise": 0.15}
AUTONOMY_LOOP_CANDIDATE_MAX = 6
AUTONOMY_LOOP_THETA_MIN = 0.35
AUTONOMY_LOOP_THETA_MAX = 0.55
AUTONOMY_LOOP_THETA_IG = 0.45
AUTONOMY_LOOP_MARGIN_MIN = 0.05
AUTONOMY_LOOP_MARGIN_MAX = 0.15
AUTONOMY_LOOP_MARGIN = 0.08
AUTONOMY_LOOP_K_MIN = 0.001
AUTONOMY_LOOP_K_MAX = 0.10
AUTONOMY_LOOP_K_DELAY = 0.02       # hyperbolic discount k per minute
AUTONOMY_LOOP_IOR_MIN = 300.0
AUTONOMY_LOOP_IOR_MAX = 1800.0
AUTONOMY_LOOP_IOR_SECONDS = 600.0  # return-inhibition recovery tau
AUTONOMY_LOOP_REFRACTORY_SECONDS = 60.0
AUTONOMY_LOOP_C0 = 0.05
AUTONOMY_LOOP_C1 = 0.20
AUTONOMY_LOOP_C2 = 0.15
AUTONOMY_LOOP_DEBT_STEP = 0.15
AUTONOMY_LOOP_DEBT_RECOVERY = 0.02
AUTONOMY_LOOP_DEBT_MAX = 0.60
AUTONOMY_LOOP_VALUE_MIN = -0.5
AUTONOMY_LOOP_VALUE_MAX = 1.0
AUTONOMY_LOOP_EMA_KEEP = 0.7
AUTONOMY_LOOP_WORKSPACE_MAX = 16
AUTONOMY_LOOP_EFFORT = {"reach_out": 0.5, "explore": 0.4, "engage": 0.6,
                        "share": 0.3, "withdraw": 0.3, "wait": 0.05}

# Task-20 batch3 L1 learning (Daw 2011 10.1016/j.neuron.2011.02.027;
# Nassar 2010 10.1523/JNEUROSCI.0822-10.2010; Wixted 1991).
LEARNING_Q_ALPHA = 0.20
LEARNING_Q_WEIGHT = 0.05
LEARNING_RETENTION_MODELS = ("power_law", "multi_scale", "single")

# Per-function LLM routing: each feature has its own enabled switch and a
# provider choice ("follow_llm" = AstrBot main chat model, or a provider_id).
# Defaults: only the two summary functions are enabled; everything else is
# opt-in. This replaces the single llm_only_reply_summary master switch while
# keeping it readable for legacy migration.
LLM_FUNCTIONS = (
    "persona_compile",
    "event_summary",
    "event_ranking",
    "insight",
    "memory_summary",
    "image_caption",
    # L-T01..L-T12: proposal-only LLM functions, all OFF by default. Each one
    # is routed through _provider_for and its prompt/parser lives in
    # interpretation.py; model output never writes biological state directly.
    "relationship_impression",
    "repair_hint",
    "empathy_hint",
    "pragmatics_hint",
    "tom_probe",
    "diary",
    "relationship_narrative",
    "humor_hint",
)
LLM_FUNCTION_DEFAULTS = {
    "persona_compile": False,
    "event_summary": True,
    "event_ranking": True,
    "insight": False,
    "memory_summary": True,
    "image_caption": False,
    "relationship_impression": False,
    "repair_hint": False,
    "empathy_hint": False,
    "pragmatics_hint": False,
    "tom_probe": False,
    "diary": False,
    "relationship_narrative": False,
    "humor_hint": False,
}
INSIGHT_MIN_NEW_EVENTS = 3
INSIGHT_COOLDOWN_SECONDS = 60 * 60
INSIGHT_FALLBACK_HOURS = 24

LLM_FUNCTION_ALIASES = {
    "persona": "persona_compile",
    "ranking": "event_ranking",
    "caption": "image_caption",
    "summary": "event_summary",
    "impression": "relationship_impression",
    "repair": "repair_hint",
    "empathy": "empathy_hint",
    "pragmatics": "pragmatics_hint",
    "tom": "tom_probe",
    "narrative": "relationship_narrative",
    "humor": "humor_hint",
}

# L-T01..L-T12 cooldowns (seconds); all functions stay OFF by default.
LLM_BACKGROUND_KINDS = {"event_summary", "event_ranking", "memory_summary",
                       "relationship_impression", "diary", "relationship_narrative",
                       "persona_compile", "insight", "tom_probe", "pragmatics_hint",
                       "humor_hint"}
EMBED_DIM_MISMATCH = 0
LLM_V2_COOLDOWNS = {
    "relationship_impression": 3600,
    "repair_hint": 900,
    "empathy_hint": 900,
    "pragmatics_hint": 900,
    "tom_probe": 600,
    "diary": 72000,
    "relationship_narrative": 86400,
    "humor_hint": 900,
}

# ACT-R retrieval constants (Anderson & Reder 1999; partial matching per
# Anderson 1994). Keeping them in one named place makes scoring tunable.
ACT_R_DECAY = 0.5
RETRIEVAL_THRESHOLD = 0.25
PARTIAL_MATCH_THRESHOLD = 0.35

# A4 continuity opener: inject "last talk" only when the user returns after a
# break, so the same-session turns and first-ever turns stay untouched.
A4_CONTINUITY_GAP_SECONDS = 600.0
A4_CONTINUITY_MAX_LOOPS = 2

# Zacks et al. (2007) event segmentation: a boundary is predicted by elapsed
# time and by the content change since the previous event in the same session.
EVENT_BOUNDARY_WINDOW_SECONDS = 1800.0
EVENT_BOUNDARY_TIME_WEIGHT = 0.62
EVENT_BOUNDARY_TEXT_WEIGHT = 0.38
EVENT_BOUNDARY_PARENT_THRESHOLD = 0.5

# Gross process model: cost paid by each regulation strategy (0..1 scale,
# distraction pays the highest bill because it leaves the concern unaddressed).
REGULATION_COST = {
    "seek_comfort": 0.003,
    "reappraise": 0.002,
    "suppress": 0.010,
    "avoid": 0.004,
    "express": 0.002,
    "distraction": 0.006,
    # Batch4 B2: affect labeling is the 7th, lowest-cost strategy.
    "label_emotion": 0.001,
}

# Batch4 A1: sensitization (dual of habituation): strong negative stimuli
# repeated within the decay window give a bounded gain, half-life 24h.
SENSITIZATION_STRONG_NEG_DV = -0.12
SENSITIZATION_STEP = 0.15
SENSITIZATION_MAX = 1.25
SENSITIZATION_HALF_LIFE_HOURS = 24.0
SENSITIZATION_HISTORY_MAX = 12
SENSITIZATION_HISTORY_MAX_AGE = 2 * 86400.0

# Batch4 B2: affect-labeling trigger thresholds (deterministic).
AFFECT_LABEL_MIN_TOP_P = 0.60
AFFECT_LABEL_MIN_AROUSAL = 0.60
# Low-cost strategy should not be picked every tick; deterministic cooldown.
AFFECT_LABEL_COOLDOWN_SECONDS = 600

# Batch4 B4: contextual recovery-speed multiplier bounds.
RECOVERY_CONTEXT_MIN = 0.8
RECOVERY_CONTEXT_MAX = 1.2

# G4: regulation-strategy statistics carry a recency weight so evidence from a
# strategy that has not been used for a long time counts less when choosing.
REGULATION_STATS_HALF_LIFE_DAYS = 10.0

# Mem0 UPDATE matching: an explicit correction ("改成/改为/其实是/更正")
# only updates a memory whose semantic similarity passes this floor; the
# exact-duplicate threshold (0.93) alone is too strict for corrections.
MEMORY_UPDATE_MATCH_THRESHOLD = 0.55

# Event-key identity: normalized keys within this window and above this
# similarity are treated as the same archived event (duplicates are merged).
EVENT_KEY_SIM_THRESHOLD = 0.82
EVENT_DUP_WINDOW_SECONDS = 21600.0
# One-time canonical cleanup compares the *real* event time (time_span) and may
# need to span the archival gap between ":"/"_" key generations (task-56).
EVENT_DEDUPE_CLEANUP_WINDOW = 7 * 86400.0

# Cowen & Keltner (2017) prototype space: which EMOTION_SPECTRUM anchors a
# basic emotion label may calibrate from this core's own state history.
SPECTRUM_FAMILY = {
    "joy": ("joy", "amusement", "contentment", "excitement", "pride", "adoration", "admiration"),
    "sadness": ("disappointment", "empathic_pain", "nostalgia", "guilt"),
    "anger": ("anger", "contempt", "disgust"),
    "fear": ("fear", "anxiety", "horror"),
    "loneliness": ("empathic_pain", "disappointment", "nostalgia"),
}

LEX = {
    "sadness": ("难过", "伤心", "委屈", "哭", "失望", "累", "撑不住"),
    "anger": ("生气", "烦", "气死", "骂", "傻逼", "滚", "恶心", "废物", "垃圾", "讨厌", "闭嘴", "没用", "蠢", "去死"),
    "fear": ("怕", "焦虑", "紧张", "担心", "失眠", "慌"),
    "joy": ("开心", "高兴", "喜欢", "好耶", "笑死", "可爱", "谢谢"),
    "loneliness": ("孤独", "一个人", "没人", "空虚"),
}


LEX["sadness"] += ("难受", "委屈", "失落", "低落")
LEX["anger"] += ("烦", "别烦", "闭嘴", "滚", "讨厌", "气人")
LEX["fear"] += ("慌", "不安", "怕", "紧张")
LEX["loneliness"] += ("丢下", "被丢下", "冷落", "忽视", "没人理", "不理我", "抛弃", "一个人", "孤单")


def _sha256(text: str) -> str:
    import hashlib
    return hashlib.sha256(str(text or "").encode("utf-8")).hexdigest()[:32]


def _clip(x, lo=-1.0, hi=1.0):
    try:
        return max(lo, min(hi, float(x)))
    except Exception:
        return lo


def _memory_entry_id_of(entry) -> str:
    """Stable per-entry id shared by the memory API and the dashboard index."""
    if not isinstance(entry, dict):
        return ""
    eid = str(entry.get("id") or "").strip()
    if eid:
        return eid
    text = str(entry.get("text") or "").strip()
    return _sha256(text[:300])[:12] if text else ""


def _pin_ts_of(entry):
    """task-44 read-only pin timestamp (None when not pinned/unknown)."""
    if not isinstance(entry, dict) or not memory_meta.is_pinned(entry):
        return None
    try:
        ts = float(entry.get("pin_ts") or 0.0)
    except Exception:
        ts = 0.0
    return round(ts, 3) if ts > 0 else None


def _memory_index_rows(memory_dir: Path, *, max_sessions: int = 50,
                       max_entries: int = 200, max_tombstones: int = 20) -> list:
    """Read-only, bounded memory index consumed by the dashboard.

    Only contract fields are exposed. Deleted entries are omitted from the
    entries list and surfaced through tombstones (soft deletes keep a
    tombstone matching the hard-delete shape). Old entries without the new
    metadata keep neutral values instead of failing.
    """
    sessions = []
    try:
        files = sorted(Path(memory_dir).glob("*.json"),
                       key=lambda p: p.stat().st_mtime, reverse=True)
    except Exception:
        files = []
    for path in files[:max(1, int(max_sessions))]:
        try:
            doc = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(doc, dict):
            continue
        entries = doc.get("entries") if isinstance(doc.get("entries"), list) else []
        rows = []
        soft_deleted = []
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            if entry.get("deleted"):
                soft_deleted.append(entry)
                continue
            if len(rows) >= max_entries:
                continue
            try:
                ts = round(float(entry.get("ts", 0) or 0), 3)
            except Exception:
                ts = 0.0
            try:
                importance = round(float(entry.get("importance", 0.5) or 0.5), 3)
            except Exception:
                importance = 0.5
            confidence = entry.get("memory_confidence")
            try:
                confidence = round(float(confidence), 4) if confidence is not None else None
            except Exception:
                confidence = None
            destination = entry.get("destination")
            provenance = entry.get("provenance")
            rows.append({
                "id": _memory_entry_id_of(entry),
                "text": str(entry.get("text") or "")[:400],
                "role": str(entry.get("role") or ""),
                "ts": ts,
                "importance": importance,
                # S1: read-only effective values (G7/G8) for the dashboard.
                "effective_importance": memory_meta.effective_importance(entry),
                "effective_assoc": memory_meta.decayed_assoc(entry),
                "last_recall": round(float(entry.get("last_recall", 0) or 0), 3),
                "hits": int(entry.get("hits", 0) or 0),
                "memory_source": str(entry.get("memory_source") or "direct"),
                "memory_confidence": confidence,
                "legacy": not bool(entry.get("memory_source")),
                "memory_tier": str(entry.get("memory_tier") or ""),
                "conflict": bool(entry.get("conflict")),
                "last_write_op": str(entry.get("last_write_op") or ""),
                "previous_versions": [str(v)[:400] for v in (entry.get("previous_versions") or [])][-8:],
                "summarized": bool(entry.get("summarized")),
                "destination": dict(destination) if isinstance(destination, dict) else None,
                "provenance": dict(provenance) if isinstance(provenance, dict) else None,
                # Read-only extras for the orb memory-ball layer.
                "encoding_emotion": str(entry.get("encoding_emotion") or ""),
                "encoding_emotion_secondary": str(entry.get("encoding_emotion_secondary") or ""),
                "last_used": round(float(entry.get("last_used", 0) or 0), 3),
                "scope": str(entry.get("scope") or ""),
                "poison_risk": bool(entry.get("poison_risk")),
                "links": len(entry.get("links") or []),
                "self_defining": bool(entry.get("self_defining")),
                "verification": str((entry.get("verification") or {}).get("status")
                                    or memory_meta.verify_entry(entry).get("status") or ""),
                # task-44 backend gap: expose pin state read-only (no semantics change).
                "pinned": bool(memory_meta.is_pinned(entry)),
                "pin_ts": _pin_ts_of(entry),
            })
        tombstones = []
        for item in (doc.get("tombstones") or [])[-max_tombstones:]:
            if not isinstance(item, dict):
                continue
            try:
                tomb_ts = round(float(item.get("ts", 0) or 0), 3)
            except Exception:
                tomb_ts = 0.0
            tombstones.append({
                "id": str(item.get("id") or ""),
                "ts": tomb_ts,
                "status": str(item.get("status") or "deleted")[:12],
                "text": "",   # tombstone is redacted: never expose the original text
            })
        for entry in soft_deleted[-max_tombstones:]:
            try:
                tomb_ts = round(float(entry.get("deleted_ts") or entry.get("ts", 0) or 0), 3)
            except Exception:
                tomb_ts = 0.0
            tombstones.append({
                "id": _memory_entry_id_of(entry),
                "ts": tomb_ts,
                "text": str(entry.get("text") or "")[:200],
            })
        sessions.append({
            "session": str(path.stem),
            "entries": rows,
            "tombstones": tombstones[-max_tombstones:],
        })
    return sessions


def _relationship_rows(user_dir: Path, *, max_users: int = 50,
                       max_trajectory: int = 40) -> list:
    """Read-only, bounded relationship index consumed by the dashboard."""
    rows = []
    try:
        files = sorted(Path(user_dir).glob("*.json"),
                       key=lambda p: p.stat().st_mtime, reverse=True)
    except Exception:
        files = []
    for path in files[:max(1, int(max_users))]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(data, dict):
            continue
        try:
            trust = float(data.get("trust", 0.5) or 0.5)
            if not math.isfinite(trust):
                raise ValueError("non-finite trust")
            trust = round(max(0.0, min(1.0, trust)), 4)
        except Exception:
            trust = 0.5
        try:
            interactions = int(data.get("interactions", 0) or 0)
        except Exception:
            interactions = 0
        try:
            last_seen = round(float(data.get("last_seen", 0) or 0), 3)
        except Exception:
            last_seen = 0.0
        rel = data.get("relationship") if isinstance(data.get("relationship"), dict) else {}
        state = rel.get("state") if isinstance(rel.get("state"), dict) else None
        if isinstance(state, dict):
            safe_state = {}
            for _key in ("trust", "closeness", "conflict", "repair", "predictability"):
                try:
                    _value = float(state.get(_key))
                    if not math.isfinite(_value):
                        raise ValueError("non-finite")
                    safe_state[_key] = round(max(0.0, min(1.0, _value)), 4)
                except Exception:
                    safe_state = {}
                    break
            state = safe_state or None
        if not isinstance(state, dict):
            try:
                state = relationship_meta.relationship_state(trust=trust)
            except Exception:
                state = {"trust": trust, "closeness": 0.5, "conflict": 0.5,
                         "repair": 0.0, "predictability": 0.5}
        trajectory = rel.get("trajectory") if isinstance(rel.get("trajectory"), list) else []
        belief = data.get("belief_state") if isinstance(data.get("belief_state"), dict) else {}
        rows.append({
            "sender_id": str(data.get("sender_id") or ""),
            "sender_name": str(data.get("sender_name") or ""),
            "interactions": interactions,
            "trust": trust,
            "last_seen": last_seen,
            # task-55: session keys from the user file feed the dashboard
            # session dropdown union (memory + events + relations + live).
            "sessions": [str(x) for x in (data.get("sessions") or [])][:20],
            "relationship": {
                "state": {key: state.get(key) for key in
                          ("trust", "closeness", "conflict", "repair", "predictability")},
                "trajectory": [dict(x) for x in trajectory[-max_trajectory:] if isinstance(x, dict)],
                "transactive_map": rel.get("transactive_map") if isinstance(rel.get("transactive_map"), dict) else {},
                "destination_map": rel.get("destination_map") if isinstance(rel.get("destination_map"), dict) else {},
                "repair_state": rel.get("repair_state") if isinstance(rel.get("repair_state"), dict) else {},
                "absence": rel.get("absence") if isinstance(rel.get("absence"), dict) else {},
                "calibration": rel.get("calibration") if isinstance(rel.get("calibration"), dict) else {},
                "social_world": [dict(x) for x in (rel.get("social_world") or [])[:20] if isinstance(x, dict)],
                "attachment": rel.get("attachment") if isinstance(rel.get("attachment"), dict) else {},
                "milestones": [dict(x) for x in (rel.get("milestones") or [])[:10] if isinstance(x, dict)],
                "we_memory": [dict(x) for x in (rel.get("we_memory") or [])[:20] if isinstance(x, dict)],
                "commitment": round(float(rel.get("commitment", 0.0) or 0.0), 4),
                "investment": round(float(rel.get("investment", 0.0) or 0.0), 4),
                "annotations": [dict(x) for x in (rel.get("annotations") or [])[:10]
                                if isinstance(x, dict)],
            },
            "belief_state": {
                "beliefs": [str(x)[:60] for x in (belief.get("beliefs") or [])[:3] if str(x)],
                "desires": [str(x)[:60] for x in (belief.get("desires") or [])[:3] if str(x)],
                "intentions": [str(x)[:60] for x in (belief.get("intentions") or [])[:3] if str(x)],
                "confidence": round(float(belief.get("confidence", 0.0) or 0.0), 3),
            },
        })
    return rows


PLUTCHIK_WHEEL = {
    "joy": ("joy", "trust", "anticipation", "surprise"),
    "trust": ("trust", "joy", "acceptance", "admiration"),
    "fear": ("fear", "surprise", "apprehension", "awe"),
    "surprise": ("surprise", "fear", "distraction", "amazement"),
    "sadness": ("sadness", "disgust", "pensiveness", "remorse"),
    "disgust": ("disgust", "sadness", "boredom", "loathing"),
    "anger": ("anger", "anticipation", "annoyance", "rage"),
    "anticipation": ("anticipation", "anger", "interest", "vigilance"),
}

EMOTION_SPECTRUM = [
    ("admiration", "钦佩", 0.40, 0.25, 0.45, 0.55),
    ("adoration", "爱慕", 0.80, 0.45, 0.40, 0.90),
    ("aesthetic", "审美欣赏", 0.50, 0.30, 0.45, 0.60),
    ("amusement", "好笑", 0.80, 0.60, 0.55, 0.60),
    ("anger", "生气", -0.60, 0.80, 0.85, 0.30),
    ("anxiety", "焦虑", -0.40, 0.80, 0.20, 0.30),
    ("awe", "敬畏", 0.60, 0.70, 0.20, 0.60),
    ("awkwardness", "尴尬", -0.20, 0.50, 0.10, 0.40),
    ("boredom", "无聊", -0.40, 0.10, 0.40, 0.40),
    ("calmness", "平静", 0.10, 0.20, 0.50, 0.50),
    ("confusion", "困惑", -0.10, 0.50, 0.40, 0.50),
    ("contempt", "轻蔑", -0.50, 0.40, 0.90, 0.30),
    ("contentment", "满足", 0.60, 0.20, 0.60, 0.70),
    ("desire", "欲望", 0.60, 0.70, 0.60, 0.60),
    ("disappointment", "失望", -0.50, 0.30, 0.40, 0.50),
    ("disgust", "厌恶", -0.60, 0.40, 0.70, 0.40),
    ("empathic_pain", "共情痛苦", -0.40, 0.40, 0.20, 0.70),
    ("entrancement", "入迷", 0.50, 0.50, 0.40, 0.60),
    ("envy", "嫉妒", -0.40, 0.60, 0.30, 0.40),
    ("excitement", "兴奋", 0.70, 0.90, 0.50, 0.60),
    ("fear", "害怕", -0.50, 0.80, 0.20, 0.40),
    ("guilt", "内疚", -0.50, 0.40, 0.30, 0.50),
    ("horror", "恐惧", -0.80, 0.90, 0.20, 0.40),
    ("interest", "兴趣", 0.40, 0.50, 0.50, 0.60),
    ("joy", "快乐", 0.80, 0.60, 0.60, 0.70),
    ("nostalgia", "怀念", 0.30, 0.30, 0.40, 0.60),
    ("pride", "自豪", 0.60, 0.50, 0.90, 0.60),
]

def circadian_alertness(hour: Any) -> float:
    """Deterministic local-hour alertness (0..1); no LLM/network."""
    try:
        h = float(hour) % 24.0
    except Exception:
        h = 12.0
    anchors = ((0.0, 0.25), (3.0, 0.20), (6.0, 0.35), (8.0, 0.85),
               (10.0, 0.95), (13.0, 0.78), (15.0, 0.72), (17.0, 0.88),
               (20.0, 0.70), (23.0, 0.45), (24.0, 0.25))
    for i in range(1, len(anchors)):
        if h <= anchors[i][0]:
            x0, y0 = anchors[i - 1]
            x1, y1 = anchors[i]
            if x1 <= x0:
                return round(y1, 3)
            return round(y0 + (y1 - y0) * (h - x0) / (x1 - x0), 3)
    return 0.25


class BioCore:
    @staticmethod
    def _word_hit(text: str, word: str) -> bool:
        idx = text.find(word)
        while idx >= 0:
            prefix = text[max(0, idx - 2):idx]
            if not prefix.endswith(("不", "没", "别", "无")):
                return True
            idx = text.find(word, idx + len(word))
        return False

    def feedback_user(self, text: str) -> None:
        t = str(text or "")
        cold_words = ("废物", "垃圾", "讨厌", "滚", "闭嘴", "没用", "蠢", "去死", "别烦", "傻子")
        warm_words = ("谢谢", "喜欢", "陪", "辛苦", "厉害", "可爱", "抱")
        cold = sum(1 for w in cold_words if self._word_hit(t, w))
        warm = sum(1 for w in warm_words if self._word_hit(t, w))
        if cold:
            self.trust = _clip(self.trust - 0.055 * cold, 0, 1)
            self.v = _clip(self.v - 0.035 * cold, -1, 1)
            self.stress = _clip(self.stress + 0.035 * cold, 0, 1)
            self.echo_trace = _clip(self.echo_trace - 0.03 * cold, -1, 1)
        if warm:
            self.trust = _clip(self.trust + 0.012 * warm, 0, 1)
            self.v = _clip(self.v + 0.02 * warm, -1, 1)
            self.stress = _clip(self.stress - 0.01 * warm, 0, 1)

    def __init__(self, profile=None):
        self.profile = dict(profile or DEFAULT_PROFILE)
        self.v = _clip(self.profile.get("baseline_v", 0.05), -1, 1)
        self.a = _clip(self.profile.get("baseline_a", 0.4), 0, 1)
        # Compiled persona profiles use PAD-baseline names (da_baseline /
        # social_baseline); legacy profiles may use baseline_d / baseline_social.
        self.d = _clip(self.profile.get("baseline_d", self.profile.get("da_baseline", 0.55)), -1, 1)
        self.social = _clip(self.profile.get("baseline_social", self.profile.get("social_baseline", 0.55)), 0, 1)
        self.stress = 0.1
        self.energy = _clip(self.profile.get("energy_baseline", 0.55), 0, 1)
        self.trust = _clip(self.profile.get("trust", 0.55), 0, 1)
        self._derive()
        self.ticks = 0
        self.labels = {"emotion": "neutral", "intent": "hold", "expression": "normal",
                       "need": "talk", "energy": "normal", "stress": "calm"}
        self.noise = {"stress": 0.0, "energy": 0.0, "social": 0.0, "attention": 0.0, "valence": 0.0}
        # Task-15: autonomy is opt-in; default OFF is a pure no-op.
        self.autonomy_enabled = False
        self._proactive_autonomy = {"enabled": False}
        # Task-28: minimal autonomy loop. Config owns "enabled"; the loop state
        # dict is created lazily and only persisted while enabled (default OFF
        # leaves the state file byte-identical to 1.2.98).
        self.autonomy_loop_enabled = False
        self.autonomy_loop = None
        self.autonomy_loop_theta_ig = AUTONOMY_LOOP_THETA_IG
        self.autonomy_loop_margin = AUTONOMY_LOOP_MARGIN
        self.autonomy_loop_k_delay = AUTONOMY_LOOP_K_DELAY
        self.autonomy_loop_ior_seconds = AUTONOMY_LOOP_IOR_SECONDS
        self.autonomy_loop_c0 = AUTONOMY_LOOP_C0
        self.autonomy_loop_c1 = AUTONOMY_LOOP_C1
        self.autonomy_loop_c2 = AUTONOMY_LOOP_C2
        self.autonomy_loop_token_only = True
        # task-36: reply consistency is an opt-in read-only projection.
        self.reply_consistency_enabled = False
        self.reply_consistency = None
        # 1.3.1 model-layer flags / read-only projections (set by plugin config).
        self.think_selfcheck_trace_enabled = False
        self.think_selfcheck_hint_enabled = False
        self.soft_bound_enabled = False
        self.soft_bound_k = 0.10
        self.soft_bound_m_frac = 0.08
        self.soft_bound_lam = 0.10
        self.token_budget_enabled = False
        self.token_usage = None
        self.reverse_check = None
        self.thought_note = None
        self.injection_trace = None
        self.path_monitor = None
        self.sycophancy_check = None
        self.sycophancy_check_enabled = False
        self.rumination_suppress = False
        self.temporal_validity_enabled = False
        self.mood_congruence_enabled = False
        self.emotion_gating_enabled = False
        # task-43: L1 "thinking physiology" scalars (read-only state; behaviour
        # effects are separately gated and default OFF).
        self.conflict_ema = 0.0
        self.rumination_ema = 0.0
        self.anchor_weight = 0.25
        self._neg_repeat = 0
        self._last_neg_topic = ""
        self.conflict_gate_enabled = False
        self.rumination_effect_enabled = False
        self.anchor_update_enabled = False
        self.identity_threat_stress_enabled = False
        self.learning_state = None
        self.relationship_dynamics = None
        self.big5_effect = None
        self.expression_chain_enabled = False
        self.relationship_chain_enabled = False
        self.gottman_enabled = False
        self.big5_effect_enabled = False
        self.learning_bandit_enabled = False
        self.learning_relationship_enabled = False
        self.learning_worthiness_enabled = False
        self._noise_seed = 0
        self._noise_accum = {}
        # Task-20: L1 learning state (deterministic, bounded, auditable).
        self.bio_learning = True
        self.retention_model = "single"
        self._learning = {
            "version": 1,
            "params": {"regulation_q": {}, "trust_alpha": 0.30,
                       "learning_rate": LEARNING_Q_ALPHA},
            "last_update": 0.0, "updates_count": 0, "log": [],
        }
        self.echo = 0.0
        self.echo_trace = 0.0
        self.reflection = {"v": 0.0, "a": 0.0, "d": 0.0, "social": 0.0}
        self.momentum = {"v": 0.0, "a": 0.0, "d": 0.0, "social": 0.0}
        self.appraisal = {"novelty": 0.0, "goal_relevance": 0.0, "coping": 0.5, "agency": 0.5}
        self.compound = ""
        self.regulation = "none"
        self.history = []
        # B-T06: exploration/boredom drive (bounded state; not a claim about feelings).
        self.novelty_need = 0.5
        self.boredom = 0.0
        # Batch4: transient bounded states (not persisted): information-gap
        # curiosity proxy and strong-negative sensitization history.
        self.info_gap = 0.0
        self._sensitization_history = []
        # B-T07: autonomy/refusal readiness (bounded state; strategy stays outside).
        self.boundary_pressure = 0.0
        self.refusal_readiness = 0.0
        # B-T09: interpersonal coupling (co-regulation proxy, not "being dragged").
        self.interpersonal = {"other_valence_est": 0.0, "coupling": 0.0, "dampening": 1.0}
        self._metabolic_energy_offset = 0.0
        # Circadian / allostatic paper mechanisms (bounded, no prompt).
        self.circadian_alertness = circadian_alertness(
            time.localtime(time.time()).tm_hour + time.localtime(time.time()).tm_min / 60.0)
        self.allostatic_load = 0.0
        # B-T12: deterministic daily digest base (no narrative text).
        self.daily_digests = []
        self._daily_accum = {"date": "", "n": 0, "v": 0.0, "a": 0.0, "stress": 0.0,
                             "emotions": {}, "ticks": 0}
        self.open_loops = []
        self.stimuli = []
        self.goals = [
            {"key": "relationship", "name": "和重要的人保持亲近", "keywords": ("喜欢", "爱", "陪", "关系", "信任", "靠近", "一起"),
             "horizon": "long", "progress": 0.0, "priority": 0.90, "last_update": 0.0},
            {"key": "autonomy", "name": "不被当成工具", "keywords": ("废物", "命令", "必须", "听话", "工具", "滚", "闭嘴"),
             "horizon": "long", "progress": 0.0, "priority": 0.85, "last_update": 0.0},
            {"key": "competence", "name": "证明自己能做好", "keywords": ("没用", "做不好", "失败", "厉害", "做得好", "能干"),
             "horizon": "long", "progress": 0.0, "priority": 0.60, "last_update": 0.0},
            {"key": "stability", "name": "保持情绪稳定", "keywords": ("平静", "冷静", "慢慢", "不急", "休息"),
             "horizon": "short", "progress": 0.0, "priority": 0.55, "last_update": 0.0},
        ]
        self.goal_focus = ""
        self.goal_scores = {}
        self.goal_context_terms = {
            "relationship": ("喜欢", "陪", "亲近", "信任", "关系", "一起", "在乎", "记得", "承诺", "重要", "对方"),
            "autonomy": ("自由", "命令", "被迫", "工具", "听话", "安排", "关起来", "憋", "自主"),
            "competence": ("做不好", "失败", "没用", "厉害", "能干", "任务", "做好", "证明", "靠谱"),
            "stability": ("平静", "冷静", "休息", "不急", "慢慢", "稳住", "安心", "别怕"),
        }
        self.coping_history = []
        self.event_anchors = []
        self.opponent = {"v": 0.0, "a": 0.0, "d": 0.0, "social": 0.0}
        self.opponent_gain = 0.10
        self.reconsolidation_seconds = 600.0
        self.autobiography = []
        self.regulation_stats = {}
        self.attention = 0.5
        self.meta_emotion = ""
        self.goal_conflict = []
        self.self_timeline = {"past": [], "present": "", "future": []}
        self.reflection_tree = {"roots": [], "count": 0}
        self.sec = {}
        self.core_self = ""
        self.narrative_self = ""
        self._query_embedding = None
        self.emotion_decay_factors = {"anger": 0.55, "fear": 0.70, "joy": 1.15,
                                      "sadness": 1.50, "loneliness": 1.80, "neutral": 1.0}
        self.valence_decay_minutes = 120.0
        self.arousal_decay_minutes = 30.0
        self.social_decay_minutes = 180.0
        self.last_tick = __import__("time").time()
        self.ripple = {"upper": 0.0, "lower": 0.0, "overlap": 0.0, "energy": 0.0}
        self.spiking = {"rate": 0.0, "variance": 0.0, "ei": 0.0}
        self._rng = __import__("random").Random()

    def set_relationship_context(self, relationship=None) -> None:
        """Attach the last per-user relationship record for the slow C6 loop.

        The plugin refreshes this hook after persisting the user doc each turn;
        only conflict/closeness are consumed by homeostasis._drives.
        """
        self.relationship_context = relationship if isinstance(relationship, dict) else None

    def seed_trust_from_user(self, user_trust, weight=0.2, max_delta=0.05) -> float:
        """G3: one-shot bounded trust seed from the user-level record.

        The caller decides *when* (cold start / context rebuild); this method
        only applies the bounded EMA step and marks the core as seeded. Trust
        stays in [0,1] and a single step moves it by at most max_delta.
        """
        try:
            target = _clip(float(user_trust), 0.0, 1.0)
            current = _clip(float(self.trust), 0.0, 1.0)
            delta = float(weight) * (target - current)
            limit = abs(float(max_delta))
            delta = max(-limit, min(limit, delta))
            self.trust = _clip(current + delta, 0.0, 1.0)
            self._user_trust_seeded = True
            self._user_trust_seed_delta = round(delta, 4)
            return round(float(self.trust), 4)
        except Exception:
            return float(getattr(self, "trust", 0.5))

    def load_state(self, d: dict) -> None:
        if not isinstance(d, dict):
            return
        for key in ("v", "a", "d", "stress", "energy", "trust", "social"):
            if key in d:
                try:
                    lo = -1 if key in ("v", "d") else 0
                    hi = 1.0
                    setattr(self, key, _clip(d[key], lo, hi))
                except Exception:
                    pass
        self._derive()
        try:
            self.ticks = max(0, int(d.get("ticks", self.ticks) or 0))
        except Exception:
            pass
        def _num_map(raw, defaults, lo=-1.0, hi=1.0):
            out = dict(defaults)
            if not isinstance(raw, dict):
                return out
            for key, default in defaults.items():
                if key not in raw:
                    continue
                try:
                    value = float(raw.get(key))
                    if not math.isfinite(value):
                        continue
                    out[key] = max(lo, min(hi, value))
                except Exception:
                    continue
            return out

        self.noise = _num_map(d.get("noise"),
                              {"stress": 0.0, "energy": 0.0, "social": 0.0,
                               "attention": 0.0, "valence": 0.0}, -0.3, 0.3)
        self.reflection = _num_map(d.get("reflection"),
                                   {"v": 0.0, "a": 0.0, "d": 0.0, "social": 0.0}, -1.0, 1.0)
        self.momentum = _num_map(d.get("momentum"),
                                 {"v": 0.0, "a": 0.0, "d": 0.0, "social": 0.0}, -1.0, 1.0)
        self.appraisal = _num_map(d.get("appraisal"),
                                  {"novelty": 0.0, "goal_relevance": 0.0,
                                   "coping": 0.5, "agency": 0.5}, 0.0, 1.0)
        self.opponent = _num_map(d.get("opponent"),
                                 {"v": 0.0, "a": 0.0, "d": 0.0, "social": 0.0}, -1.0, 1.0)
        # Labels are display/decision proxies: whitelist known values only.
        _allowed_labels = {
            "emotion": {"joy", "sadness", "anger", "fear", "loneliness", "neutral"},
            "intent": {"approach", "hold", "withdraw"},
            "expression": {"open", "normal", "short"},
            "need": {"share", "space", "vent", "be_heard", "talk"},
            "energy": {"low", "normal", "high"},
            "stress": {"calm", "tense", "overloaded"},
        }
        safe_labels = {}
        raw_labels = d.get("labels") if isinstance(d.get("labels"), dict) else {}
        for key, allowed in _allowed_labels.items():
            value = str(raw_labels.get(key) or "").strip()
            if value in allowed:
                safe_labels[key] = value
        self.labels = {**{"emotion": "neutral", "intent": "hold",
                          "expression": "normal", "need": "talk",
                          "energy": "normal", "stress": "calm"}, **safe_labels}
        if isinstance(d.get("ripple"), dict):
            self.ripple = _num_map(d["ripple"], self.ripple, 0.0, 1.0)
        if isinstance(d.get("spiking"), dict):
            self.spiking = _num_map(d["spiking"], self.spiking, 0.0, 10.0)
        if isinstance(d.get("stimuli"), list):
            self.stimuli = [x for x in d["stimuli"] if isinstance(x, dict)][-40:]
        if isinstance(d.get("history"), list):
            self.history = [x for x in d["history"] if isinstance(x, dict)][-80:]
        if isinstance(d.get("open_loops"), list):
            self.open_loops = [x for x in d["open_loops"] if isinstance(x, dict)][-20:]
        if isinstance(d.get("coping_history"), list):
            self.coping_history = [float(x) for x in d["coping_history"] if isinstance(x, (int, float))][-40:]
        if isinstance(d.get("event_anchors"), list):
            self.event_anchors = [x for x in d["event_anchors"] if isinstance(x, dict)][-20:]
        if isinstance(d.get("autobiography"), list):
            self.autobiography = [x for x in d["autobiography"] if isinstance(x, dict)][-80:]
        if isinstance(d.get("regulation_stats"), dict):
            self.regulation_stats = {str(k): dict(v) for k, v in d["regulation_stats"].items() if isinstance(v, dict)}
        try:
            self.attention = _clip(d.get("attention", 0.5), 0, 1)
        except Exception:
            self.attention = 0.5
        for _key in ("circadian_alertness", "allostatic_load"):
            if _key in d:
                try:
                    setattr(self, _key, _clip(d[_key], 0, 1))
                except Exception:
                    pass
        try:
            self.homeostasis = homeostasis.normalize_state(d.get("homeostasis"))
        except Exception:
            self.homeostasis = homeostasis.default_state()
        # BUG-01: restore the remaining bounded biological fields.
        for _key in ("novelty_need", "boredom", "boundary_pressure", "refusal_readiness"):
            if _key in d:
                try:
                    setattr(self, _key, _clip(d[_key], 0.0, 1.0))
                except Exception:
                    pass
        raw_inter = d.get("interpersonal") if isinstance(d.get("interpersonal"), dict) else {}
        self.interpersonal = {
            "other_valence_est": round(_clip(raw_inter.get("other_valence_est", 0.0), -1.0, 1.0), 6),
            "coupling": round(_clip(raw_inter.get("coupling", 0.0), 0.0, 1.0), 6),
            "dampening": round(_clip(raw_inter.get("dampening", 1.0), 0.0, 1.0), 6),
        }
        digests = d.get("daily_digests")
        if isinstance(digests, list):
            safe_digests = []
            for item in digests[-30:]:
                if not isinstance(item, dict):
                    continue
                try:
                    safe_digests.append({
                        "date": str(item.get("date") or "")[:10],
                        "event_ids": [str(x)[:80] for x in (item.get("event_ids") or [])[:50] if str(x)],
                        "mean_v": round(_clip(item.get("mean_v", 0.0), -1.0, 1.0), 4),
                        "mean_a": round(_clip(item.get("mean_a", 0.0), 0.0, 1.0), 4),
                        "mean_stress": round(_clip(item.get("mean_stress", 0.0), 0.0, 1.0), 4),
                        "dominant_emotion": str(item.get("dominant_emotion") or "neutral")[:20],
                        "interaction_count": max(0, int(item.get("interaction_count", 0) or 0)),
                    })
                except Exception:
                    continue
            self.daily_digests = safe_digests[-30:]
        self.goal_focus = str(d.get("goal_focus") or "")[:40]
        if isinstance(d.get("meta_emotion"), str):
            self.meta_emotion = d["meta_emotion"]
        if isinstance(d.get("goals"), list):
            self.goals = [dict(g) for g in d["goals"] if isinstance(g, dict)][:8]
        if isinstance(d.get("goal_conflict"), list):
            self.goal_conflict = [str(x) for x in d["goal_conflict"]][:6]
        if isinstance(d.get("goal_scores"), dict):
            self.goal_scores = {str(k): _clip(v, 0, 1) for k, v in d["goal_scores"].items()
                                if isinstance(v, (int, float))}
        for _g in self.goals:
            if not isinstance(_g, dict):
                continue
            _g.setdefault("priority", 0.5)
            _g.setdefault("last_update", 0.0)
        if isinstance(d.get("self_timeline"), dict):
            self.self_timeline = d["self_timeline"]
        if isinstance(d.get("reflection_tree"), dict):
            self.reflection_tree = d["reflection_tree"]
        elif isinstance(d.get("reflection_tree"), list):
            self.reflection_tree = {"roots": [x for x in d["reflection_tree"] if isinstance(x, dict)][-10:], "count": len(d["reflection_tree"])}
        if isinstance(d.get("sec"), dict):
            self.sec = dict(d["sec"])
        self.core_self = str(d.get("core_self") or "")
        self.narrative_self = str(d.get("narrative_self") or "")
        self.last_tick = __import__("time").time()
        for key in ("echo", "echo_trace"):
            if key in d:
                try:
                    setattr(self, key, _clip(d[key]))
                except Exception:
                    pass
        # Task-15: restore autonomy counters/history only; enabled is owned by
        # plugin config. Old states without the key keep {"enabled": False}.
        _raw_auto = d.get("proactive_autonomy")
        if isinstance(_raw_auto, dict):
            _safe_auto = {"enabled": bool(_raw_auto.get("enabled", False))}
            for _k in ("threshold", "max_chars", "impulse", "chaos",
                       "impulse_ema", "ready", "gain", "noise_seed",
                       "last_sent_ts", "sent_count", "sent_day", "updated_ts"):
                if _k in _raw_auto:
                    _safe_auto[_k] = _raw_auto[_k]
            self._proactive_autonomy = _safe_auto
            try:
                self._noise_seed = max(0, int(_raw_auto.get("noise_seed", 0) or 0))
            except Exception:
                self._noise_seed = 0
        # Task-28: restore the autonomy-loop state if present; "enabled" is
        # owned by plugin config and unknown/extra keys are ignored.
        _raw_loop = d.get("autonomy_loop")
        if isinstance(_raw_loop, dict):
            self.autonomy_loop = self._autonomy_loop_restore(_raw_loop)
        # task-43 L1 scalars (bounded restore; unknown/NaN -> defaults).
        self.conflict_ema = _clip(d.get("conflict_ema", 0.0) or 0.0, 0.0, 1.0)
        self.rumination_ema = _clip(d.get("rumination_ema", 0.0) or 0.0, 0.0, 1.0)
        self.anchor_weight = _clip(d.get("anchor_weight", 0.25) or 0.25, 0.0, 0.9)
        try:
            self._neg_repeat = max(0, int(d.get("_neg_repeat", 0) or 0))
        except Exception:
            self._neg_repeat = 0
        self._last_neg_topic = str(d.get("_last_neg_topic") or "")[:80]

    def _derive(self) -> None:
        """Derive stress/energy from v, a, dominance, social (they are not independent)."""
        v = float(getattr(self, "v", 0.0))
        a = float(getattr(self, "a", 0.5))
        d = float(getattr(self, "d", 0.55))
        soc = float(getattr(self, "social", 0.55))
        self.stress = _clip(0.45 * max(0.0, -v) * a + 0.35 * (1.0 - d) + 0.20 * (1.0 - soc), 0, 1)
        _offset = 0.0
        try:
            _offset = _clip(float(getattr(self, "_metabolic_energy_offset", 0.0)), 0.0, 0.20)
        except Exception:
            _offset = 0.0
        self.energy = _clip(0.45 * a + 0.25 * max(0.0, v) + 0.20 * d + 0.10 * soc - _offset, 0, 1)

    def _intensity(self) -> float:
        """Normalized current emotional intensity (0..1)."""
        v = abs(float(getattr(self, "v", 0.0)))
        a = float(getattr(self, "a", 0.5))
        d = abs(float(getattr(self, "d", 0.5)) - 0.5) * 2.0
        soc = abs(float(getattr(self, "social", 0.5)) - 0.5) * 2.0
        stress = float(getattr(self, "stress", 0.0))
        return max(0.0, min(1.0, 0.30 * v + 0.30 * a + 0.20 * stress + 0.10 * d + 0.10 * soc))

    def _goal_signature(self, g: dict) -> str:
        try:
            return "、".join([str(g.get("name") or "")] + [str(x) for x in (g.get("keywords") or ())[:6]])
        except Exception:
            return str(g.get("name") or "")

    def _goal_evidence(self, g: dict, local_text: str, context_text: str) -> float:
        """Evidence that a goal is active, from this turn plus retrieved context.

        Local keyword hits are only one channel; memory / self-narrative text is
        compared against the goal signature so relevance is not keyword-only.
        """
        try:
            t = str(local_text or "")
            ctx = str(context_text or "")
            sig = self._goal_signature(g)
            terms = tuple(g.get("keywords") or ())
            terms += tuple((getattr(self, "goal_context_terms", {}) or {}).get(str(g.get("key") or ""), ()))
            hits = sum(1 for w in terms if w and str(w) in t)
            local = min(1.0, 0.35 + 0.18 * hits) if hits else 0.0
            local = max(local, self._text_similarity(t, sig) * 0.75)
            learned = 0.0
            if ctx:
                term_hits = [w for w in terms if w and str(w) in ctx]
                coverage = len(term_hits) / max(1, len(terms))
                density = min(1.0, len(term_hits) / 5.0)
                learned = max(self._text_similarity(ctx[:900], sig) * 1.6,
                              min(1.0, 0.5 * density + 0.9 * coverage))
                for h in (getattr(self, "history", []) or [])[-12:]:
                    _txt = str((h or {}).get("text") or "")
                    if _txt and _txt in ctx:
                        learned = max(learned, self._text_similarity(_txt, sig) * 0.8)
            return max(0.0, min(1.0, max(local, 0.75 * learned)))
        except Exception:
            return 0.0

    def _resolve_goal_conflict(self, scores=None) -> None:
        """Pick a focus among active goals: high priority and low progress win."""
        scores = scores if isinstance(scores, dict) else dict(getattr(self, "goal_scores", {}) or {})
        cand = []
        for g in getattr(self, "goals", []) or []:
            if not isinstance(g, dict):
                continue
            key = str(g.get("key") or "")
            rel = float(scores.get(key, 0.0) or 0.0)
            if rel < 0.25:
                continue
            try:
                pri = float(g.get("priority", 0.5) or 0.5)
                prog = max(0.0, min(1.0, float(g.get("progress", 0.0) or 0.0)))
            except Exception:
                pri, prog = 0.5, 0.0
            cand.append((pri * (1.0 - prog), rel, g))
        if not cand:
            self.goal_focus = ""
            self.goal_conflict = []
            return
        cand.sort(key=lambda x: (x[0], x[1]), reverse=True)
        self.goal_focus = str(cand[0][2].get("name") or "")
        self.goal_conflict = [str(x[2].get("name") or "") for x in cand[1:]][:4]

    def _update_goals(self, text: str, context: str = "") -> None:
        t = str(text or "")
        ctx = str(context or "")
        scores = {}
        for g in getattr(self, "goals", []) or []:
            if not isinstance(g, dict):
                continue
            key = str(g.get("key") or "")
            scores[key] = round(self._goal_evidence(g, t, ctx), 3)
        self.goal_scores = scores
        # Deterministic priority learning: repeated evidence raises a goal,
        # neglect decays it slowly (bounded EMA; no LLM involved).
        try:
            for g in getattr(self, "goals", []) or []:
                if not isinstance(g, dict):
                    continue
                _key = str(g.get("key") or "")
                _rel = float(scores.get(_key, 0.0) or 0.0)
                memory_meta.update_goal_priority(
                    g, hit=(_rel > 0.05), relevance=_rel)
        except Exception:
            pass
        best = max(scores.values()) if scores else 0.0
        self.appraisal["goal_relevance"] = round(best, 3)
        self._resolve_goal_conflict(scores)
        _pos = sum(1 for w in ("谢谢", "喜欢", "陪", "开心", "信任", "爱") if w in t)
        _neg = sum(1 for w in ("废物", "滚", "闭嘴", "讨厌", "没用", "难受") if w in t)
        self.appraisal["norm_compatibility"] = round(max(0.0, min(1.0, 0.5 + 0.12 * _pos - 0.18 * _neg)), 3)
        self.appraisal["expectedness"] = round(1.0 - float(self.appraisal.get("novelty", 0.0) or 0.0), 3)
        self.appraisal["urgency"] = round(float(getattr(self, "a", 0.5)), 3)

    def _advance_goals(self, v_delta: float = 0.0, social_delta: float = 0.0) -> None:
        """Goal progress follows the interaction outcome, not a fixed step."""
        focus_key = ""
        focus_name = str(getattr(self, "goal_focus", "") or "")
        if not focus_name:
            return
        for g in getattr(self, "goals", []) or []:
            if str(g.get("name") or "") == focus_name:
                focus_key = str(g.get("key") or "")
                break
        if not focus_key:
            return
        try:
            rel = float((getattr(self, "goal_scores", {}) or {}).get(focus_key, 0.0) or 0.0)
            if rel <= 0.0:
                return
            gain = (0.004 * rel
                    + 0.060 * max(0.0, float(v_delta))
                    + 0.040 * max(0.0, float(social_delta))
                    - 0.060 * max(0.0, -float(v_delta)))
            # Stage-2 C9: appraisal/emotion now feeds goal progress (real loop),
            # gated by bio_feedback_loops; default OFF keeps 1.2.98 unchanged.
            if getattr(self, "bio_feedback_loops", False):
                try:
                    _coping = float((getattr(self, "appraisal", {}) or {}).get("coping", 0.5) or 0.5)
                    _goal_rel = float((getattr(self, "appraisal", {}) or {}).get("goal_relevance", 0.5) or 0.5)
                    gain += 0.02 * ((_coping - 0.5) + (_goal_rel - 0.5))
                except Exception:
                    pass
            gain = max(-0.06, min(0.08, gain))
            for g in self.goals:
                if str(g.get("key") or "") != focus_key:
                    continue
                g["progress"] = round(max(0.0, min(1.0, float(g.get("progress", 0.0) or 0.0) + gain)), 4)
                g["last_update"] = round(__import__("time").time(), 3)
                try:
                    memory_meta.update_goal_priority(
                        g, hit=(gain >= 0.0), relevance=min(1.0, rel + max(0.0, gain)))
                except Exception:
                    pass
                break
        except Exception:
            pass

    def bind_goal_context(self, memory_text: str = "", self_model=None, recent=None, text: str = "") -> None:
        """Fuse retrieved memory / self narrative / recent turns into goal relevance."""
        try:
            ctx_parts = [str(memory_text or "")]
            if isinstance(self_model, dict):
                ctx_parts.append(str(self_model.get("narrative") or ""))
                ctx_parts.append("、".join(str(x) for x in (self_model.get("consistency") or [])[:5]))
            if isinstance(recent, (list, tuple)):
                ctx_parts.extend(str(x)[:200] for x in recent[:8])
            ctx = "\n".join([p for p in ctx_parts if p])
            if not ctx.strip():
                return
            base = dict(getattr(self, "goal_scores", {}) or {})
            for g in getattr(self, "goals", []) or []:
                if not isinstance(g, dict):
                    continue
                key = str(g.get("key") or "")
                rel = self._goal_evidence(g, str(text or ""), ctx)
                base[key] = round(max(float(base.get(key, 0.0) or 0.0), rel), 3)
            self.goal_scores = base
            if base:
                self.appraisal["goal_relevance"] = round(min(1.0, max(base.values())), 3)
            self._resolve_goal_conflict(base)
        except Exception:
            pass

    def _update_coping(self, pre_stress: float) -> None:
        delta = float(getattr(self, "stress", 0.2)) - float(pre_stress)
        success = 0.5 - 0.8 * delta + 0.15 * (float(getattr(self, "social", 0.5)) - 0.5)
        success = max(0.0, min(1.0, success))
        self.coping_history = (list(getattr(self, "coping_history", [])) + [success])[-40:]
        if self.coping_history:
            self.appraisal["coping"] = round(sum(self.coping_history) / len(self.coping_history), 3)

    def remember_event(self, key: str, title: str, meaning: str = "", reflection: str = "",
                       embedding=None) -> None:
        key = str(key or "").strip()
        title = str(title or "").strip()
        if not key or not title:
            return
        self.event_anchors = [x for x in getattr(self, "event_anchors", [])
                              if x.get("key") != key][-19:]
        _anchor = {"key": key, "title": title, "ts": __import__("time").time()}
        if embedding:
            try:
                _anchor["embedding"] = [float(x) for x in embedding]
            except Exception:
                pass
        self.event_anchors.append(_anchor)
        self.autobiography = (list(getattr(self, "autobiography", [])) + [{
            "ts": __import__("time").time(), "key": key, "title": title,
            "meaning": str(meaning or "")[:400], "reflection": str(reflection or "")[:400],
        }])[-80:]
        try:
            self.self_timeline["past"] = [x.get("title") for x in self.autobiography[-8:]]
            self.self_timeline["present"] = str(reflection or meaning or title)[:300]
            self.self_timeline["future"] = [g.get("name") for g in (self.goals or []) if g.get("name")][:5]
            self.core_self = str(getattr(self, "core_self", "") or title)[:300]
            self.narrative_self = str(reflection or meaning or title)[:500]
        except Exception:
            pass

    @staticmethod
    def _cosine_static(a, b) -> float:
        try:
            aa = [float(x) for x in (a or [])]
            bb = [float(x) for x in (b or [])]
            if not aa or not bb:
                return 0.0
            return sum(x * y for x, y in zip(aa, bb))
        except Exception:
            return 0.0

    @staticmethod
    def _text_similarity(a: str, b: str) -> float:
        a = str(a or "")
        b = str(b or "")
        if not a or not b:
            return 0.0
        def grams(x):
            x = re.sub(r"\s+", "", x)
            return {x[i:i + 2] for i in range(max(0, len(x) - 1))}
        ga, gb = grams(a), grams(b)
        if not ga or not gb:
            return 0.0
        return len(ga & gb) / float(len(ga | gb))

    def _update_sec(self, v_delta: float, a_delta: float) -> None:
        self.sec = {
            "relevance": round(max(0.0, min(1.0, float(self.appraisal.get("goal_relevance", 0.0) or 0.0) * 0.7 + float(self.appraisal.get("novelty", 0.0) or 0.0) * 0.3)), 3),
            "implication": round(max(0.0, min(1.0, abs(float(v_delta)) * 2.0 + float(self.stress))), 3),
            "coping_potential": round(max(0.0, min(1.0, float(self.appraisal.get("coping", 0.5) or 0.5))), 3),
            "normative": round(max(0.0, min(1.0, float(self.appraisal.get("norm_compatibility", 0.5) or 0.5))), 3),
        }

    def _update_attention(self, v_delta: float, a_delta: float) -> None:
        novelty = float(self.appraisal.get("novelty", 0.0) or 0.0)
        goal = float(self.appraisal.get("goal_relevance", 0.0) or 0.0)
        salience = abs(float(v_delta)) * 1.8 + abs(float(a_delta)) * 1.2 + novelty * 0.4 + goal * 0.5
        self.attention = _clip(0.82 * float(self.attention) + 0.18 * _clip(salience, 0, 1), 0, 1)

    def _update_meta_emotion(self) -> None:
        e = str((self.labels or {}).get("emotion") or "neutral")
        t = float(self.trust)
        soc = float(self.social)
        if e == "sadness" and t < 0.55:
            self.meta_emotion = "对难过的羞耻"
        elif e == "anger" and soc < 0.50:
            self.meta_emotion = "对生气的羞耻"
        elif e == "fear" and float(self.appraisal.get("coping", 0.5)) < 0.45:
            self.meta_emotion = "对害怕的焦虑"
        elif e == "loneliness" and t >= 0.55:
            self.meta_emotion = "对孤独的承认"
        else:
            self.meta_emotion = ""

    def update_open_loops(self, text: str, now=None) -> None:
        """Deterministic prospective-memory (open loops) update from one message."""
        try:
            stamp = float(now if now is not None else __import__("time").time())
            loops = [x for x in (getattr(self, "open_loops", []) or []) if isinstance(x, dict)]
            memory_meta.resolve_open_loops(loops, text, stamp)
            for new_loop in memory_meta.detect_open_loops(text, stamp):
                merged = False
                for existing in loops:
                    if str(existing.get("status") or "open") != "open":
                        continue
                    if memory_meta.text_similarity(
                            existing.get("text", ""), new_loop.get("text", "")) >= memory_meta.OPEN_LOOP_MERGE_SIMILARITY:
                        existing["last_mentioned_ts"] = stamp
                        existing["mentioned"] = int(existing.get("mentioned", 1) or 1) + 1
                        merged = True
                        break
                if not merged:
                    loops.append(new_loop)
            self.open_loops = loops[-int(memory_meta.OPEN_LOOP_MAX):]
        except Exception:
            pass

    def observe(self, text: str, embedding=None) -> None:
        self._decay_to_now()
        self._query_embedding = embedding
        _pre_stress = float(self.stress)
        t = str(text or "")
        self._update_goals(t)
        _event_key = ""
        for _anchor in getattr(self, "event_anchors", []) or []:
            _sim = self._text_similarity(re.sub(r"\s+", "", t)[:120], str(_anchor.get("title", "")))
            if self._query_embedding and _anchor.get("embedding"):
                _sim = max(_sim, self._cosine_static(self._query_embedding, _anchor.get("embedding")))
            if _sim >= 0.55:
                _event_key = str(_anchor.get("key", ""))
                break
        v_delta, a_delta, d_delta, social_delta = 0.0, 0.0, 0.0, 0.0
        _hits = []
        for label, words in LEX.items():
            if not any(self._word_hit(t, w) for w in words):
                continue
            _hits.append(label)
            if label == "joy":
                v_delta += 0.12
                a_delta += 0.05
                d_delta += 0.04
                social_delta += 0.03
            elif label == "sadness":
                v_delta -= 0.14
                a_delta -= 0.03
                d_delta -= 0.05
            elif label == "loneliness":
                v_delta -= 0.12
                a_delta -= 0.03
                d_delta -= 0.04
                social_delta -= 0.16
            elif label == "anger":
                v_delta -= 0.12
                a_delta += 0.15
                d_delta += 0.10
                social_delta -= 0.05
            elif label == "fear":
                v_delta -= 0.16
                a_delta += 0.14
                d_delta -= 0.12
                social_delta -= 0.03
        # Short-term habituation: repeated equivalent emotional stimuli decay.
        _now = time.time()
        # B-T06: generic novelty history (also covers non-emotional repeated text).
        try:
            _novelty_text = re.sub(r"\s+", "", t)[:160]
            if _novelty_text:
                _hist = getattr(self, "_novelty_history", [])
                _seen_before = any(
                    self._text_similarity(_novelty_text, str(x)) >= 0.65
                    for x in _hist[-12:])
                if _seen_before:
                    self.boredom = _clip(self.boredom + 0.06 * (1.0 - self.boredom), 0.0, 1.0)
                    self.novelty_need = _clip(self.novelty_need + 0.03 * (1.0 - self.novelty_need), 0.0, 1.0)
                else:
                    self.boredom = _clip(self.boredom - 0.08, 0.0, 1.0)
                    self.novelty_need = _clip(0.94 * self.novelty_need + 0.06 * 0.5, 0.0, 1.0)
                self._novelty_history = (_hist + [_novelty_text])[-20:]
        except Exception:
            pass
        # Batch4 B5: information-gap curiosity proxy. Question/unknown cues raise
        # a bounded EMA that the homeostasis layer reads as extra curiosity.
        try:
            _question_cue = ("?" in t or "？" in t or any(
                w in t for w in ("什么", "谁", "为什么", "怎么", "哪", "多少", "吗", "如何")))
            self.info_gap = _clip(
                0.85 * float(getattr(self, "info_gap", 0.0))
                + 0.15 * (1.0 if _question_cue else 0.0), 0.0, 1.0)
        except Exception:
            self.info_gap = 0.0
        self.stimuli = [x for x in (getattr(self, "stimuli", []) or [])
                        if _now - float(x.get("ts", 0) or 0) <= float(getattr(self, "stimulus_decay_seconds", 300))]
        if _hits:
            _labels = tuple(sorted(set(_hits)))
            _norm = re.sub(r"\s+", "", t)[:120]
            _item = None
            for _cand in self.stimuli:
                if _event_key:
                    if str(_cand.get("event_key", "")) != _event_key:
                        continue
                    _item = _cand
                    break
                if tuple(_cand.get("labels") or ()) != _labels:
                    continue
                if self._text_similarity(_norm, str(_cand.get("text", ""))) >= 0.55:
                    _item = _cand
                    break
            if _item:
                _gap = max(0.0, _now - float(_item.get("ts", _now)))
                try:
                    _count = float(_item.get("n", 0) or 0) * math.exp(-_gap / max(30.0, float(getattr(self, "stimulus_decay_seconds", 300))))
                except Exception:
                    _count = 0.0
            else:
                _count = 0.0
            _hab = 1.0 / (1.0 + float(getattr(self, "stimulus_habituation", 0.75)) * _count)
            _novelty = float((getattr(self, "appraisal", {}) or {}).get("novelty", 0.0) or 0.0)
            _hab *= max(0.25, 1.0 - 0.6 * _novelty)
            # Batch4 B1: sensitization is the dual of habituation. Only strong
            # negative impulses (v_delta <= -0.12) repeated with >=0.55 text
            # similarity get a gain: 1 + 0.15 * sum(0.5 ** (age_h / 24h)),
            # capped at 1.25. Weak/neutral stimuli keep _sens = 1.0; the final
            # impulse is base * _hab * _sens (habituation still applies).
            _sens = 1.0
            try:
                _prior_sens = [x for x in (getattr(self, "_sensitization_history", []) or [])
                               if isinstance(x, dict)
                               and _now - float(x.get("ts", 0) or 0) <= SENSITIZATION_HISTORY_MAX_AGE]
                if v_delta <= SENSITIZATION_STRONG_NEG_DV:
                    _rep = 0.0
                    for _old in _prior_sens:
                        if self._text_similarity(_norm, str(_old.get("text", ""))) < 0.55:
                            continue
                        _age_h = max(0.0, _now - float(_old.get("ts", 0) or 0)) / 3600.0
                        _rep += 0.5 ** (_age_h / SENSITIZATION_HALF_LIFE_HOURS)
                    _sens = min(SENSITIZATION_MAX, 1.0 + SENSITIZATION_STEP * _rep)
                    _prior_sens.append({"text": _norm, "ts": _now})
                self._sensitization_history = _prior_sens[-SENSITIZATION_HISTORY_MAX:]
            except Exception:
                _sens = 1.0
            if _item:
                _item["n"] = _count + 1
                _item["ts"] = _now
            else:
                self.stimuli.append({"labels": _labels, "text": _norm, "n": 1, "ts": _now, "event_key": _event_key})
            v_delta *= _hab * _sens
            a_delta *= _hab * _sens
            d_delta *= _hab * _sens
            social_delta *= _hab * _sens
            if _item:
                # Repeated equivalent stimulus: boredom rises, novelty need rises.
                self.boredom = _clip(self.boredom + (0.05 + 0.03 * min(3.0, _count)) * (1.0 - self.boredom), 0.0, 1.0)
                self.novelty_need = _clip(self.novelty_need + 0.04 * (1.0 - self.novelty_need), 0.0, 1.0)
            else:
                # New stimulus: boredom falls, novelty need eases toward baseline.
                self.boredom = _clip(self.boredom - 0.08, 0.0, 1.0)
                self.novelty_need = _clip(0.92 * self.novelty_need + 0.08 * 0.5, 0.0, 1.0)
        # B-T07: boundary pressure/refusal readiness from explicit command cues.
        _text_b = str(t or "")
        _commands = sum(1 for w in ("必须", "立刻", "马上", "服从", "不许", "闭嘴", "滚", "废物", "没用", "就该") if w in _text_b)
        _polite = sum(1 for w in ("请", "可以", "愿意", "谢谢", "麻烦") if w in _text_b)
        self.boundary_pressure = _clip(0.86 * self.boundary_pressure + 0.14 * min(1.0, _commands) - 0.04 * min(1.0, _polite), 0.0, 1.0)
        self.refusal_readiness = _clip(
            0.78 * self.refusal_readiness + 0.30 * self.boundary_pressure * min(1.0, _commands)
            + 0.08 * self.stress - 0.05 * min(1.0, _polite), 0.0, 1.0)
        # B-T09: estimate other's valence from the stimulus response, couple with dampening.
        _other_v = _clip(v_delta * 2.5, -1.0, 1.0)
        _gain = _clip(float(getattr(self, "profile", {}).get("contagion_gain", 0.10) or 0.10), 0.0, 0.6)
        _reg = str(getattr(self, "regulation", "none") or "none").lower()
        _damp = 0.55 if _reg in ("reappraise", "reframe") else (0.75 if _reg in ("suppress", "suppression") else 1.0)
        _coupling = _clip(_gain * _damp * abs(_other_v), 0.0, 1.0)
        self.interpersonal = {"other_valence_est": round(_other_v, 4),
                              "coupling": round(_coupling, 4), "dampening": round(_damp, 3)}
        self.v = _clip(self.v + 0.05 * _coupling * _other_v, -1, 1)
        self.a = _clip(self.a + 0.02 * _coupling * abs(_other_v), 0, 1)
        self.v = _clip(0.7 * self.v + 0.3 * v_delta, -1, 1)
        self.a = _clip(0.8 * self.a + 0.2 * (0.4 + a_delta), 0, 1)
        self.d = _clip(0.8 * self.d + 0.2 * (0.55 + d_delta), -1, 1)
        self.social = _clip(0.8 * self.social + 0.2 * (0.55 + social_delta), 0, 1)
        # Affective inertia: recent impulses keep pushing in their direction.
        self.momentum["v"] = _clip(0.75 * float(self.momentum.get("v", 0.0)) + 0.25 * v_delta, -1, 1)
        self.momentum["a"] = _clip(0.75 * float(self.momentum.get("a", 0.0)) + 0.25 * a_delta, -1, 1)
        self.momentum["d"] = _clip(0.75 * float(self.momentum.get("d", 0.0)) + 0.25 * d_delta, -1, 1)
        self.momentum["social"] = _clip(0.75 * float(self.momentum.get("social", 0.0)) + 0.25 * social_delta, -1, 1)
        self.v = _clip(self.v + 0.16 * self.momentum["v"], -1, 1)
        self.a = _clip(self.a + 0.16 * self.momentum["a"], 0, 1)
        self.d = _clip(self.d + 0.16 * self.momentum["d"], -1, 1)
        self.social = _clip(self.social + 0.16 * self.momentum["social"], 0, 1)
        # Intensity raises noise amplitude, but a dimension already near its
        # ceiling receives less effective noise (saturation).
        _int = self._intensity()
        _amp = 0.010 + 0.055 * _int
        self.v = _clip(self.v + self._rng.gauss(0, _amp * (1.0 - 0.75 * abs(self.v))), -1, 1)
        self.a = _clip(self.a + self._rng.gauss(0, _amp * (1.0 - 0.55 * self.a)), 0, 1)
        self.d = _clip(self.d + self._rng.gauss(0, _amp * 0.6 * (1.0 - 0.65 * abs(self.d))), -1, 1)
        self.social = _clip(self.social + self._rng.gauss(0, _amp * 0.5 * (1.0 - 0.65 * self.social)), 0, 1)
        # Reflection buffer: impulse proportional to intensity, then decays;
        # feedback is attenuated when the destination is already high.
        _ref_gain = 0.10 + 0.25 * _int
        self.reflection["v"] = _clip(0.90 * float(self.reflection.get("v", 0.0)) + _ref_gain * v_delta, -1, 1)
        self.reflection["a"] = _clip(0.88 * float(self.reflection.get("a", 0.0)) + _ref_gain * a_delta, -1, 1)
        self.reflection["d"] = _clip(0.92 * float(self.reflection.get("d", 0.0)) + _ref_gain * 0.6 * d_delta, -1, 1)
        self.reflection["social"] = _clip(0.92 * float(self.reflection.get("social", 0.0)) + _ref_gain * 0.6 * social_delta, 0, 1)
        self.v = _clip(self.v + self.reflection["v"] * (1.0 - 0.7 * abs(self.v)), -1, 1)
        self.a = _clip(self.a + self.reflection["a"] * (1.0 - 0.5 * self.a), 0, 1)
        self.d = _clip(self.d + self.reflection["d"] * (1.0 - 0.6 * abs(self.d)), -1, 1)
        self.social = _clip(self.social + self.reflection["social"] * (1.0 - 0.6 * self.social), 0, 1)
        # Opponent process (Solomon & Corbit): the after-reaction builds in the
        # opposite direction and decays slowly, producing an affective rebound.
        _deltas = {"v": v_delta, "a": a_delta, "d": d_delta, "social": social_delta}
        for _k in ("v", "a", "d", "social"):
            _old = float(self.opponent.get(_k, 0.0))
            self.opponent[_k] = _clip(0.86 * _old - 0.22 * _deltas[_k], -1, 1)
        self.v = _clip(self.v + float(getattr(self, "opponent_gain", 0.10)) * self.opponent["v"], -1, 1)
        self.a = _clip(self.a + float(getattr(self, "opponent_gain", 0.10)) * self.opponent["a"], 0, 1)
        self.d = _clip(self.d + float(getattr(self, "opponent_gain", 0.10)) * self.opponent["d"], -1, 1)
        self.social = _clip(self.social + float(getattr(self, "opponent_gain", 0.10)) * self.opponent["social"], 0, 1)
        self._derive()
        self._update_coping(_pre_stress)
        # Stage-2 C8: goal progress writes back to appraisal/affect (real loop),
        # gated by bio_feedback_loops; default OFF is a pure 1.2.98 no-op.
        _progress_before = 0.0
        if getattr(self, "bio_feedback_loops", False):
            try:
                _focus = str(getattr(self, "goal_focus", "") or "")
                for _g in (getattr(self, "goals", []) or []):
                    if isinstance(_g, dict) and str(_g.get("name") or "") == _focus:
                        _progress_before = float(_g.get("progress", 0.0) or 0.0)
                        break
            except Exception:
                _progress_before = 0.0
        self._advance_goals(v_delta, social_delta)
        if getattr(self, "bio_feedback_loops", False):
            try:
                _focus = str(getattr(self, "goal_focus", "") or "")
                _progress_after = _progress_before
                for _g in (getattr(self, "goals", []) or []):
                    if isinstance(_g, dict) and str(_g.get("name") or "") == _focus:
                        _progress_after = float(_g.get("progress", 0.0) or 0.0)
                        break
                _pdelta = _progress_after - _progress_before
                if abs(_pdelta) > 1e-9:
                    _apr = self.appraisal if isinstance(self.appraisal, dict) else {}
                    _apr["coping"] = round(_clip(
                        float(_apr.get("coping", 0.5) or 0.5) + 0.30 * _pdelta,
                        0.0, 1.0), 3)
                    _apr["goal_relevance"] = round(_clip(
                        float(_apr.get("goal_relevance", 0.5) or 0.5)
                        + 0.20 * max(0.0, _pdelta), 0.0, 1.0), 3)
                    self.v = _clip(self.v + 0.20 * _pdelta, -1.0, 1.0)
                    self.stress = _clip(self.stress - 0.10 * max(0.0, _pdelta), 0.0, 1.0)
                    self.appraisal = _apr
            except Exception:
                pass
        self._update_attention(v_delta, a_delta)
        self._update_sec(v_delta, a_delta)
        self._update_meta_emotion()
        if not getattr(self, "autonomy_enabled", False):
            # Legacy noise update (1.2.98). When autonomy is enabled, the only
            # noise update point is noise_tick() driven by the background tick.
            for k in self.noise:
                self.noise[k] = _clip(0.82 * self.noise[k] + self._rng.gauss(0, 0.045), -0.3, 0.3)
            self.noise["valence"] = _clip(0.7 * self.noise["valence"] + 0.3 * v_delta, -0.3, 0.3)
            self.noise["stress"] = _clip(0.8 * self.noise["stress"] + 0.2 * (self.stress - 0.2), -0.3, 0.3)
        self.echo_trace = _clip(0.88 * self.echo_trace + 0.12 * (self.v - self.stress * 0.5), -1, 1)
        self.echo = _clip(0.7 * self.echo + 0.3 * self.echo_trace, -1, 1)
        upper = _clip(0.6 * max(0.0, self.v) + 0.2 * self.trust, 0, 1)
        lower = _clip(0.6 * max(0.0, -self.v) + 0.3 * self.stress, 0, 1)
        self.ripple = {"upper": round(upper, 3), "lower": round(lower, 3),
                       "overlap": round(min(upper, lower), 3), "energy": round((upper + lower) / 2, 3)}
        self.spiking = {"rate": round(0.02 + self.energy * 0.08, 3),
                        "variance": round(0.01 + self.stress * 0.05, 4),
                        "ei": round(0.2 + self.trust * 0.3, 3)}
        try:
            self.update_open_loops(t)
        except Exception:
            pass
        self.ticks += 1
        self.infer_labels(force=True)
        try:
            homeostasis.step(self, relationship=getattr(self, "relationship_context", None))
        except Exception:
            pass
        # Task-15: affect tick + homeostasis drive deviation feed L1 noise.
        try:
            self.integrate_noise(
                "emotion_tick",
                stress=0.004 * float(self.stress),
                energy=0.003 * (0.5 - float(self.energy)),
                social=0.003 * (0.5 - float(self.social)),
                valence=0.004 * float(self.v))
            _homeo = self.homeostasis if isinstance(self.homeostasis, dict) else {}
            _l_int = float(_homeo.get("L_int", 0.0) or 0.0)
            _drives = _homeo.get("drives") if isinstance(_homeo.get("drives"), dict) else {}
            _points = _homeo.get("set_points") if isinstance(_homeo.get("set_points"), dict) else {}
            self.integrate_noise(
                "homeostasis",
                energy=0.004 * _l_int,
                social=0.004 * abs(float(_drives.get("social", 0.5))
                                   - float(_points.get("social", 0.55))),
                attention=0.002 * _l_int)
        except Exception:
            pass

    def _spectrum(self) -> list:
        v = (float(getattr(self, "v", 0.0)) + 1.0) / 2.0
        a = float(getattr(self, "a", 0.5))
        d = (float(getattr(self, "d", 0.5)) + 1.0) / 2.0
        soc = float(getattr(self, "social", 0.5))
        out = []
        _emo_bias = {
            "sadness": {"disappointment": 0.42, "empathic_pain": 0.36, "guilt": 0.18},
            "anger": {"anger": 0.52, "contempt": 0.30, "disgust": 0.18},
            "fear": {"fear": 0.52, "anxiety": 0.42, "horror": 0.24},
            "loneliness": {"empathic_pain": 0.42, "disappointment": 0.36, "nostalgia": 0.24},
            "joy": {"joy": 0.52, "contentment": 0.36, "amusement": 0.24},
        }.get(str((self.labels or {}).get("emotion") or ""), {})
        _protos = {}
        try:
            _protos = self._calibrate_spectrum_prototypes()
        except Exception:
            _protos = {}
        for key, cn, sv, sa, sd, ss in EMOTION_SPECTRUM:
            _p = _protos.get(key)
            if _p:
                sv, sa, sd, ss = _p
            dv = v - ((sv + 1.0) / 2.0)
            dd = d - ((sd + 1.0) / 2.0)
            dist = (dv * dv * 1.2 + (a - sa) ** 2 + dd * dd + (soc - ss) ** 2) ** 0.5
            dist = max(0.0, dist - float(_emo_bias.get(key, 0.0)))
            out.append((round(dist, 3), key, cn))
        out.sort(key=lambda x: x[0])
        return [{"key": k, "name": n, "distance": dist} for dist, k, n in out[:3]]

    def _spectrum_probs(self) -> list:
        try:
            out = []
            for it in self._spectrum():
                dist = max(0.001, float(it.get("distance", 1.0)))
                out.append({"key": it.get("key"), "name": it.get("name"), "p": round(1.0 / dist, 4)})
            total = sum(x["p"] for x in out) or 1.0
            for x in out:
                x["p"] = round(x["p"] / total, 4)
            return out
        except Exception:
            return []

    def _calibrate_spectrum_prototypes(self) -> dict:
        """Cowen & Keltner (2017) style prototype calibration.

        Each EMOTION_SPECTRUM anchor is mixed with the centroid of this core's
        own state history for the matching emotion family. Pure anchors are
        used until at least two observations exist, so a single turn cannot
        move the emotion map. Deterministic: no RNG, no LLM call.
        """
        anchors = {key: (sv, sa, sd, ss) for key, cn, sv, sa, sd, ss in EMOTION_SPECTRUM}
        sums = {}
        counts = {}
        hist = list(getattr(self, "history", []) or [])[-80:]
        cur_d = float(getattr(self, "d", 0.55))
        cur_soc = float(getattr(self, "social", 0.55))
        for h in hist:
            if not isinstance(h, dict):
                continue
            emo = str(h.get("emotion") or "").strip()
            keys = SPECTRUM_FAMILY.get(emo)
            if not keys:
                continue
            try:
                w = max(0.05, min(1.0, float(h.get("intensity", 0.5) or 0.5)))
            except Exception:
                w = 0.5
            try:
                hv = float(h.get("v", 0.0))
                ha = float(h.get("a", 0.5))
            except Exception:
                continue
            try:
                hd = float(h.get("d", cur_d))
            except Exception:
                hd = cur_d
            try:
                hs = float(h.get("social", cur_soc))
            except Exception:
                hs = cur_soc
            for key in keys:
                if key not in anchors:
                    continue
                acc = sums.setdefault(key, [0.0, 0.0, 0.0, 0.0, 0.0])
                acc[0] += hv * w
                acc[1] += ha * w
                acc[2] += hd * w
                acc[3] += hs * w
                acc[4] += w
                counts[key] = int(counts.get(key, 0) or 0) + 1
        out = {}
        for key, anchor in anchors.items():
            acc = sums.get(key)
            n = int(counts.get(key, 0) or 0)
            if acc and n >= 2 and acc[4] > 0:
                alpha = min(0.35, 0.06 * n)
                centroid = [acc[0] / acc[4], acc[1] / acc[4], acc[2] / acc[4], acc[3] / acc[4]]
                out[key] = tuple((1.0 - alpha) * anchor[i] + alpha * centroid[i] for i in range(4))
            else:
                out[key] = anchor
        self._spectrum_calibration_meta = {
            "samples": len(hist),
            "families": len({str(h.get("emotion") or "") for h in hist
                             if SPECTRUM_FAMILY.get(str(h.get("emotion") or ""))}),
            "calibrated": sum(1 for k in anchors if int(counts.get(k, 0) or 0) >= 2),
        }
        return out

    def _compound_emotion(self) -> str:
        v = float(getattr(self, "v", 0.0))
        a = float(getattr(self, "a", 0.5))
        d = float(getattr(self, "d", 0.5))
        soc = float(getattr(self, "social", 0.5))
        trust = float(getattr(self, "trust", 0.5))
        w = {
            "joy": max(0.0, v) * max(0.2, a),
            "trust": trust * max(0.0, 1.0 - abs(v)),
            "sadness": max(0.0, -v) * (1.0 - a * 0.5),
            "anger": max(0.0, -v) * a * max(0.0, d - 0.5) * 2.0,
            "fear": max(0.0, -v) * a * max(0.0, 0.5 - d) * 2.0,
            "loneliness": max(0.0, -v) * max(0.0, 0.7 - soc),
            "surprise": max(0.0, float(self.appraisal.get("novelty", 0.0) or 0.0)) * max(0.2, a),
            "anticipation": max(0.0, float(self.appraisal.get("goal_relevance", 0.0) or 0.0)) * max(0.2, a),
            "disgust": max(0.0, -v) * max(0.0, 1.0 - a) * max(0.0, 0.6 - soc),
        }
        top = sorted(w.items(), key=lambda kv: kv[1], reverse=True)[:2]
        if len(top) < 2 or top[1][1] < 0.08:
            return ""
        pair = frozenset((top[0][0], top[1][0]))
        names = {
            frozenset(("joy", "trust")): "亲近",
            frozenset(("joy", "fear")): "不安的期待",
            frozenset(("joy", "sadness")): "苦甜参半",
            frozenset(("joy", "anger")): "复杂",
            frozenset(("joy", "loneliness")): "热闹中的空",
            frozenset(("trust", "fear")): "顺从的不安",
            frozenset(("trust", "sadness")): "失落",
            frozenset(("trust", "anger")): "失望的怒",
            frozenset(("trust", "loneliness")): "想念",
            frozenset(("fear", "sadness")): "无助",
            frozenset(("fear", "anger")): "戒备",
            frozenset(("fear", "loneliness")): "被抛下",
            frozenset(("sadness", "anger")): "委屈",
            frozenset(("sadness", "loneliness")): "空落",
            frozenset(("anger", "loneliness")): "被排斥的怒",
        }
        names.update({
            frozenset(("joy", "surprise")): "惊喜",
            frozenset(("trust", "surprise")): "敬畏",
            frozenset(("fear", "surprise")): "惊骇",
            frozenset(("sadness", "surprise")): "意外失落",
            frozenset(("disgust", "surprise")): "错愕",
            frozenset(("anger", "surprise")): "暴怒",
            frozenset(("anticipation", "surprise")): "期待",
            frozenset(("joy", "anticipation")): "乐观",
            frozenset(("trust", "anticipation")): "希望",
            frozenset(("fear", "anticipation")): "焦虑",
            frozenset(("sadness", "anticipation")): "悲观",
            frozenset(("disgust", "anticipation")): "蔑视",
            frozenset(("anger", "anticipation")): "攻击性",
            frozenset(("joy", "disgust")): "幸灾乐祸",
            frozenset(("trust", "disgust")): "矛盾",
            frozenset(("fear", "disgust")): "厌恶恐惧",
            frozenset(("sadness", "disgust")): "懊悔",
            frozenset(("joy", "sadness")): "苦甜参半",
            frozenset(("trust", "anger")): "失望的怒",
            frozenset(("surprise", "anticipation")): "警觉",
            frozenset(("disgust", "anger")): "轻蔑",
            frozenset(("disgust", "sadness")): "嫌恶",
            frozenset(("disgust", "fear")): "恶心",
            frozenset(("disgust", "trust")): "勉强接受",
            frozenset(("surprise", "joy")): "惊喜",
            frozenset(("surprise", "fear")): "惊骇",
            frozenset(("anticipation", "joy")): "乐观",
            frozenset(("anticipation", "fear")): "焦虑",
        })
        return names.get(pair, "混合")

    def _regulation_rate(self, strategy: str, now: float = None) -> float:
        """G4: recency-weighted success rate for one regulation strategy.

        Raw uses/success/cost stay cumulative; the score is multiplied by an
        exponential recency weight derived from last_update (half-life
        REGULATION_STATS_HALF_LIFE_DAYS). Read-only: stats are never rewritten
        here, and legacy stats without last_update keep their old score.
        """
        try:
            st = (getattr(self, "regulation_stats", None) or {}).get(strategy) or {}
            uses = int(st.get("uses", 0) or 0)
            if uses <= 0:
                return 0.0
            success = float(st.get("success", 0) or 0)
            cost = float(st.get("cost", 0) or 0)
            score = success / uses - 0.05 * (cost / uses)
            last = st.get("last_update")
            if last is None:
                return score
            current = float(now if now is not None else time.time())
            elapsed_days = max(0.0, current - float(last)) / 86400.0
            return score * (0.5 ** (elapsed_days / REGULATION_STATS_HALF_LIFE_DAYS))
        except Exception:
            return 0.0

    def _choose_regulation(self) -> str:
        stress = float(getattr(self, "stress", 0.0))
        trust = float(getattr(self, "trust", 0.5))
        soc = float(getattr(self, "social", 0.5))
        arousal = float(getattr(self, "a", 0.5))
        attention = float(getattr(self, "attention", 0.5))
        emo = str(self.labels.get("emotion") or "neutral")
        if stress >= 0.65:
            if trust >= 0.55:
                return "seek_comfort"
            if soc <= 0.30:
                return "avoid"
            return "reappraise"
        _cands = []
        if emo in ("anger", "fear"):
            _cands = (["suppress", "reappraise", "distraction"] if soc < 0.50
                      else ["reappraise", "express", "distraction"])
            if arousal >= 0.72:
                _cands = ["distraction"] + _cands
        elif emo == "sadness":
            _cands = ["express", "reappraise", "seek_comfort", "distraction"]
        elif emo == "loneliness":
            _cands = ["seek_comfort", "avoid", "express", "distraction"]
        elif stress >= 0.45 and arousal >= 0.70 and attention < 0.55:
            _cands = ["distraction", "reappraise"]
        # Batch4 B2: affect labeling (naming the emotion) is the 7th strategy.
        # Deterministic trigger: spectrum top1 >= 0.45 and arousal >= 0.50.
        if _cands and arousal >= AFFECT_LABEL_MIN_AROUSAL:
            try:
                _top_p = max((float(x.get("p", 0.0) or 0.0)
                              for x in self._spectrum_probs() if isinstance(x, dict)),
                             default=0.0)
            except Exception:
                _top_p = 0.0
            try:
                _label_stats = (getattr(self, "regulation_stats", {}) or {}).get(
                    "label_emotion") or {}
                _last_label = _label_stats.get("last_update")
                if _last_label is None:
                    _label_ready = True
                else:
                    _label_ready = (time.time() - float(_last_label)
                                    >= AFFECT_LABEL_COOLDOWN_SECONDS)
            except Exception:
                _label_ready = True
            if _top_p >= AFFECT_LABEL_MIN_TOP_P and _label_ready:
                _cands = ["label_emotion"] + _cands
        if _cands:
            if getattr(self, "regulation_stats", None):
                _qs = (getattr(self, "_learning", {}) or {}).get("params", {}).get("regulation_q", {}) if getattr(self, "bio_learning", False) else {}
                _cands.sort(key=lambda s: self._regulation_rate(s) + (LEARNING_Q_WEIGHT * float((_qs or {}).get(s, 0.0) or 0.0)), reverse=True)
            return _cands[0]
        return "none"

    def _record_regulation(self, strategy: str, pre_stress: float) -> None:
        """Persist uses / success / cumulative stress change / cost + last_update."""
        if not strategy or strategy == "none":
            return
        try:
            stats = self.regulation_stats
            st = stats.setdefault(strategy, {"uses": 0, "success": 0, "stress_delta": 0.0, "cost": 0.0})
            uses = int(st.get("uses", 0) or 0) + 1
            delta = float(getattr(self, "stress", 0.0)) - float(pre_stress)
            st["uses"] = uses
            st["stress_delta"] = round(float(st.get("stress_delta", 0.0) or 0.0) + delta, 5)
            st["cost"] = round(float(st.get("cost", 0.0) or 0.0) + float(REGULATION_COST.get(strategy, 0.003)), 5)
            st["last_update"] = round(time.time(), 3)
            if getattr(self, "bio_learning", False):
                try:
                    # Daw 2011 Q-learning; min-sample N=5 + step cap 0.02 (review BLOCK-05).
                    r = max(-1.0, min(1.0, (-delta) * 10.0
                                      - 0.05 * float(REGULATION_COST.get(strategy, 0.003))
                                      + 0.10 * float(getattr(self, "a", 0.5))))
                    qs = self._learning.setdefault("params", {}).setdefault("regulation_q", {})
                    evidence = self._learning.setdefault("evidence", {}).setdefault("regulation_q", {})
                    ev = evidence.get(strategy) if isinstance(evidence.get(strategy), dict) else {"n": 0, "sum_pe": 0.0}
                    old_q = float(qs.get(strategy, 0.0) or 0.0)
                    ev["n"] = int(ev.get("n", 0) or 0) + 1
                    ev["sum_pe"] = float(ev.get("sum_pe", 0.0) or 0.0) + (r - old_q)
                    evidence[strategy] = ev
                    if int(ev.get("n", 0)) >= 5:
                        alpha = memory_meta.nassar_alpha(float(ev["sum_pe"]) / int(ev["n"]))
                        delta_q = max(-0.02, min(0.02, alpha * float(ev["sum_pe"]) / int(ev["n"])))
                        new_q = max(-1.0, min(1.0, old_q + delta_q))
                        qs[strategy] = round(new_q, 5)
                        evidence[strategy] = {"n": 0, "sum_pe": 0.0}
                        self._learning["updates_count"] = int(self._learning.get("updates_count", 0) or 0) + 1
                        self._learning["last_update"] = round(time.time(), 3)
                        log = self._learning.get("log") if isinstance(self._learning.get("log"), list) else []
                        log.append({"ts": round(time.time(), 3), "param": "regulation_q." + str(strategy),
                                    "old": round(old_q, 5), "new": round(new_q, 5),
                                    "reason": "delta_stress", "samples": 5})
                        self._learning["log"] = log[-20:]
                except Exception:
                    pass
            if delta <= 0.0005:
                st["success"] = int(st.get("success", 0) or 0) + 1
        except Exception:
            pass

    def _apply_regulation(self) -> None:
        r = self.regulation
        _pre_stress = float(self.stress)
        if r == "seek_comfort":
            self.social = _clip(self.social + 0.03, 0, 1)
            self.stress = _clip(self.stress - 0.02, 0, 1)
        elif r == "reappraise":
            self.stress = _clip(self.stress - 0.04, 0, 1)
            self.v = _clip(self.v + 0.015, -1, 1)
        elif r == "suppress":
            self.stress = _clip(self.stress + 0.01, 0, 1)
            self.v = _clip(self.v - 0.005, -1, 1)
        elif r == "avoid":
            self.social = _clip(self.social - 0.03, 0, 1)
        elif r == "express":
            self.v = _clip(self.v + 0.01, -1, 1)
            self.stress = _clip(self.stress - 0.01, 0, 1)
        elif r == "label_emotion":
            # Batch4 B2: name the feeling; deliberately tiny effects (not a
            # comfort button): v toward 0, arousal/stress slightly down.
            self.v = _clip(self.v + 0.005, -1, 1)
            self.a = _clip(self.a - 0.01, 0, 1)
            self.stress = _clip(self.stress - 0.005, 0, 1)
        elif r == "distraction":
            # Brief relief: lower arousal/stress now, but attention and the
            # current goal pay for it because the concern is left unaddressed.
            self.a = _clip(self.a - 0.06, 0, 1)
            self.stress = _clip(self.stress - 0.035, 0, 1)
            self.attention = _clip(self.attention - 0.05, 0, 1)
            _focus = str(getattr(self, "goal_focus", "") or "")
            for g in self.goals:
                if str(g.get("name") or "") == _focus:
                    g["progress"] = round(max(0.0, float(g.get("progress", 0) or 0) - 0.005), 5)
                    break
        self._derive()
        self._record_regulation(r, _pre_stress)

    def infer_labels(self, force: bool = False) -> None:
        """Derive labels from the biological state when the model omits them."""
        v = float(getattr(self, "v", 0.0))
        a = float(getattr(self, "a", 0.5))
        d = float(getattr(self, "d", 0.55))
        soc = float(getattr(self, "social", 0.55))
        stress = float(getattr(self, "stress", 0.0))
        energy = float(getattr(self, "energy", 0.8))
        trust = float(getattr(self, "trust", 0.5))
        inferred = {}
        if soc <= 0.47 and v <= 0.00:
            inferred["emotion"] = "loneliness"
        elif v >= 0.16 and a >= 0.40 and d >= 0.35:
            inferred["emotion"] = "joy"
        elif v <= -0.20 and a < 0.55:
            inferred["emotion"] = "sadness"
        elif v <= -0.12 and a >= 0.55 and d >= 0.50:
            inferred["emotion"] = "anger"
        elif v <= -0.08 and a >= 0.50 and d < 0.50:
            inferred["emotion"] = "fear"
        else:
            inferred["emotion"] = "neutral"
        if v >= 0.25 and soc >= 0.35:
            inferred["intent"] = "approach"
        elif v <= -0.25 or soc <= 0.30:
            inferred["intent"] = "withdraw"
        else:
            inferred["intent"] = "hold"
        if energy >= 0.68 and v >= 0.15:
            inferred["expression"] = "open"
        elif energy <= 0.35:
            inferred["expression"] = "short"
        else:
            inferred["expression"] = "normal"
        if soc <= 0.30:
            inferred["need"] = "space"
        elif stress >= 0.65:
            inferred["need"] = "vent" if trust >= 0.40 else "space"
        elif trust >= 0.60:
            inferred["need"] = "be_heard" if v <= 0.0 else "share"
        elif v <= -0.30:
            inferred["need"] = "space"
        else:
            inferred["need"] = "talk"
        inferred["energy"] = "high" if energy >= 0.70 else ("low" if energy <= 0.35 else "normal")
        inferred["stress"] = "overloaded" if stress >= 0.70 else ("tense" if stress >= 0.35 else "calm")
        for key, value in inferred.items():
            if force or not self.labels.get(key):
                self.labels[key] = value
        self.compound = self._compound_emotion()
        self.regulation = self._choose_regulation()
        self._apply_regulation()

    def intent(self) -> dict:
        labels = dict(getattr(self, "labels", {}) or {})
        return {
            "emotion": labels.get("emotion", "neutral"),
            "energy": labels.get("energy", "normal"),
            "stress": labels.get("stress", "calm"),
            "trust": round(self.trust, 2),
            "intent": labels.get("intent", "hold"),
            "expression": labels.get("expression", "normal"),
            "need": labels.get("need", "talk"),
            "dominance": round(self.d, 2),
            "social": round(self.social, 2),
            "compound": self.compound,
            "spectrum": self._spectrum(),
            "regulation": self.regulation,
        }

    def apply_affect(self, meta: dict) -> None:
        if not isinstance(meta, dict):
            return
        def delta(key, lo=-0.30, hi=0.30):
            try:
                return _clip(meta.get(key, 0.0), lo, hi)
            except Exception:
                return 0.0
        self.v = _clip(self.v + delta("valence_delta"), -1, 1)
        self.a = _clip(self.a + delta("arousal_delta"), 0, 1)
        self.d = _clip(self.d + delta("dominance_delta"), -1, 1)
        self.social = _clip(self.social + delta("social_delta"), 0, 1)
        # Backward compatibility with old tags that only sent stress/energy.
        if "dominance_delta" not in meta and "stress_delta" in meta:
            self.d = _clip(self.d - delta("stress_delta") * 0.5, -1, 1)
        if "social_delta" not in meta and "stress_delta" in meta:
            self.social = _clip(self.social - max(0.0, delta("stress_delta")) * 0.4, 0, 1)
        self.trust = _clip(self.trust + delta("trust_delta"), 0, 1)
        self.momentum["v"] = _clip(0.75 * float(self.momentum.get("v", 0.0)) + 0.25 * delta("valence_delta"), -1, 1)
        self.momentum["a"] = _clip(0.75 * float(self.momentum.get("a", 0.0)) + 0.25 * delta("arousal_delta"), -1, 1)
        self.momentum["d"] = _clip(0.75 * float(self.momentum.get("d", 0.0)) + 0.25 * delta("dominance_delta"), -1, 1)
        self.momentum["social"] = _clip(0.75 * float(self.momentum.get("social", 0.0)) + 0.25 * delta("social_delta"), -1, 1)
        self.v = _clip(self.v + 0.12 * self.momentum["v"], -1, 1)
        self.a = _clip(self.a + 0.12 * self.momentum["a"], 0, 1)
        self.d = _clip(self.d + 0.12 * self.momentum["d"], -1, 1)
        self.social = _clip(self.social + 0.12 * self.momentum["social"], 0, 1)
        for _k in ("novelty", "goal_relevance", "coping", "agency"):
            if _k + "_delta" in meta:
                self.appraisal[_k] = _clip(float(self.appraisal.get(_k, 0.0)) + delta(_k + "_delta"), 0, 1)
        self._derive()
        allowed = {
            "emotion": {"joy", "sadness", "anger", "fear", "loneliness", "neutral"},
            "intent": {"approach", "hold", "withdraw"},
            "expression": {"open", "normal", "short"},
            "need": {"share", "space", "vent", "be_heard", "talk"},
            "energy": {"low", "normal", "high"},
            "stress": {"calm", "tense", "overloaded"},
        }
        for key, values in allowed.items():
            value = str(meta.get(key) or "").strip()
            if value in values:
                self.labels[key] = value
        # task-39 §9.3: optional soft-bounded negative feedback replacing the
        # final hard clamp. Default OFF => bit-identical to the legacy _clip path.
        if getattr(self, "soft_bound_enabled", False):
            try:
                _prof = self.profile if isinstance(self.profile, dict) else {}
                _k = float(getattr(self, "soft_bound_k", 0.10) or 0.10)
                _mf = float(getattr(self, "soft_bound_m_frac", 0.08) or 0.08)
                _lam = float(getattr(self, "soft_bound_lam", 0.10) or 0.10)
                _bv = float(_prof.get("baseline_v", 0.05) or 0.05)
                _ba = float(_prof.get("baseline_a", 0.40) or 0.40)
                self.v = memory_meta.soft_bounded(self.v, _bv, -1.0, 1.0, _k, _mf, _lam)
                self.a = memory_meta.soft_bounded(self.a, _ba, 0.0, 1.0, _k, _mf, _lam)
                self.d = memory_meta.soft_bounded(self.d, 0.5, -1.0, 1.0, _k, _mf, _lam)
                self.social = memory_meta.soft_bounded(self.social, 0.5, 0.0, 1.0, _k, _mf, _lam)
                self.trust = memory_meta.soft_bounded(self.trust, 0.5, 0.0, 1.0, _k, _mf, _lam)
            except Exception:
                pass
        self._derive()
        self.infer_labels(force=False)
        self.ticks += 1
        self.noise["valence"] = _clip(0.7 * self.noise["valence"] + 0.3 * delta("valence_delta"), -0.3, 0.3)
        self.noise["stress"] = _clip(0.8 * self.noise["stress"] + 0.2 * delta("stress_delta"), -0.3, 0.3)
        self.echo_trace = _clip(0.88 * self.echo_trace + 0.12 * (self.v - self.stress * 0.5), -1, 1)
        self.echo = _clip(0.7 * self.echo + 0.3 * self.echo_trace, -1, 1)
        upper = _clip(0.6 * max(0.0, self.v) + 0.2 * self.trust, 0, 1)
        lower = _clip(0.6 * max(0.0, -self.v) + 0.3 * self.stress, 0, 1)
        self.ripple = {"upper": round(upper, 3), "lower": round(lower, 3),
                       "overlap": round(min(upper, lower), 3), "energy": round((upper + lower) / 2, 3)}
        self.spiking = {"rate": round(0.02 + self.energy * 0.08, 3),
                        "variance": round(0.01 + self.stress * 0.05, 4),
                        "ei": round(0.2 + self.trust * 0.3, 3)}

    def feedback(self, reply: str) -> None:
        r = str(reply or "")
        warm = 0.008 * sum(1 for w in ("谢谢", "在", "陪", "懂", "一起", "抱") if w in r)
        self.trust = _clip(self.trust + warm, 0, 1)
        self.social = _clip(self.social + warm * 0.5, 0, 1)
        self._derive()
        self.echo_trace = _clip(0.9 * self.echo_trace + 0.1 * warm, -1, 1)

    def _recovery_speed(self) -> float:
        """Batch4 B4: contextual recovery-speed multiplier, bounded [0.8, 1.2].

        speed = clamp(0.85 + 0.30*recovery_rate
                      + 0.05*(2*coping_success - 1)
                      + 0.05*(circadian_alertness - 0.5), 0.8, 1.2)
        Applied as HL/speed only to dimensions below baseline (v<0, a>0.40,
        social<0.55), so recovery is faster after rest/support and slower when
        recovery_rate is low. Deterministic, no LLM, no new stored field.
        """
        try:
            rate = _clip(float((getattr(self, "profile", {}) or {}).get(
                "recovery_rate", 0.62) or 0.62), 0.0, 1.0)
        except Exception:
            rate = 0.62
        success = 0.5
        try:
            stats = getattr(self, "regulation_stats", {}) or {}
            uses = sum(int(v.get("uses", 0) or 0) for v in stats.values()
                       if isinstance(v, dict))
            succ = sum(int(v.get("success", 0) or 0) for v in stats.values()
                       if isinstance(v, dict))
            if uses > 0:
                success = _clip(succ / uses, 0.0, 1.0)
        except Exception:
            success = 0.5
        try:
            alert = _clip(float(getattr(self, "circadian_alertness", 0.5) or 0.5), 0.0, 1.0)
        except Exception:
            alert = 0.5
        speed = (0.85 + 0.30 * rate + 0.05 * (2.0 * success - 1.0)
                 + 0.05 * (alert - 0.5))
        return max(RECOVERY_CONTEXT_MIN, min(RECOVERY_CONTEXT_MAX, speed))

    def _decay_to_now(self) -> None:
        now = __import__("time").time()
        try:
            dt_min = max(0.0, (now - float(getattr(self, "last_tick", now))) / 60.0)
        except Exception:
            dt_min = 0.0
        self.last_tick = now
        if dt_min < 0.5:
            return
        def factor(halflife):
            try:
                hl = max(1.0, float(halflife))
            except Exception:
                hl = 120.0
            return 0.5 ** (dt_min / hl)
        _emo = str((getattr(self, "labels", {}) or {}).get("emotion") or "neutral")
        _ef = float((getattr(self, "emotion_decay_factors", {}) or {}).get(_emo, 1.0))
        # Batch4 B4: contextual recovery speed shortens the half-life only for
        # dimensions that are recovering toward baseline.
        _rec = self._recovery_speed()
        _v_rec = _rec if self.v < 0 else 1.0
        _a_rec = _rec if self.a > 0.40 else 1.0
        _soc_rec = _rec if self.social < 0.55 else 1.0
        self.v = _clip(self.v * factor(self.valence_decay_minutes * _ef / _v_rec), -1, 1)
        self.a = _clip(0.40 + (self.a - 0.40) * factor(
            self.arousal_decay_minutes * max(0.5, _ef) / _a_rec), 0, 1)
        self.d = _clip(0.55 + (self.d - 0.55) * factor(self.valence_decay_minutes * _ef), -1, 1)
        self.social = _clip(0.55 + (self.social - 0.55) * factor(
            self.social_decay_minutes * _ef / _soc_rec), 0, 1)
        self._derive()
        try:
            self._apply_circadian_effects()
            self._update_allostatic_load()
        except Exception:
            pass
        try:
            self._metabolic_energy_offset = _clip(
                float(getattr(self, "_metabolic_energy_offset", 0.0)) * 0.98, 0.0, 0.20)
        except Exception:
            self._metabolic_energy_offset = 0.0

    def apply_memory_trace(self, v_delta: float = 0.0, stress_delta: float = 0.0) -> dict:
        """Single BioCore writer for L3 memory-trace nudges (bounded)."""
        try:
            dv = max(-0.05, min(0.05, float(v_delta or 0.0)))
        except Exception:
            dv = 0.0
        try:
            ds = max(-0.05, min(0.05, float(stress_delta or 0.0)))
        except Exception:
            ds = 0.0
        self.v = _clip(float(getattr(self, "v", 0.0)) + dv, -1.0, 1.0)
        self.stress = _clip(float(getattr(self, "stress", 0.0)) + ds, 0.0, 1.0)
        return {"v_delta": round(dv, 4), "stress_delta": round(ds, 4)}

    def record_reply(self, text: str = "", meta=None) -> None:
        try:
            emo = str((self.labels or {}).get("emotion") or "neutral")
            self.history.append({
                "ts": __import__("time").time(),
                "emotion": emo,
                "compound": str(self.compound or ""),
                "intensity": round(float(self._intensity()), 3),
                "v": round(float(self.v), 3),
                "a": round(float(self.a), 3),
                "d": round(float(self.d), 3),
                "social": round(float(self.social), 3),
                "text": str(text or "")[:80],
            })
            if len(self.history) > 80:
                self.history = self.history[-80:]
        except Exception:
            pass

    def _apply_circadian_effects(self, alert=None, now=None) -> float:
        """Small attention/energy modulation from local-hour alertness."""
        try:
            if alert is None:
                current = time.localtime(time.time() if now is None else now)
                alert = circadian_alertness(current.tm_hour + current.tm_min / 60.0)
            alert = max(0.0, min(1.0, float(alert)))
            self.circadian_alertness = round(alert, 3)
            delta = 0.01 * (alert - 0.5)
            self.energy = _clip(self.energy + delta, 0.0, 1.0)
            self.attention = _clip(self.attention + delta * 0.5, 0.0, 1.0)
            return alert
        except Exception:
            return 0.5

    def _update_allostatic_load(self) -> float:
        """Slow allostatic accumulation/recovery; bounded, tiny stress offset."""
        try:
            stress = _clip(self.stress, 0.0, 1.0)
            if stress > 0.55:
                self.allostatic_load = _clip(
                    self.allostatic_load + 0.01 * (stress - 0.55) * (1.0 - self.allostatic_load), 0.0, 1.0)
            else:
                self.allostatic_load = _clip(
                    self.allostatic_load - 0.004 * (0.55 - stress), 0.0, 1.0)
            if self.allostatic_load > 0:
                self.stress = _clip(self.stress + 0.005 * self.allostatic_load, 0.0, 1.0)
            return float(self.allostatic_load)
        except Exception:
            return 0.0

    def update_daily_digest(self, now=None, event_ids=None) -> dict:
        """Deterministic daily digest base; no narrative/LLM. Bounded to 30 days."""
        try:
            current = float(time.time() if now is None else now)
            date = time.strftime("%Y-%m-%d", time.localtime(current))
            accum = getattr(self, "_daily_accum", None)
            if not isinstance(accum, dict):
                accum = {"date": "", "n": 0, "v": 0.0, "a": 0.0, "stress": 0.0,
                         "emotions": {}, "ticks": 0, "event_ids": []}
            if accum.get("date") and accum.get("date") != date:
                if int(accum.get("n", 0) or 0) > 0:
                    emotions = accum.get("emotions") or {}
                    dominant = max(emotions.items(), key=lambda kv: kv[1])[0] if emotions else "neutral"
                    n = int(accum.get("n", 1) or 1)
                    self.daily_digests.append({
                        "date": str(accum.get("date")),
                        "event_ids": [str(x) for x in (accum.get("event_ids") or [])[-50:] if str(x)],
                        "mean_v": round(float(accum.get("v", 0.0) or 0.0) / n, 4),
                        "mean_a": round(float(accum.get("a", 0.0) or 0.0) / n, 4),
                        "mean_stress": round(float(accum.get("stress", 0.0) or 0.0) / n, 4),
                        "dominant_emotion": dominant,
                        "interaction_count": n,
                    })
                    self.daily_digests = self.daily_digests[-30:]
                accum = {"date": date, "n": 0, "v": 0.0, "a": 0.0, "stress": 0.0,
                         "emotions": {}, "ticks": 0, "event_ids": []}
            accum["date"] = date
            accum["n"] = int(accum.get("n", 0) or 0) + 1
            accum["v"] = float(accum.get("v", 0.0) or 0.0) + float(self.v)
            accum["a"] = float(accum.get("a", 0.0) or 0.0) + float(self.a)
            accum["stress"] = float(accum.get("stress", 0.0) or 0.0) + float(self.stress)
            _emo = str((self.labels or {}).get("emotion") or "neutral")
            emotions = accum.get("emotions") if isinstance(accum.get("emotions"), dict) else {}
            emotions[_emo] = int(emotions.get(_emo, 0) or 0) + 1
            accum["emotions"] = emotions
            accum["ticks"] = int(accum.get("ticks", 0) or 0) + 1
            if isinstance(event_ids, (list, tuple)):
                _eids = accum.get("event_ids") if isinstance(accum.get("event_ids"), list) else []
                for _eid in event_ids:
                    if str(_eid) and str(_eid) not in _eids:
                        _eids.append(str(_eid))
                accum["event_ids"] = _eids[-50:]
            self._daily_accum = accum
            _b = getattr(self, "_core_bridge", None)
            if _b is not None and getattr(_b, "enabled", False) and str(getattr(_b, "mode", "off")) in ("primary", "shadow"):
                try:
                    import json as _json
                    _b.summary_dry_run({"session": str(event_ids or date)[:64], "text": _json.dumps(accum, ensure_ascii=False)[:4000]})
                except Exception:
                    pass
            return dict(accum)
        except Exception:
            return {}

    def _reflection_tree_view(self) -> dict:
        """G15: read-only reflection tree with old nodes softly forgotten.

        Nodes carry their creation ts; nodes older than REFLECTION_TREE_TTL_DAYS
        are hidden from snapshots/dashboard without deleting stored history.
        """
        try:
            tree = self.reflection_tree if isinstance(self.reflection_tree, dict) else {}
            cutoff = time.time() - REFLECTION_TREE_TTL_DAYS * 86400.0

            def _alive(node):
                try:
                    ts = float(node.get("ts", 0) or 0)
                except Exception:
                    ts = 0.0
                return ts <= 0 or ts >= cutoff

            roots = []
            for node in (tree.get("roots") or [])[:10]:
                if not isinstance(node, dict) or not _alive(node):
                    continue
                item = dict(node)
                item["children"] = [dict(child) for child in
                                    (node.get("children") or [])[-10:]
                                    if isinstance(child, dict) and _alive(child)]
                roots.append(item)
            stored_roots = [node for node in (tree.get("roots") or [])
                            if isinstance(node, dict)]
            stored_total = sum(
                1 + len([c for c in (node.get("children") or []) if isinstance(c, dict)])
                for node in stored_roots)
            visible_total = sum(1 + len(item.get("children") or []) for item in roots)
            return {"roots": roots[-10:], "count": int(tree.get("count", 0) or 0),
                    "hidden_count": max(0, stored_total - visible_total)}
        except Exception:
            return {"roots": [], "count": 0, "hidden_count": 0}

    def integrate_noise(self, source: str = "", **deltas) -> dict:
        """L1 task-15: decayed addition into the 5-channel noise integrator.

        Only active when the plugin enabled proactive autonomy
        (core.autonomy_enabled). Default OFF is a pure no-op, so the legacy
        noise trajectory is unchanged. Channels decay 0.98 per integration and
        are clamped to ±NOISE_CLAMP. This is an L1 state update: callers only
        hand in module deltas; no caller reads it to bypass L1 decisions.
        """
        if not getattr(self, "autonomy_enabled", False):
            return {}
        # Accumulator only: modules add small deltas; the single tick applies
        # decay + RNG + the accumulated injections (P0-2 unified noise model).
        if not isinstance(getattr(self, "_noise_accum", None), dict):
            self._noise_accum = {}
        out = {}
        try:
            for key in ("stress", "energy", "social", "attention", "valence"):
                try:
                    add = float(deltas.get(key, 0.0) or 0.0)
                except Exception:
                    add = 0.0
                add = max(-0.02, min(0.02, add))
                current = float(self._noise_accum.get(key, 0.0) or 0.0)
                value = _clip(current + add, -NOISE_CLAMP, NOISE_CLAMP)
                self._noise_accum[key] = round(value, 4)
                out[key] = round(value, 4)
            self._last_noise_source = {"source": str(source or "")[:40],
                                       "ts": round(time.time(), 3)}
        except Exception:
            pass
        return out

    def noise_tick(self, now=None) -> dict:
        """L1 task-15 P0-2: single noise update point.

        noise = clip(0.82*noise + gauss(0,0.045) + accumulated module deltas,
                     ±NOISE_CLAMP). Only called by the autonomy tick; legacy
        per-observe noise updates are skipped while autonomy is enabled.
        """
        if not (getattr(self, "autonomy_enabled", False)
                or getattr(self, "autonomy_loop_enabled", False)):
            return {}
        out = {}
        try:
            accum = self._noise_accum if isinstance(getattr(self, "_noise_accum", None), dict) else {}
            for key in ("stress", "energy", "social", "attention", "valence"):
                old = float(self.noise.get(key, 0.0) or 0.0)
                try:
                    gauss = float(self._rng.gauss(0, 0.045))
                except Exception:
                    gauss = 0.0
                try:
                    add = float(accum.get(key, 0.0) or 0.0)
                except Exception:
                    add = 0.0
                value = _clip(0.82 * old + gauss + add, -NOISE_CLAMP, NOISE_CLAMP)
                self.noise[key] = round(value, 4)
                out[key] = round(value, 4)
            self._noise_accum = {}
        except Exception:
            pass
        return out

    # ------------------------------------------------------------------
    # Task-28: minimal autonomy loop (L1, deterministic, default OFF)
    # ------------------------------------------------------------------
    @staticmethod
    def _loop_num(value, default: float = 0.0, lo: float = 0.0,
                  hi: float = 1.0) -> float:
        """Finite, bounded float for loop inputs (NaN/Inf -> default)."""
        try:
            num = float(value)
        except Exception:
            return default
        if num != num or num in (float("inf"), float("-inf")):
            return default
        return max(lo, min(hi, num))

    @staticmethod
    def _autonomy_loop_default_state(now: float = 0.0) -> dict:
        """Bounded loop state shape (spec §7.2); created only while enabled."""
        try:
            stamp = float(now or time.time())
        except Exception:
            stamp = time.time()
        return {
            "enabled": True,
            "tick": 0,
            "candidates": [],
            "winner": None,
            "ignition": False,
            "workspace_token": "",
            "inhibition": {},
            "value_ema": {},
            "effort_debt": 0.0,
            "budget": {"day": time.strftime("%Y-%m-%d", time.localtime(stamp)),
                       "used": 0, "last_action_ts": 0.0},
            "stats": {"ticks": 0, "no_ignition": 0, "ignitions": 0, "executed": 0,
                      "blocked_group": 0, "blocked_quiet": 0,
                      "blocked_cooldown": 0, "blocked_cap": 0},
            "updated_ts": 0.0,
        }

    def _autonomy_loop_restore(self, raw: dict) -> dict:
        """Restore persisted loop state; unknown keys dropped, values bounded."""
        base = self._autonomy_loop_default_state()
        if not isinstance(raw, dict):
            return base
        try:
            base["tick"] = max(0, min(10 ** 9, int(raw.get("tick", 0) or 0)))
        except Exception:
            base["tick"] = 0
        cands = raw.get("candidates") if isinstance(raw.get("candidates"), list) else []
        safe_cands = []
        for row in cands[:AUTONOMY_LOOP_CANDIDATE_MAX]:
            if not isinstance(row, dict):
                continue
            mode = str(row.get("mode") or "")[:AUTONOMY_LOOP_WORKSPACE_MAX]
            if mode not in AUTONOMY_LOOP_MODES:
                continue
            safe_cands.append({
                "mode": mode,
                "source": str(row.get("source") or "")[:16],
                "salience": round(self._loop_num(row.get("salience"), 0.0, 0.0, 1.0), 4),
                "goal_gain": round(self._loop_num(row.get("goal_gain"), 1.0, 0.8, 1.4), 4),
                "discount": round(self._loop_num(row.get("discount"), 1.0, 0.05, 1.0), 4),
                "effort": round(self._loop_num(row.get("effort"), 0.5, 0.0, 1.0), 4),
                "cost": round(self._loop_num(row.get("cost"), 0.0, 0.0, 1.0), 4),
                "value": round(self._loop_num(row.get("value"), 0.0,
                                              AUTONOMY_LOOP_VALUE_MIN,
                                              AUTONOMY_LOOP_VALUE_MAX), 4),
            })
        base["candidates"] = safe_cands
        winner = raw.get("winner")
        if isinstance(winner, dict) and str(winner.get("mode") or "") in AUTONOMY_LOOP_MODES:
            base["winner"] = {
                "mode": str(winner.get("mode"))[:AUTONOMY_LOOP_WORKSPACE_MAX],
                "value": round(self._loop_num(winner.get("value"), 0.0,
                                              AUTONOMY_LOOP_VALUE_MIN,
                                              AUTONOMY_LOOP_VALUE_MAX), 4),
                "ts": round(self._loop_num(winner.get("ts"), 0.0, 0.0, 10 ** 12), 3),
            }
        base["ignition"] = bool(raw.get("ignition", False))
        token = str(raw.get("workspace_token") or "")[:AUTONOMY_LOOP_WORKSPACE_MAX]
        base["workspace_token"] = token if token in AUTONOMY_LOOP_MODES else ""
        inhibition = raw.get("inhibition") if isinstance(raw.get("inhibition"), dict) else {}
        safe_inh = {}
        for mode, ts in list(inhibition.items())[:AUTONOMY_LOOP_CANDIDATE_MAX]:
            mode = str(mode or "")[:AUTONOMY_LOOP_WORKSPACE_MAX]
            if mode not in AUTONOMY_LOOP_MODES:
                continue
            safe_inh[mode] = round(self._loop_num(ts, 0.0, 0.0, 10 ** 12), 3)
        base["inhibition"] = dict(sorted(safe_inh.items(),
                                         key=lambda kv: kv[1], reverse=True)
                                 [:AUTONOMY_LOOP_CANDIDATE_MAX])
        ema = raw.get("value_ema") if isinstance(raw.get("value_ema"), dict) else {}
        base["value_ema"] = {
            str(k)[:AUTONOMY_LOOP_WORKSPACE_MAX]:
                round(self._loop_num(v, 0.0, AUTONOMY_LOOP_VALUE_MIN,
                                     AUTONOMY_LOOP_VALUE_MAX), 6)
            for k, v in list(ema.items())[:AUTONOMY_LOOP_CANDIDATE_MAX]
            if str(k)[:AUTONOMY_LOOP_WORKSPACE_MAX] in AUTONOMY_LOOP_MODES}
        base["effort_debt"] = round(self._loop_num(
            raw.get("effort_debt"), 0.0, 0.0, AUTONOMY_LOOP_DEBT_MAX), 6)
        budget = raw.get("budget") if isinstance(raw.get("budget"), dict) else {}
        base["budget"] = {
            "day": str(budget.get("day") or "")[:10],
            "used": max(0, min(int(self._loop_num(budget.get("used"), 0.0, 0.0, 10 ** 6)),
                               AUTONOMY_DAILY_CAP)),
            "last_action_ts": round(self._loop_num(
                budget.get("last_action_ts"), 0.0, 0.0, 10 ** 12), 3),
        }
        stats = raw.get("stats") if isinstance(raw.get("stats"), dict) else {}
        base["stats"] = {key: max(0, min(
            int(self._loop_num(stats.get(key), 0.0, 0.0, 10 ** 9)), 10 ** 9))
            for key in base["stats"]}
        base["updated_ts"] = round(self._loop_num(
            raw.get("updated_ts"), 0.0, 0.0, 10 ** 12), 3)
        return base

    def _autonomy_loop_param(self, name: str, default: float,
                             lo: float, hi: float) -> float:
        """Read one loop tuning parameter, defensively clamped to its range."""
        try:
            value = float(getattr(self, name, default))
        except Exception:
            return float(default)
        if value != value or value in (float("inf"), float("-inf")):
            return float(default)
        return max(float(lo), min(float(hi), value))

    def _autonomy_loop_ior_factor(self, state: dict, mode: str, now: float) -> float:
        """Return-inhibition recovery factor (Itti & Koch 1998 WTA + IOR).

        A just-broadcast mode is fully suppressed (0) and recovers towards 1 as
        exp(-Δ/τ). Note: spec §2's literal exp(-Δ/τ) points the opposite way
        (no suppression right after selection); the implemented direction is the
        IOR semantics the spec's S9 scenario requires.
        """
        try:
            inhibition = state.get("inhibition") if isinstance(state.get("inhibition"), dict) else {}
            stamp = float(inhibition.get(mode, 0.0) or 0.0)
        except Exception:
            stamp = 0.0
        if stamp <= 0:
            return 1.0
        tau = self._autonomy_loop_param(
            "autonomy_loop_ior_seconds", AUTONOMY_LOOP_IOR_SECONDS,
            AUTONOMY_LOOP_IOR_MIN, AUTONOMY_LOOP_IOR_MAX)
        delta = max(0.0, float(now) - stamp)
        return _clip(1.0 - math.exp(-delta / max(1.0, tau)), 0.0, 1.0)

    def _autonomy_loop_goal_progress(self) -> float:
        """Progress proxy for the engaged goal (0 when there is no goal)."""
        try:
            goals = [g for g in (getattr(self, "goals", []) or [])
                     if isinstance(g, dict)]
            if not goals:
                return 0.0
            focus = str(getattr(self, "goal_focus", "") or "")
            chosen = next((g for g in goals
                           if str(g.get("key") or "") == focus), None)
            if chosen is None:
                chosen = max(goals, key=lambda g: self._loop_num(
                    g.get("priority"), 0.5, 0.0, 1.0))
            return self._loop_num(chosen.get("progress"), 0.0, 0.0, 1.0)
        except Exception:
            return 0.0

    def _autonomy_loop_noise_chaos(self) -> float:
        """Normalized 5-channel noise chaos (same scale as task-15)."""
        try:
            total = sum(abs(self._loop_num((getattr(self, "noise", {}) or {}).get(k),
                                           0.0, -NOISE_CLAMP, NOISE_CLAMP))
                        for k in ("stress", "energy", "social", "attention", "valence"))
            return _clip(total / (5.0 * NOISE_CLAMP), 0.0, 1.0)
        except Exception:
            return 0.0

    def _autonomy_loop_open_loops(self) -> tuple:
        """(due_count, delay_min proxy) for the open-loop candidate."""
        due = 0
        delay_min = 0.0
        try:
            for loop in (getattr(self, "open_loops", []) or []):
                if not isinstance(loop, dict):
                    continue
                if str(loop.get("status") or "open") != "open":
                    continue
                hint = str(loop.get("due_hint") or "")
                if hint == "soon":
                    due += 1
                    delay_min = max(delay_min, 60.0)
                elif hint == "tomorrow":
                    due += 1
                    delay_min = max(delay_min, 1440.0)
        except Exception:
            return 0, 0.0
        return due, delay_min

    def _autonomy_loop_candidates(self, relationship, now: float, state: dict) -> list:
        """Build ≤6 deterministic candidates (spec §7.3); values per §2–§6."""
        rel = relationship if isinstance(relationship, dict) else {}
        rel_state = rel.get("state") if isinstance(rel.get("state"), dict) else {}
        attachment = rel.get("attachment") if isinstance(rel.get("attachment"), dict) else {}
        absence = rel.get("absence") if isinstance(rel.get("absence"), dict) else {}
        closeness = self._loop_num(rel_state.get("closeness"), 0.5)
        conflict = self._loop_num(rel_state.get("conflict"), 0.0)
        attachment_safe = self._loop_num(attachment.get("safe"), 0.5)
        closeness_eff = _clip(0.70 * closeness + 0.30 * attachment_safe, 0.0, 1.0)
        gap_days = self._loop_num(absence.get("gap_days"), 0.0, 0.0, 365.0)
        appraisal = getattr(self, "appraisal", {}) if isinstance(getattr(self, "appraisal", None), dict) else {}
        novelty = self._loop_num(appraisal.get("novelty"), 0.0)
        goal_rel = self._loop_num(appraisal.get("goal_relevance"), 0.0)
        intensity = self._loop_num(self._intensity(), 0.0)
        stress = self._loop_num(getattr(self, "stress", 0.0), 0.0)
        boredom = self._loop_num(getattr(self, "boredom", 0.0), 0.0)
        novelty_need = self._loop_num(getattr(self, "novelty_need", 0.5), 0.5)
        chaos = self._autonomy_loop_noise_chaos()
        due_count, loop_delay = self._autonomy_loop_open_loops()
        loop_progress = 0.5 if due_count else 0.0
        goal_progress = self._autonomy_loop_goal_progress()
        debt = self._loop_num(state.get("effort_debt"), 0.0, 0.0,
                              AUTONOMY_LOOP_DEBT_MAX)
        k = self._autonomy_loop_param("autonomy_loop_k_delay", AUTONOMY_LOOP_K_DELAY,
                                      AUTONOMY_LOOP_K_MIN, AUTONOMY_LOOP_K_MAX)
        c0 = self._autonomy_loop_param("autonomy_loop_c0", AUTONOMY_LOOP_C0, 0.0, 1.0)
        c1 = self._autonomy_loop_param("autonomy_loop_c1", AUTONOMY_LOOP_C1, 0.0, 1.0)
        c2 = self._autonomy_loop_param("autonomy_loop_c2", AUTONOMY_LOOP_C2, 0.0, 1.0)
        w = AUTONOMY_LOOP_WEIGHTS
        # (mode, features, goal_progress|None, delay_min)
        rows = [
            ("reach_out",
             {"novelty": 0.0, "goal": 0.0, "relation": closeness_eff,
              "affect": intensity, "noise": chaos}, None, gap_days * 1440.0),
            ("explore",
             {"novelty": max(novelty_need, boredom), "goal": 0.0, "relation": 0.0,
              "affect": 0.5 * intensity, "noise": 0.5 * chaos}, None, 0.0),
            ("engage",
             {"novelty": novelty, "goal": goal_rel,
              "relation": 0.5 * closeness_eff, "affect": intensity,
              "noise": 0.3 * chaos}, goal_progress, 0.0),
            ("wait",
             {"novelty": 0.0, "goal": 0.0, "relation": 0.0,
              "affect": 0.0, "noise": 0.0}, None, 0.0),
            ("share",
             {"novelty": 0.0, "goal": loop_progress, "relation": closeness_eff,
              "affect": 0.3 * intensity, "noise": 0.2 * chaos},
             loop_progress, loop_delay),
            ("withdraw",
             {"novelty": 0.0, "goal": 0.0,
              "relation": _clip(max(conflict, 1.0 - closeness_eff), 0.0, 1.0),
              "affect": stress, "noise": chaos}, None, 0.0),
        ]
        out = []
        for mode, features, progress, delay_min in rows[:AUTONOMY_LOOP_CANDIDATE_MAX]:
            salience = sum(w[key] * self._loop_num(features.get(key), 0.0)
                           for key in w)
            salience = _clip(salience, 0.0, 1.0)
            ior = self._autonomy_loop_ior_factor(state, mode, now)
            salience = _clip(salience * ior, 0.0, 1.0)
            if progress is None:
                goal_gain = 1.0
            else:
                goal_gain = _clip(0.8 + 0.4 * self._loop_num(progress, 0.0),
                                  0.8, 1.4)
            discount = _clip(1.0 / (1.0 + k * max(0.0, self._loop_num(
                delay_min, 0.0, 0.0, 1440.0))), 0.05, 1.0)
            effort = AUTONOMY_LOOP_EFFORT.get(mode, 0.5)
            cost = c0 + c1 * effort + c2 * debt
            value = _clip(salience * goal_gain * discount - cost,
                          AUTONOMY_LOOP_VALUE_MIN, AUTONOMY_LOOP_VALUE_MAX)
            out.append({
                "mode": mode,
                "source": ("readiness" if mode == "reach_out" else
                           "curiosity" if mode == "explore" else
                           "context" if mode == "engage" else
                           "fallback" if mode == "wait" else
                           "open_loop" if mode == "share" else "stress"),
                "salience": round(salience, 4),
                "goal_gain": round(goal_gain, 4),
                "discount": round(discount, 4),
                "effort": round(effort, 4),
                "cost": round(cost, 4),
                "value": round(value, 4),
            })
        return out

    def autonomy_loop_tick(self, relationship=None, now=None,
                           private_chat: bool = True) -> dict:
        """One deterministic minimal-autonomy-loop tick (L1, spec §7.1).

        Deterministic arbitration inspired by biased competition / saliency
        WTA+IOR / goal gradient / hyperbolic delay discounting / effort cost /
        global-workspace-style single-token broadcast. This is an engineering
        control loop, NOT an implementation of consciousness or a GWT.

        Default OFF returns {"enabled": False} without creating state or
        touching any other field. Only one token is broadcast per tick; the
        caller decides whether anything is sent (token-only default).
        """
        if not getattr(self, "autonomy_loop_enabled", False):
            return {"enabled": False}
        try:
            current = float(now if now is not None else time.time())
        except Exception:
            current = time.time()
        state = self.autonomy_loop if isinstance(
            getattr(self, "autonomy_loop", None), dict) else None
        if state is None:
            state = self._autonomy_loop_default_state(current)
            self.autonomy_loop = state
        base = self._autonomy_loop_default_state(current)
        for key, value in base.items():
            if key not in state or not isinstance(state.get(key), type(value)):
                state[key] = value
        for key in base["stats"]:
            if key not in state["stats"]:
                state["stats"][key] = 0
        state["enabled"] = True
        try:
            state["tick"] = int(state.get("tick", 0) or 0) + 1
        except Exception:
            state["tick"] = 1
        stats = state["stats"]
        stats["ticks"] = int(stats.get("ticks", 0) or 0) + 1
        budget = state["budget"]
        day = time.strftime("%Y-%m-%d", time.localtime(current))
        if str(budget.get("day") or "") != day:
            budget["day"] = day
            budget["used"] = 0
        # --- gates (spec §7.1 order: group -> quiet -> cooldown -> daily cap)
        blocked = ""
        if not private_chat:
            blocked = "group"
            stats["blocked_group"] = int(stats.get("blocked_group", 0) or 0) + 1
        else:
            hour = time.localtime(current).tm_hour
            if AUTONOMY_QUIET_START_HOUR <= hour < AUTONOMY_QUIET_END_HOUR:
                blocked = "quiet"
                stats["blocked_quiet"] = int(stats.get("blocked_quiet", 0) or 0) + 1
            else:
                last_ts = self._loop_num(budget.get("last_action_ts"), 0.0,
                                         0.0, 10 ** 12)
                if last_ts > 0 and (current - last_ts) < AUTONOMY_COOLDOWN_SECONDS:
                    blocked = "cooldown"
                    stats["blocked_cooldown"] = int(
                        stats.get("blocked_cooldown", 0) or 0) + 1
                elif int(budget.get("used", 0) or 0) >= AUTONOMY_DAILY_CAP:
                    blocked = "cap"
                    stats["blocked_cap"] = int(stats.get("blocked_cap", 0) or 0) + 1
        if blocked:
            state["ignition"] = False
            state["winner"] = None
            state["workspace_token"] = ""
            state["candidates"] = []
            state["updated_ts"] = round(current, 3)
            return {"enabled": True, "blocked": blocked, "ignition": False,
                    "tick": state["tick"], "candidates": [], "stats": dict(stats)}
        # --- effort-debt recovery on every active tick (bounded)
        state["effort_debt"] = round(_clip(
            self._loop_num(state.get("effort_debt"), 0.0, 0.0,
                           AUTONOMY_LOOP_DEBT_MAX) - AUTONOMY_LOOP_DEBT_RECOVERY,
            0.0, AUTONOMY_LOOP_DEBT_MAX), 6)
        # --- candidates + values
        candidates = self._autonomy_loop_candidates(relationship, current, state)
        state["candidates"] = [dict(row) for row in candidates]
        if not candidates:
            stats["no_ignition"] = int(stats.get("no_ignition", 0) or 0) + 1
            state["ignition"] = False
            state["winner"] = None
            state["workspace_token"] = ""
            state["updated_ts"] = round(current, 3)
            return {"enabled": True, "blocked": "", "ignition": False,
                    "tick": state["tick"], "candidates": [], "stats": dict(stats)}
        theta = self._autonomy_loop_param(
            "autonomy_loop_theta_ig", AUTONOMY_LOOP_THETA_IG,
            AUTONOMY_LOOP_THETA_MIN, AUTONOMY_LOOP_THETA_MAX)
        margin_min = self._autonomy_loop_param(
            "autonomy_loop_margin", AUTONOMY_LOOP_MARGIN,
            AUTONOMY_LOOP_MARGIN_MIN, AUTONOMY_LOOP_MARGIN_MAX)
        inhibition = state["inhibition"] if isinstance(
            state.get("inhibition"), dict) else {}
        # Refractory: a mode broadcast within the last 60 s cannot win again.
        eligible = []
        for row in candidates:
            stamp = self._loop_num(inhibition.get(row["mode"]), 0.0, 0.0, 10 ** 12)
            if stamp > 0 and (current - stamp) < AUTONOMY_LOOP_REFRACTORY_SECONDS:
                continue
            eligible.append(row)
        margin = 0.0
        ignition = False
        winner = None
        if eligible:
            ranked = sorted(
                eligible, key=lambda row: (-float(row["value"]),
                                           AUTONOMY_LOOP_MODES.index(row["mode"])))
            winner = ranked[0]
            second = float(ranked[1]["value"]) if len(ranked) > 1 else \
                AUTONOMY_LOOP_VALUE_MIN
            margin = float(winner["value"]) - second
            ignition = bool(float(winner["value"]) >= theta
                            and margin >= margin_min)
        if not ignition:
            stats["no_ignition"] = int(stats.get("no_ignition", 0) or 0) + 1
            state["ignition"] = False
            state["winner"] = None
            state["workspace_token"] = ""
            state["updated_ts"] = round(current, 3)
            return {"enabled": True, "blocked": "", "ignition": False,
                    "tick": state["tick"], "candidates": [dict(r) for r in candidates],
                    "theta_ig": round(theta, 4), "margin": round(margin, 4),
                    "stats": dict(stats)}
        # --- broadcast exactly one workspace token (token-only; no send here)
        mode = str(winner["mode"])[:AUTONOMY_LOOP_WORKSPACE_MAX]
        state["workspace_token"] = mode
        state["winner"] = {"mode": mode, "value": round(float(winner["value"]), 4),
                           "ts": round(current, 3)}
        state["ignition"] = True
        inhibition[mode] = round(current, 3)
        state["inhibition"] = dict(sorted(
            inhibition.items(), key=lambda kv: self._loop_num(
                kv[1], 0.0, 0.0, 10 ** 12), reverse=True
        )[:AUTONOMY_LOOP_CANDIDATE_MAX])
        # --- feedback EMA (record-only; no learning gradient / no next-tick use)
        ema = state["value_ema"] if isinstance(state.get("value_ema"), dict) else {}
        prev = self._loop_num(ema.get(mode), 0.0, AUTONOMY_LOOP_VALUE_MIN,
                              AUTONOMY_LOOP_VALUE_MAX)
        outcome = _clip(float(winner["value"]), AUTONOMY_LOOP_VALUE_MIN,
                        AUTONOMY_LOOP_VALUE_MAX)
        ema[mode] = round(_clip(
            AUTONOMY_LOOP_EMA_KEEP * prev
            + (1.0 - AUTONOMY_LOOP_EMA_KEEP) * outcome,
            AUTONOMY_LOOP_VALUE_MIN, AUTONOMY_LOOP_VALUE_MAX), 6)
        state["value_ema"] = {str(k)[:AUTONOMY_LOOP_WORKSPACE_MAX]: v
                              for k, v in list(ema.items())[
                                  :AUTONOMY_LOOP_CANDIDATE_MAX]}
        state["effort_debt"] = round(_clip(
            self._loop_num(state.get("effort_debt"), 0.0, 0.0,
                           AUTONOMY_LOOP_DEBT_MAX) + AUTONOMY_LOOP_DEBT_STEP,
            0.0, AUTONOMY_LOOP_DEBT_MAX), 6)
        budget["last_action_ts"] = round(current, 3)
        budget["used"] = int(budget.get("used", 0) or 0) + 1
        stats["ignitions"] = int(stats.get("ignitions", 0) or 0) + 1
        stats["executed"] = int(stats.get("executed", 0) or 0) + 1
        state["updated_ts"] = round(current, 3)
        return {"enabled": True, "blocked": "", "ignition": True,
                "tick": state["tick"], "workspace_token": mode,
                "winner": dict(state["winner"]),
                "candidates": [dict(r) for r in candidates],
                "theta_ig": round(theta, 4), "margin": round(margin, 4),
                "effort_debt": state["effort_debt"],
                "value_ema": dict(state["value_ema"]), "stats": dict(stats)}

    def refusal_posture(self, relationship=None) -> dict:
        """task-35 L1: deterministic refusal posture -> brevity posture.

        Reads boundary_pressure/trust/conflict only; returns a label used by L2
        rendering and the proactive gate. Never decides by itself whether a reply
        is sent here.
        """
        rel = relationship if isinstance(relationship, dict) else {}
        state = rel.get("state") if isinstance(rel.get("state"), dict) else {}
        try:
            protocol = relationship_meta.refusal_protocol({
                "boundary_pressure": float(getattr(self, "boundary_pressure", 0.0) or 0.0),
                "trust": float(state.get("trust", 0.5) or 0.5),
                "conflict": float(state.get("conflict", 0.0) or 0.0),
            })
        except Exception:
            protocol = {"mode": "comply"}
        mode = str(protocol.get("mode") or "comply")
        brevity = "short" if mode == "decline" else (
            "medium" if mode == "negotiate" else "normal")
        _b = getattr(self, "_core_bridge", None)
        if _b is not None:
            try:
                _b.record_episode("guard:refusal", "blocked", 0.0, {"reason": str(locals().get("mode", ""))[:80]})
            except Exception:
                pass
        return {"mode": mode, "brevity": brevity}

    def evaluate_reply_consistency(self, text, now=None) -> dict:
        """task-36: deterministic reply/intent consistency (0..1, read-only).

        Heuristic checks only (length bands vs labels need/expression). It never
        rewrites the reply and is only stored when reply_consistency_enabled.
        """
        value = str(text or "").strip()
        checks = []
        score = 1.0
        try:
            labels = getattr(self, "labels", {}) or {}
            need = str(labels.get("need") or "talk")
            expression = str(labels.get("expression") or "normal")
            if not value:
                score = 0.0
                checks.append("empty")
            else:
                length = len(value)
                if length > 240:
                    score -= 0.20
                    checks.append("too_long")
                if length < 2:
                    score -= 0.30
                    checks.append("too_short")
                if need == "space" and length > 60:
                    score -= 0.20
                    checks.append("space_but_long")
                if need == "talk" and length < 4:
                    score -= 0.10
                    checks.append("talk_but_short")
                if expression == "normal" and value.count("！") >= 4:
                    score -= 0.10
                    checks.append("too_excited")
        except Exception:
            checks.append("error")
        try:
            stamp = float(now if now is not None else time.time())
        except Exception:
            stamp = time.time()
        return {"score": round(_clip(score, 0.0, 1.0), 4),
                "length": len(value), "checks": checks[:6],
                "ts": round(stamp, 3)}

    # ---- task-43: L1 deterministic "thinking physiology" scalars ----
    def blend_prior(self, new_value, prior, anchor=None) -> float:
        """Tversky 1974 / Nickerson 1998 anchor-weighted update."""
        try:
            new = float(new_value)
            old = float(prior)
        except Exception:
            return _clip(new_value)
        try:
            a = float(anchor if anchor is not None else self.anchor_weight)
        except Exception:
            a = 0.25
        a = max(0.0, min(0.9, a))
        return _clip((1.0 - a) * new + a * old, -1.0, 1.0)

    def update_conflict_ema(self, text, *, novelty=0.0, correction=False,
                            contradiction=False) -> dict:
        """Botvinick 2001 proxy: contradiction/correction/instruction conflict EMA."""
        value = str(text or "")
        cues = ("不对", "不是", "你错了", "矛盾", "但是", "可是", "然而",
                "说错", "纠正", "改口", "冲突", "说反")
        hits = sum(1 for cue in cues if cue in value)
        corr = 1.0 if (correction or any(w in value for w in ("不对", "你错了", "纠正", "改口"))) else 0.0
        contrad = 1.0 if (contradiction or any(w in value for w in ("矛盾", "不是这样", "说错了"))) else 0.0
        nov = _clip(novelty, 0.0, 1.0)
        delta = _clip(0.45 * min(1.0, hits / 2.0) + 0.30 * corr
                      + 0.15 * contrad + 0.10 * nov, 0.0, 1.0)
        self.conflict_ema = _clip(0.80 * float(getattr(self, "conflict_ema", 0.0)) + 0.20 * delta,
                                  0.0, 1.0)
        high = self.conflict_ema >= 0.60
        if high and getattr(self, "conflict_gate_enabled", False):
            state = getattr(self, "autonomy_loop", None)
            if isinstance(state, dict):
                try:
                    debt = float(state.get("effort_debt", 0.0) or 0.0)
                    state["effort_debt"] = round(_clip(debt + 0.02, 0.0, 0.60), 4)
                except Exception:
                    pass
        return {"conflict_ema": round(self.conflict_ema, 4),
                "delta": round(delta, 4), "high": bool(high)}

    def update_rumination_ema(self, text, *, emotion="neutral", intensity=0.0,
                              novelty=0.0) -> dict:
        """Nolen-Hoeksema 1991 proxy: repeated negative topic EMA (bounded)."""
        value = str(text or "")
        negative = (str(emotion or "") in ("sadness", "anger", "fear", "loneliness")
                    or any(w in value for w in ("难受", "难过", "烦", "焦虑", "委屈",
                                                "不想", "讨厌", "崩溃", "累")))
        topic = value[:40] if negative else ""
        repeat = False
        if negative and topic and self._last_neg_topic:
            repeat = memory_meta.text_similarity(topic, self._last_neg_topic) >= 0.5
        if negative:
            self._neg_repeat = (int(getattr(self, "_neg_repeat", 0) or 0) + 1
                                if repeat else 1)
            self._last_neg_topic = topic
            inc = 0.20 if repeat else 0.10
            add = inc * (0.5 + 0.5 * _clip(intensity, 0.0, 1.0))
            self.rumination_ema = _clip(float(getattr(self, "rumination_ema", 0.0)) + add,
                                        0.0, 1.0)
            # §6/LIT: 3 consecutive same-topic negative rounds -> suppression mark.
            if int(getattr(self, "_neg_repeat", 0) or 0) >= 3:
                self.rumination_suppress = True
        else:
            decay = 0.70 if _clip(novelty, 0.0, 1.0) >= 0.50 else 0.85
            self.rumination_ema = _clip(
                float(getattr(self, "rumination_ema", 0.0)) * decay, 0.0, 1.0)
            self._neg_repeat = 0
            self.rumination_suppress = False
        if (getattr(self, "rumination_effect_enabled", False)
                and self.rumination_ema > 0.0):
            shift = min(0.12, 0.12 * self.rumination_ema)
            self.v = _clip(self.v - shift, -1.0, 1.0)
        return {"rumination_ema": round(self.rumination_ema, 4),
                "repeat": bool(repeat), "repeat_count": int(self._neg_repeat)}

    @staticmethod
    def detect_identity_threat(text) -> bool:
        """Swann 1987 proxy: deterministic self/role/narrative conflict cues."""
        value = str(text or "")
        cues = ("你不是她", "你不是你", "不配", "工具", "废物", "假的", "装的",
                "人设", "角色", "根本不懂", "不是真的", "换个人", "你变了")
        return any(cue in value for cue in cues)

    def apply_identity_threat(self, text) -> bool:
        """task-43 (default OFF): identity threat -> bounded stress bump (<=0.08)."""
        if not getattr(self, "identity_threat_stress_enabled", False):
            return False
        if not self.detect_identity_threat(text):
            return False
        self.stress = _clip(float(getattr(self, "stress", 0.0)) + 0.06, 0.0, 1.0)
        _b = getattr(self, "_core_bridge", None)
        if _b is not None and getattr(_b, "enabled", False) and str(getattr(_b, "mode", "off")) == "primary":
            try:
                import hashlib
                _b.identity_signal({"level": "high", "kind": "identity_conflict", "text_hash": hashlib.sha1(str(text or "").encode("utf-8")).hexdigest()[:12]})
            except Exception:
                pass
        return True

    def autonomy_state(self, relationship=None, now=None, persist: bool = True) -> dict:
        """L1 task-15: deterministic noise -> autonomy readiness.

        Inputs are all L1 state: 5 noise channels, echo_trace, stress_load
        (stress + allostatic), homeostasis drive deviation (L_int), persona
        autonomy_gain, and the relationship record passed in as data.
        Outputs are bounded: threshold ∈ [0.55, 0.90], max_chars ∈ [60, 240],
        impulse ∈ [0, 1]. P1-G11: threshold follows an EMA of past impulses plus
        a ready hysteresis band, not the current impulse alone. Default OFF
        returns {"enabled": False} without computing anything.
        """
        if not getattr(self, "autonomy_enabled", False):
            return {"enabled": False}
        try:
            current = float(now if now is not None else time.time())
        except Exception:
            current = time.time()
        try:
            noise = {k: float(self.noise.get(k, 0.0) or 0.0)
                     for k in ("stress", "energy", "social", "attention", "valence")}
        except Exception:
            noise = {}
        chaos = _clip(sum(abs(v) for v in noise.values()) / (5.0 * NOISE_CLAMP), 0.0, 1.0)
        # Stage-2: echo/ripple/spiking all feed the readiness input, not just
        # echo_trace. Bounded weighted mix (deterministic).
        try:
            _echo_raw = abs(float(getattr(self, "echo_trace", 0.0) or 0.0))
            _ripple = float((getattr(self, "ripple", {}) or {}).get("energy", 0.0) or 0.0)
            _spiking = float((getattr(self, "spiking", {}) or {}).get("rate", 0.0) or 0.0)
            echo = _clip(0.60 * _echo_raw + 0.20 * _ripple + 0.20 * min(1.0, _spiking), 0.0, 1.0)
        except Exception:
            echo = 0.0
        try:
            stress_load = _clip(
                0.6 * float(self.stress)
                + 0.4 * float(getattr(self, "allostatic_load", 0.0)), 0.0, 1.0)
        except Exception:
            stress_load = 0.0
        try:
            homeo = self.homeostasis if isinstance(self.homeostasis, dict) else {}
            drive_dev = _clip(float(homeo.get("L_int", 0.0) or 0.0), 0.0, 1.0)
        except Exception:
            drive_dev = 0.0
        rel = relationship if isinstance(relationship, dict) else {}
        rel_state = rel.get("state") if isinstance(rel.get("state"), dict) else {}
        try:
            trust = _clip(float(rel_state.get("trust", 0.5) or 0.5), 0.0, 1.0)
        except Exception:
            trust = 0.5
        try:
            closeness = _clip(float(rel_state.get("closeness", 0.5) or 0.5), 0.0, 1.0)
        except Exception:
            closeness = 0.5
        # Stage-2: attachment is an L1 input (not dashboard-only anymore).
        try:
            _attachment = rel.get("attachment") if isinstance(rel.get("attachment"), dict) else {}
            attachment_safe = _clip(float(_attachment.get("safe", 0.5) or 0.5), 0.0, 1.0)
        except Exception:
            attachment_safe = 0.5
        closeness_eff = _clip(0.70 * closeness + 0.30 * attachment_safe, 0.0, 1.0)
        try:
            gain = _clip(float((getattr(self, "profile", {}) or {}).get(
                "autonomy_gain", 1.0) or 0.0), 0.0, 1.5)
        except Exception:
            gain = 1.0
        w = AUTONOMY_WEIGHTS
        impulse = _clip(
            w["chaos"] * chaos + w["echo"] * echo + w["stress_load"] * stress_load
            + w["drive_dev"] * drive_dev + w["distrust"] * (1.0 - trust)
            + w["distance"] * (1.0 - closeness_eff), 0.0, 1.0)
        # P1-G10: autonomy_gain (persona profile) is now a real consumer.
        impulse = _clip(impulse * gain, 0.0, 1.0)
        prev = self._proactive_autonomy if isinstance(self._proactive_autonomy, dict) else {}
        try:
            prev_ema = float(prev.get("impulse_ema", impulse))
        except Exception:
            prev_ema = impulse
        impulse_ema = _clip(0.8 * prev_ema + 0.2 * impulse, 0.0, 1.0)
        # P1-G11: threshold uses the EMA (history), so it does not collapse to a
        # function of the current impulse; ready uses a small hysteresis band.
        target = _clip(0.82 - 0.30 * impulse_ema,
                       AUTONOMY_THRESHOLD_MIN, AUTONOMY_THRESHOLD_MAX)
        prev_ready = bool(prev.get("ready", False))
        # Explicit hysteresis: enter at 0.72, exit only below 0.60.
        if prev_ready:
            ready = impulse >= AUTONOMY_EXIT
        else:
            ready = impulse >= AUTONOMY_ENTER
        max_chars = int(round(_clip(60.0 + 180.0 * impulse,
                                    AUTONOMY_MAX_CHARS_MIN, AUTONOMY_MAX_CHARS_MAX)))
        result = {
            "enabled": True,
            "threshold": round(target, 4),
            "max_chars": max_chars,
            "impulse": round(impulse, 4),
            "impulse_ema": round(impulse_ema, 4),
            "ready": bool(ready),
            "chaos": round(chaos, 4),
            "gain": round(gain, 3),
            "noise_seed": int(getattr(self, "_noise_seed", 0) or 0),
            "sources": {
                "noise": {k: round(v, 4) for k, v in noise.items()},
                "echo_trace": round(echo, 4),
                "stress_load": round(stress_load, 4),
                "drive_dev": round(drive_dev, 4),
                "trust": round(trust, 4),
                "closeness": round(closeness, 4),
                "attachment_safe": round(attachment_safe, 4),
                "closeness_effective": round(closeness_eff, 4),
                "autonomy_gain": round(gain, 3),
            },
            "updated_ts": round(current, 3),
            "last_sent_ts": float(prev.get("last_sent_ts", 0.0) or 0.0),
            "sent_count": int(prev.get("sent_count", 0) or 0),
            "sent_day": str(prev.get("sent_day") or ""),
            "cooldown_seconds": AUTONOMY_COOLDOWN_SECONDS,
            "daily_cap": AUTONOMY_DAILY_CAP,
            "quiet_hours": [AUTONOMY_QUIET_START_HOUR, AUTONOMY_QUIET_END_HOUR],
        }
        if persist:
            self._proactive_autonomy = result
        return dict(result)

    def snapshot(self) -> dict:
        self._decay_to_now()
        out = {"v": round(self.v, 4), "a": round(self.a, 4),
                "d": round(self.d, 4), "social": round(self.social, 4),
                "stress": round(self.stress, 4), "energy": round(self.energy, 4),
                "trust": round(self.trust, 4), "ticks": self.ticks,
                "noise": {k: round(float(v), 3) for k, v in self.noise.items()},
                "echo": round(self.echo, 4), "echo_trace": round(self.echo_trace, 4),
                "ripple": dict(self.ripple), "spiking": dict(self.spiking),
                "reflection": dict(self.reflection),
                "momentum": dict(self.momentum),
                "appraisal": dict(self.appraisal),
                "stimuli": list(self.stimuli)[-8:],
                "history": list(self.history)[-80:],
                "open_loops": [dict(x) for x in (getattr(self, "open_loops", []) or [])[-20:]
                               if isinstance(x, dict)],
                "open_loops_due": sum(1 for _loop in (getattr(self, "open_loops", []) or [])
                                      if isinstance(_loop, dict)
                                      and _loop.get("status") == "open"
                                      and str(_loop.get("due_hint") or "") in ("soon", "tomorrow")),
                "goal_focus": self.goal_focus,
                "coping": round(float((self.appraisal or {}).get("coping", 0.5)), 3),
                "event_anchors": list(self.event_anchors)[-5:],
                "opponent": dict(self.opponent),
                "autobiography": list(self.autobiography)[-8:],
                "regulation_stats": dict(self.regulation_stats),
                "attention": round(float(self.attention), 3),
                "novelty_need": round(float(getattr(self, "novelty_need", 0.5)), 3),
                "boredom": round(float(getattr(self, "boredom", 0.0)), 3),
                "circadian_alertness": round(float(getattr(self, "circadian_alertness", 0.5)), 3),
                "allostatic_load": round(float(getattr(self, "allostatic_load", 0.0)), 3),
                "homeostasis": dict(getattr(self, "homeostasis", {}) or {}),
                "boundary_pressure": round(float(getattr(self, "boundary_pressure", 0.0)), 3),
                "refusal_readiness": round(float(getattr(self, "refusal_readiness", 0.0)), 3),
                "conflict_ema": round(float(getattr(self, "conflict_ema", 0.0) or 0.0), 4),
                "rumination_ema": round(float(getattr(self, "rumination_ema", 0.0) or 0.0), 4),
                "anchor_weight": round(float(getattr(self, "anchor_weight", 0.25) or 0.25), 4),
                "rumination_suppress": bool(getattr(self, "rumination_suppress", False)),
                "user_trust_seeded": bool(getattr(self, "_user_trust_seeded", False)),
                "user_trust_seed_delta": round(
                    float(getattr(self, "_user_trust_seed_delta", 0.0) or 0.0), 4),
                "interpersonal": {k: round(float(v), 4) for k, v in (getattr(self, "interpersonal", {}) or {}).items()},
                "daily_digests": [dict(x) for x in (getattr(self, "daily_digests", []) or [])[-30:]],
                "meta_emotion": self.meta_emotion,
                "goals": [{"key": g.get("key"), "name": g.get("name"), "horizon": g.get("horizon"),
                           "progress": round(float(g.get("progress", 0) or 0), 3),
                           "priority": round(float(g.get("priority", 0.5) or 0.5), 3),
                           "last_update": round(float(g.get("last_update", 0.0) or 0.0), 3)}
                          for g in self.goals],
                "goal_conflict": list(self.goal_conflict),
                "goal_scores": dict(getattr(self, "goal_scores", {}) or {}),
                "self_timeline": dict(self.self_timeline),
                "reflection_tree": self._reflection_tree_view(),
                "spectrum_probs": self._spectrum_probs(),
                "sec": dict(self.sec),
                "core_self": self.core_self,
                "narrative_self": self.narrative_self,
                "plutchik": PLUTCHIK_WHEEL,
                "compound": self.compound,
                "regulation": self.regulation,
                "spectrum": self._spectrum(),
                "spectrum_calibration": dict(getattr(self, "_spectrum_calibration_meta", {}) or {}),
                "labels": dict(getattr(self, "labels", {}) or {}),
                # Task-15: exactly one new top-level field; default OFF keeps
                # the minimal marker and computes no readiness.
                "learning": dict(self._learning),
                "proactive_autonomy": (dict(self._proactive_autonomy)
                                       if getattr(self, "autonomy_enabled", False)
                                       and isinstance(getattr(self, "_proactive_autonomy", None), dict)
                                       else {"enabled": False})}
        # Task-28: persisted ONLY while the loop is enabled. Default OFF is a
        # true no-op: the state file stays byte-identical (key absent entirely).
        if (getattr(self, "autonomy_loop_enabled", False)
                and isinstance(getattr(self, "autonomy_loop", None), dict)):
            out["autonomy_loop"] = dict(self.autonomy_loop)
        # task-36: opt-in read-only reply-consistency projection; default OFF
        # keeps the state file byte-identical to 1.2.99.
        if (getattr(self, "reply_consistency_enabled", False)
                and isinstance(getattr(self, "reply_consistency", None), dict)):
            out["reply_consistency"] = dict(self.reply_consistency)
        # 1.3.1: opt-in read-only projections (default OFF keeps the state file
        # byte-identical to 1.3.0). thought_note is NEVER persisted.
        if (getattr(self, "think_selfcheck_trace_enabled", False)
                and isinstance(getattr(self, "reverse_check", None), dict)):
            out["reverse_check"] = dict(self.reverse_check)
        if (getattr(self, "token_budget_enabled", False)
                and isinstance(getattr(self, "token_usage", None), dict)):
            out["token_usage"] = dict(self.token_usage)
        if (getattr(self, "path_monitor_enabled", False)
                and isinstance(getattr(self, "path_monitor", None), dict)):
            out["path_monitor"] = dict(self.path_monitor)
        if (getattr(self, "sycophancy_check_enabled", False)
                and isinstance(getattr(self, "sycophancy_check", None), dict)):
            out["sycophancy_check"] = dict(self.sycophancy_check)
        if any(getattr(self, k, False) for k in (
                "learning_bandit_enabled", "learning_relationship_enabled",
                "learning_worthiness_enabled")) and isinstance(
                getattr(self, "learning_state", None), dict):
            out["learning_state"] = dict(self.learning_state)
        if (getattr(self, "relationship_chain_enabled", False)
                or getattr(self, "gottman_enabled", False)) and isinstance(
                getattr(self, "relationship_dynamics", None), dict):
            out["relationship_dynamics"] = dict(self.relationship_dynamics)
        if (getattr(self, "big5_effect_enabled", False)
                and isinstance(getattr(self, "big5_effect", None), dict)):
            out["big5_effect"] = dict(self.big5_effect)
        if (getattr(self, "injection_trace_enabled", False)
                and isinstance(getattr(self, "injection_trace", None), dict)):
            out["injection_trace"] = dict(self.injection_trace)
        return out


class _AutonomySendTarget:
    """Minimal event-like send target for the P0-1 background generator."""

    def __init__(self, plugin, umo, sender_id="", sender_name="", private=True):
        self._plugin = plugin
        self.unified_msg_origin = str(umo or "")
        self._sender_id = str(sender_id or "")
        self._sender_name = str(sender_name or "")
        self._private = bool(private)

    def is_private_chat(self):
        return self._private

    def get_sender_id(self):
        return self._sender_id

    def get_sender_name(self):
        return self._sender_name

    async def send(self, chain):
        return await self._plugin.context.send_message(self.unified_msg_origin, chain)


@register("astrbot_plugin_biocore", "Johnhmzm", "拟态生物情绪核心：注入表达意图，不生成回复", "1.3.5")
class BioCorePlugin(Star):
    def __init__(self, context: Context, config=None):
        super().__init__(context)
        self.config = config or {}
        self._core_bridge = None
        self._core_shadow_state = None
        try:
            self._core_bridge = CoreBridge(self.config, DATA_DIR) if CoreBridge is not None else None
        except Exception:
            self._core_bridge = None
        self.enabled = bool(self.config.get("enabled", True))
        self.inject_intent = bool(self.config.get("inject_intent", True))
        try:
            self.summary_max_chars = max(0, int(self.config.get("summary_max_chars", 0) or 0))
        except Exception:
            self.summary_max_chars = 0
        self.prompt_rules_enabled = bool(self.config.get("prompt_rules_enabled", True))
        self.enhancement_sidecar = bool(self.config.get("enhancement_sidecar", False))
        self.archive_batch = bool(self.config.get("archive_batch", True))
        self.bc_prompt_mode = str(self.config.get("bc_prompt_mode", "telemetry") or "telemetry").strip().lower()
        if self.bc_prompt_mode not in ("telemetry", "semantic", "text"):
            self.bc_prompt_mode = "telemetry"
        self.bc_text_legend_enabled = bool(
            self.config.get("bc_text_legend_enabled", True))
        self.voice_transcription_enabled = bool(self.config.get("voice_transcription_enabled", True))
        try:
            self.event_summary_delay_hours = max(0, int(self.config.get("event_summary_delay_hours", 6) or 6))
        except Exception:
            self.event_summary_delay_hours = 6
        self.proactive_reply = bool(self.config.get("proactive_reply", False))
        # Task-15: noise -> autonomy. Both default false; when off no readiness
        # is computed, no background task starts, and no message can be sent.
        self.proactive_autonomy = bool(self.config.get("proactive_autonomy", False))
        self.proactive_send = bool(self.config.get("proactive_send", False))
        # Task-28: minimal autonomy loop (default OFF; private-only; token-only).
        self.autonomy_loop_enabled = bool(self.config.get("autonomy_loop_enabled", False))
        self.autonomy_loop_theta_ig = self._loop_cfg_float(
            "autonomy_loop_theta_ig", AUTONOMY_LOOP_THETA_IG,
            AUTONOMY_LOOP_THETA_MIN, AUTONOMY_LOOP_THETA_MAX)
        self.autonomy_loop_margin = self._loop_cfg_float(
            "autonomy_loop_margin", AUTONOMY_LOOP_MARGIN,
            AUTONOMY_LOOP_MARGIN_MIN, AUTONOMY_LOOP_MARGIN_MAX)
        self.autonomy_loop_k_delay = self._loop_cfg_float(
            "autonomy_loop_k_delay", AUTONOMY_LOOP_K_DELAY,
            AUTONOMY_LOOP_K_MIN, AUTONOMY_LOOP_K_MAX)
        self.autonomy_loop_ior_seconds = self._loop_cfg_float(
            "autonomy_loop_ior_seconds", AUTONOMY_LOOP_IOR_SECONDS,
            AUTONOMY_LOOP_IOR_MIN, AUTONOMY_LOOP_IOR_MAX)
        self.autonomy_loop_c0 = self._loop_cfg_float(
            "autonomy_loop_c0", AUTONOMY_LOOP_C0, 0.0, 1.0)
        self.autonomy_loop_c1 = self._loop_cfg_float(
            "autonomy_loop_c1", AUTONOMY_LOOP_C1, 0.0, 1.0)
        self.autonomy_loop_c2 = self._loop_cfg_float(
            "autonomy_loop_c2", AUTONOMY_LOOP_C2, 0.0, 1.0)
        self.autonomy_loop_token_only = bool(
            self.config.get("autonomy_loop_token_only", True))
        # task-35/36: reply-side wiring (all deterministic, default OFF except
        # read-only telemetry counters which have no behavioural effect).
        self.refusal_brevity_enabled = bool(
            self.config.get("refusal_brevity_enabled", False))
        self.reply_consistency_enabled = bool(
            self.config.get("reply_consistency_enabled", False))
        self.llm_telemetry_enabled = bool(
            self.config.get("llm_telemetry_enabled", False))
        self.token_usage_enabled = bool(
            self.config.get("token_usage_enabled", False))
        # P1-3: real reply truncation cap (only active with refusal_brevity_enabled).
        try:
            self.refusal_brevity_max_chars = max(40, min(400, int(
                self.config.get("refusal_brevity_max_chars", 160) or 160)))
        except Exception:
            self.refusal_brevity_max_chars = 160
        # ---- 1.3.1 model-layer (task-37/38/39) ----
        self.bc_budget_enabled = bool(self.config.get("bc_budget_enabled", True))
        # §6: total char budget 480–800 (engineering); the old token-only key
        # was dead config and has been removed (P2 fix).
        try:
            self.bc_budget_chars = max(480, min(800, int(
                self.config.get("bc_budget_chars", 700) or 700)))
        except Exception:
            self.bc_budget_chars = 700
        self.sycophancy_check_enabled = bool(
            self.config.get("sycophancy_check_enabled", True))
        self.bc_dedupe_enabled = bool(self.config.get("bc_dedupe_enabled", True))
        try:
            self.bc_dedupe_history = max(1, min(50, int(
                self.config.get("bc_dedupe_history", 5) or 5)))
        except Exception:
            self.bc_dedupe_history = 5
        self.bc_hints_enabled = bool(self.config.get("bc_hints_enabled", True))
        self.bc_trace_enabled = bool(self.config.get("bc_trace_enabled", False))
        _wl = self.config.get("bc_label_whitelist")
        self._bc_label_whitelist = (list(_wl) if isinstance(_wl, (list, tuple)) and _wl
                                    else None)
        # P1-1: F1 split into two independent switches.
        #   trace: write state.reverse_check only (default ON, read-only, no hint)
        #   hint:  inject the <=140-char "avoid X" line next round (default OFF)
        self.think_selfcheck_trace_enabled = bool(
            self.config.get("think_selfcheck_trace_enabled", True))
        self.think_selfcheck_hint_enabled = bool(
            self.config.get("think_selfcheck_hint_enabled", False))
        self.think_repeat_guard_enabled = bool(
            self.config.get("think_repeat_guard_enabled", False))
        self.think_reflect_enabled = bool(
            self.config.get("think_reflect_enabled", False))
        try:
            self.think_reflect_daily_cap = max(1, min(20, int(
                self.config.get("think_reflect_daily_cap", 3) or 3)))
        except Exception:
            self.think_reflect_daily_cap = 3
        self.think_reflect_private_only = bool(
            self.config.get("think_reflect_private_only", True))
        self.think_reflect_llm_enabled = bool(
            self.config.get("think_reflect_llm_enabled", False))
        self.think_reflect_provider = str(
            self.config.get("think_reflect_provider", "") or "").strip()
        self.soft_bound_enabled = bool(self.config.get("soft_bound_enabled", False))
        self.soft_bound_k = self._loop_cfg_float("soft_bound_k", 0.10, 0.05, 0.20)
        self.soft_bound_m_frac = self._loop_cfg_float(
            "soft_bound_m_frac", 0.08, 0.05, 0.10)
        self.soft_bound_lam = self._loop_cfg_float(
            "soft_bound_lam", 0.10, 0.05, 0.20)
        self.path_monitor_enabled = bool(
            self.config.get("path_monitor_enabled", False))
        # ---- task-43: L1 thinking-physiology behaviour switches (all OFF) ----
        self.conflict_gate_enabled = bool(
            self.config.get("conflict_gate_enabled", False))
        self.rumination_effect_enabled = bool(
            self.config.get("rumination_effect_enabled", False))
        self.anchor_update_enabled = bool(
            self.config.get("anchor_update_enabled", False))
        self.identity_threat_stress_enabled = bool(
            self.config.get("identity_threat_stress_enabled", False))
        self.anchor_weight = self._loop_cfg_float(
            "anchor_weight", 0.25, 0.0, 0.9)
        # ---- task-38 accuracy ----
        self.temporal_validity_enabled = bool(
            self.config.get("temporal_validity_enabled", False))
        self.calibration_adaptive_enabled = bool(
            self.config.get("calibration_adaptive_enabled", False))
        self.rerank_enabled = bool(self.config.get("rerank_enabled", False))
        try:
            self.rerank_top_n = max(1, min(10, int(
                self.config.get("rerank_top_n", 5) or 5)))
        except Exception:
            self.rerank_top_n = 5
        self.memory_pin_enabled = bool(self.config.get("memory_pin_enabled", True))
        self.memory_overflow_compact_enabled = bool(
            self.config.get("memory_overflow_compact_enabled", False))
        self.mood_congruence_enabled = bool(
            self.config.get("mood_congruence_enabled", False))
        self.emotion_gating_enabled = bool(
            self.config.get("emotion_gating_enabled", False))
        # ---- task-37 token/cost ----
        self.token_budget_enabled = bool(
            self.config.get("token_budget_enabled", True))
        self.memory_recall_budget_enabled = bool(
            self.config.get("memory_recall_budget_enabled", False))
        try:
            self.recall_top_k = max(1, min(8, int(
                self.config.get("recall_top_k", 3) or 3)))
        except Exception:
            self.recall_top_k = 3
        try:
            self.recall_single_chars = max(40, min(220, int(
                self.config.get("recall_single_chars", 120) or 120)))
        except Exception:
            self.recall_single_chars = 120
        self.savings_mode = bool(self.config.get("savings_mode", False))
        self.context_budget_enabled = bool(
            self.config.get("context_budget_enabled", False))
        try:
            self.context_budget_turns = max(2, min(40, int(
                self.config.get("context_budget_turns", 8) or 8)))
        except Exception:
            self.context_budget_turns = 8
        self.cost_input_per_1m = self._loop_cfg_float(
            "cost_input_per_1m", 2.0, 0.0, 1000.0)
        self.cost_output_per_1m = self._loop_cfg_float(
            "cost_output_per_1m", 8.0, 0.0, 1000.0)
        self.cost_cache_per_1m = self._loop_cfg_float(
            "cost_cache_per_1m", 0.5, 0.0, 1000.0)
        # ---- task-54/55 chains (all default OFF; no LLM) ----
        self.expression_chain_enabled = bool(
            self.config.get("expression_chain_enabled", False))
        self.relationship_chain_enabled = bool(
            self.config.get("relationship_chain_enabled", False))
        self.gottman_enabled = bool(self.config.get("gottman_enabled", False))
        self.big5_effect_enabled = bool(
            self.config.get("big5_effect_enabled", False))
        self.learning_bandit_enabled = bool(
            self.config.get("learning_bandit_enabled", False))
        self.learning_relationship_enabled = bool(
            self.config.get("learning_relationship_enabled", False))
        self.learning_worthiness_enabled = bool(
            self.config.get("learning_worthiness_enabled", False))
        # P0/P1 safety + external-call governance (default-safe).
        self.data_admin_token = str(self.config.get("data_admin_token", "") or "")
        self.embedding_sensitive_allowed = bool(
            self.config.get("embedding_sensitive_allowed", False))
        try:
            self.bg_llm_daily_calls = max(0, min(100000, int(
                self.config.get("bg_llm_daily_calls", 200) or 200)))
        except Exception:
            self.bg_llm_daily_calls = 200
        self.bg_llm_daily_cost = self._loop_cfg_float(
            "bg_llm_daily_cost", 2.0, 0.0, 1000.0)
        try:
            self.outbound_timeout_ms = max(2000, min(5000, int(
                self.config.get("outbound_timeout_ms", 3000) or 3000)))
        except Exception:
            self.outbound_timeout_ms = 3000
        try:
            self.image_caption_timeout_ms = max(2000, min(20000, int(
                self.config.get("image_caption_timeout_ms", 8000) or 8000)))
        except Exception:
            self.image_caption_timeout_ms = 8000
        try:
            self.summary_llm_timeout_ms = max(2000, min(20000, int(
                self.config.get("summary_llm_timeout_ms", 8000) or 8000)))
        except Exception:
            self.summary_llm_timeout_ms = 8000
        # "省钱模式" is an OPTIONAL preset (default off); it only overrides
        # effective caps, never the accuracy-first defaults.
        if self.savings_mode:
            _eff = savings_overrides({
                "bc_budget_chars": self.bc_budget_chars,
                "recall_top_k": self.recall_top_k,
                "recall_single_chars": self.recall_single_chars})
            self.bc_budget_chars = int(_eff["bc_budget_chars"])
            self.memory_recall_budget_enabled = bool(_eff["memory_recall_budget_enabled"])
            self.recall_top_k = int(_eff["recall_top_k"])
            self.recall_single_chars = int(_eff["recall_single_chars"])
            self.sentence_dedup_enabled = bool(_eff["sentence_dedup_enabled"])
            self.bc_hints_enabled = bool(_eff["bc_hints_enabled"])
        # Stage-2: C8+C9 goal<->appraisal closed loop (default OFF = 1.2.98).
        self.bio_feedback_loops = bool(self.config.get("bio_feedback_loops", False))
        # Task-20: L1 learning defaults ON with small steps + hard bounds.
        self.bio_learning = bool(self.config.get("bio_learning", True))
        _rm = str(self.config.get("retention_model", "single") or "single")
        self.retention_model = _rm if _rm in LEARNING_RETENTION_MODELS else "single"
        # Batch4 attention flags: all default OFF = pure 1.2.98 no-op.
        self.attention_gate_enabled = bool(self.config.get("attention_gate_enabled", False))
        try:
            self.attention_gate_s = max(0.20, min(0.40, float(self.config.get("attention_gate_s", 0.30) or 0.30)))
        except Exception:
            self.attention_gate_s = 0.30
        try:
            self.attention_gate_shift = max(-0.20, min(0.20, float(self.config.get("attention_gate_shift", 0.0) or 0.0)))
        except Exception:
            self.attention_gate_shift = 0.0
        self.fan_penalty_enabled = bool(self.config.get("fan_penalty_enabled", False))
        try:
            self.fan_cap = max(1, min(64, int(self.config.get("fan_cap", 32) or 32)))
        except Exception:
            self.fan_cap = 32
        try:
            self.fan_gain = max(0.05, min(0.20, float(self.config.get("fan_gain", 0.10) or 0.10)))
        except Exception:
            self.fan_gain = 0.10
        try:
            self.fan_floor = max(0.50, min(0.85, float(self.config.get("fan_floor", 0.70) or 0.70)))
        except Exception:
            self.fan_floor = 0.70
        self.cowan_capacity_enabled = bool(self.config.get("cowan_capacity_enabled", False))
        try:
            self.cowan_capacity = max(3, min(6, int(self.config.get("cowan_capacity", 4) or 4)))
        except Exception:
            self.cowan_capacity = 4
        self.attention_topk_cap_enabled = bool(self.config.get("attention_topk_cap_enabled", False))
        try:
            self.attention_topk_cap = max(3, min(6, int(self.config.get("attention_topk_cap", 4) or 4)))
        except Exception:
            self.attention_topk_cap = 4
        # Batch5 H2: event chain (default OFF; H2-3 multi-hop also OFF).
        self.attention_gate_mode = str(self.config.get("attention_gate_mode", "hard") or "hard").lower()
        if self.attention_gate_mode not in ("hard", "probabilistic"):
            self.attention_gate_mode = "hard"
        try:
            self.attention_seed = int(self.config.get("attention_seed", 0) or 0)
        except Exception:
            self.attention_seed = 0
        # H2-2 budget is independent of the H2-1 edge switch.
        self.chain_budget_enabled = bool(self.config.get("chain_budget_enabled", False))
        self.memory_chain_enabled = bool(self.config.get("memory_chain_enabled", False))
        self.salience_boost_enabled = bool(self.config.get("salience_boost_enabled", False))
        self.sentence_dedup_enabled = bool(self.config.get("sentence_dedup_enabled", False))
        self.embedding_cache_enabled = bool(self.config.get("embedding_cache_enabled", True))
        try:
            self.embedding_timeout_ms = max(100, min(15000, int(
                self.config.get("embedding_timeout_ms", EMBED_TIMEOUT_MS_DEFAULT)
                or EMBED_TIMEOUT_MS_DEFAULT)))
        except Exception:
            self.embedding_timeout_ms = EMBED_TIMEOUT_MS_DEFAULT
        self.memory_chain_multihop = bool(self.config.get("memory_chain_multihop", False))
        try:
            self.chain_hops = max(1, min(2, int(self.config.get("chain_hops", 2) or 2)))
        except Exception:
            self.chain_hops = 2
        try:
            self.chain_fan_out = max(1, min(3, int(self.config.get("chain_fan_out", 3) or 3)))
        except Exception:
            self.chain_fan_out = 3
        try:
            self.chain_decay = max(0.4, min(0.6, float(self.config.get("chain_decay", 0.5) or 0.5)))
        except Exception:
            self.chain_decay = 0.5
        try:
            self.chain_max_new = max(1, min(6, int(self.config.get("chain_max_new", 6) or 6)))
        except Exception:
            self.chain_max_new = 6
        try:
            self.noise_seed = int(self.config.get("noise_seed", 0) or 0)
        except Exception:
            self.noise_seed = 0
        self._autonomy_task = None
        self._autonomy_private_sessions = {}
        # A1: event ranking is deterministic by default; the optional LLM rerank
        # follows the global rerank provider only when this switch is turned on.
        self.event_ranking_llm = bool(self.config.get("event_ranking_llm", False))
        # D5: stable default shape even before the first recall fills it.
        self._last_memory_trace = dict(DEFAULT_MEMORY_TRACE)
        self.memory_dedup_embedding = bool(self.config.get("memory_dedup_embedding", True))
        # M1 memory module: default OFF; enabled = shadow engine (no behaviour change).
        self.memory_module_enabled = bool(self.config.get("memory_module_enabled", False))
        self._memory_module_engines = {}
        self._memory_module_last_recall = None
        # task-33: deterministic memory-point worthiness gate (default ON).
        # OFF = exact legacy behaviour (archive every candidate, no new fields).
        self.memory_worthiness_enabled = bool(
            self.config.get("memory_worthiness_enabled", True))
        # Safety switch: default ON (new installs). When OFF, no masking,
        # no cross-session isolation, no forced abstention, no poison filter.
        # Saved old settings keep the user's stored value (load_settings below).
        self.safety_enabled = bool(self.config.get("safety_enabled", True))
        self.cross_session_memory = not self.safety_enabled
        self.sensitive_memory_protection = self.safety_enabled
        # P2: warn AFTER the value is assigned (previously logged false always).
        if not self.safety_enabled:
            logger.warning("[biocore] safety_enabled=false: 公开部署建议保持开启；"
                           "私人使用可关（敏感掩码/跨会话隔离/低置信拒答/投毒过滤关闭）")
        # Hybrid lexical+MMR retrieval and LLM-proposed write candidates.
        self.hybrid_retrieval = bool(self.config.get("hybrid_retrieval", True))
        self.llm_memory_candidates = bool(self.config.get("llm_memory_candidates", True))
        # B-T02 we-memory is evidence-gated and OFF by default (needs real
        # shared-ritual evidence before it writes relationship state).
        self.we_memory_enabled = bool(self.config.get("we_memory_enabled", False))
        # L-T02..L-T12 bounded runtime state. Only the last trace/hint is kept
        # in memory; no prompt text is stored and no reply is generated.
        self._last_cause_trace = []
        self._last_strategy_hint = ""
        self._last_memory_entries = []
        self._llm_v2_last = {}
        # task-36: bounded read-only telemetry (never feeds prompts or gates).
        self._llm_telemetry = {"counters": {}, "recent": []}
        self._token_usage = {"available": False, "sessions": {}}
        # task-37/39/40 per-turn read-only state (never fed back into prompts).
        self._bc_history = []
        self._last_injection_trace = None
        self._last_reverse_check = None
        # P1-1: F1 hint is NOT merged into strategy hints; it is a separate
        # pending line accounted inside bc_budget_chars.
        self._reverse_check_hint = ""
        self._repeat_guard = None
        self._repeat_hint = ""
        self._repeat_streak = 0
        self._reflect_hint = ""
        self._reflect_stats = {}
        self._reflect_cache = {}
        self._path_monitor = None
        self._token_budget = {"sessions": {}, "today": {}, "calls": 0}
        self._recent_replies = []
        self._label_history = []
        self._thought_note_current = ""
        self._rerank_stats = {"calls": 0, "fallback": 0, "last_n": 0}
        # task-54/55: per-session learning state (L1 read-only projection).
        self._learning = {}
        self._learning_pending = {}
        self._learning_daily = {}
        self._last_user_text = ""
        # P0/P1 safety ops state (read-only; tokens are in-memory/one-shot).
        self._download_tokens = {}
        self._delete_tokens = {}
        self._image_caption_timeouts = 0
        self._bg_lock = None
        self._bg_llm_usage = {"day": "", "calls": 0, "cost": 0.0}
        self._embed_cache_sig = None
        self._image_fail_count = 0
        self._corrupt_backups = 0
        self._migration_note = ""
        self._restore_fail_inject = False
        try:
            self._env_checks = self._run_env_selfcheck()
        except Exception:
            self._env_checks = {"warnings": ["selfcheck_failed"]}
        # LLM scope: user requirement is "LLM only for reply + summary".
        # When true, BioCore only calls the LLM for event/memory summaries;
        # persona compile / event ranking / reflection / image caption are
        # skipped (deterministic fallbacks where available).
        self.llm_only_reply_summary = bool(
            self.config.get("llm_only_reply_summary", True))
        self.llm_functions = {
            _name: {"enabled": LLM_FUNCTION_DEFAULTS[_name],
                    "provider": "follow_llm"}
            for _name in LLM_FUNCTIONS
        }
        self.first_run_persona_compile = bool(self.config.get("first_run_persona_compile", True))
        self.kb_enabled = bool(self.config.get("kb_enabled", False))
        _names = self.config.get("kb_names", [])
        self.kb_names = [str(x).strip() for x in _names] if isinstance(_names, (list, tuple)) else []
        self.cores = {}
        self._consolidating = False
        self._last_consolidation = 0.0
        self._last_event_archive = 0.0
        self._last_reflection = 0.0
        try:
            self.reflection_interval_hours = max(1, int(self.config.get("reflection_interval_hours", 6) or 6))
        except Exception:
            self.reflection_interval_hours = 6
        # Event-driven insight trigger: fallback is a 24h ultra-long safety net,
        # not a periodic 6h main trigger anymore.
        self._insight_fallback_hours = max(INSIGHT_FALLBACK_HOURS, int(self.reflection_interval_hours))
        # Tunable thresholds (defaults match the constants above; AstrBot plugin
        # config exposes insight_min_new_events / insight_cooldown_minutes).
        try:
            self._insight_min_new_events = max(
                1, int(self.config.get("insight_min_new_events", INSIGHT_MIN_NEW_EVENTS)
                       or INSIGHT_MIN_NEW_EVENTS))
        except Exception:
            self._insight_min_new_events = INSIGHT_MIN_NEW_EVENTS
        try:
            self._insight_cooldown_minutes = max(
                1, int(self.config.get("insight_cooldown_minutes", INSIGHT_COOLDOWN_SECONDS // 60)
                       or (INSIGHT_COOLDOWN_SECONDS // 60)))
        except Exception:
            self._insight_cooldown_minutes = INSIGHT_COOLDOWN_SECONDS // 60
        # Long-term pattern insight: main entry is the manual dashboard button;
        # automatic generation is opt-in and OFF by default.
        self.insight_auto_enabled = bool(self.config.get("insight_auto_enabled", False))
        try:
            self.stimulus_decay_seconds = max(30, int(self.config.get("stimulus_decay_seconds", 300) or 300))
            self.stimulus_habituation = max(0.0, float(self.config.get("stimulus_habituation", 0.75) or 0.75))
        except Exception:
            self.stimulus_decay_seconds = 300
            self.stimulus_habituation = 0.75
        self.image_recognition_enabled = bool(self.config.get("image_recognition_enabled", True))
        try:
            self.image_service_idle_seconds = max(30, int(self.config.get("image_service_idle_seconds", 120) or 120))
        except Exception:
            self.image_service_idle_seconds = 120
        try:
            self.image_cache_max_entries = max(20, int(self.config.get("image_cache_max_entries", 500) or 500))
        except Exception:
            self.image_cache_max_entries = 500
        def _configured_path(key):
            raw = str(self.config.get(key, "") or "").strip()
            return Path(raw) if raw else None
        self.image_llama_server = _configured_path("image_llama_server")
        self.image_llama_model = _configured_path("image_llama_model")
        self.image_llama_mmproj = _configured_path("image_llama_mmproj")
        try:
            _raw_port = int(self.config.get("image_service_port", 0) or 0)
            self.image_service_port = _raw_port if _raw_port > 0 else 0
        except Exception:
            self.image_service_port = 0
        # Lazy image-service process/lock state (initialized here so the
        # first image request does not AttributeError).
        self._image_proc = None
        self._image_last_used = 0.0
        self._image_service_lock = None
        _triggers = self.config.get("image_trigger_words", [])
        self.image_trigger_words = ([str(x).strip() for x in _triggers if str(x).strip()]
                                    if isinstance(_triggers, (list, tuple)) else [])
        try:
            self.valence_decay_minutes = max(1.0, float(self.config.get("valence_decay_minutes", 120) or 120))
        except Exception:
            self.valence_decay_minutes = 120.0
        try:
            self.arousal_decay_minutes = max(1.0, float(self.config.get("arousal_decay_minutes", 30) or 30))
        except Exception:
            self.arousal_decay_minutes = 30.0
        try:
            self.social_decay_minutes = max(1.0, float(self.config.get("social_decay_minutes", 180) or 180))
        except Exception:
            self.social_decay_minutes = 180.0
        self.stimuli = []
        self.profile = None
        self.persona_text = ""
        # Persona selection: empty = follow AstrBot default persona.
        self.persona_id = str(self.config.get("persona_id") or "").strip()
        # Hash of the persona text whose numeric profile was compiled; lets
        # strict LLM mode still compile ONCE on first run / persona change.
        self._persona_compiled_hash = ""
        # Schema slots proposed once by the persona compiler (bounded strings).
        self.schema_texts = []
        # L-T07: bounded persona style slots proposed by the compiler (never
        # prompt text; the interpretation layer stays the only prompt owner).
        self.persona_style = {"intimacy_style": "neutral", "address_terms": []}
        self.self_model = self._load_self_model()
        if not isinstance(self.self_model.get("diary"), list):
            self.self_model["diary"] = []
        if not isinstance(self.self_model.get("relationship_narratives"), list):
            self.self_model["relationship_narratives"] = []
        self.api_config = {}
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        self._load_profile()
        self._load_settings()
        if "kb_enabled" in self.config:
            self.kb_enabled = bool(self.config.get("kb_enabled"))
        if "kb_names" in self.config:
            _n = self.config.get("kb_names")
            if isinstance(_n, (list, tuple)):
                self.kb_names = [str(x).strip() for x in _n if str(x).strip()]
        self._load_api_config()
        self._register_page_api()
        try:
            self._cleanup_duplicate_events()
        except Exception as exc:
            logger.warning("[biocore] dedupe init failed: %s", exc)
        try:
            _d = self._public_api_config()
            logger.info("[biocore] api defaults llm=%s embedding=%s rerank=%s",
                        (_d.get("llm") or {}).get("provider_id"),
                        (_d.get("embedding") or {}).get("provider_id"),
                        (_d.get("rerank") or {}).get("provider_id"))
        except Exception as exc:
            logger.warning("[biocore] api defaults probe failed: %s", exc)

    def _load_profile(self):
        try:
            if PROFILE_PATH.exists():
                d = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
                self.profile = dict(d.get("profile") or {})
                self.persona_text = str(d.get("persona") or "")
                _ph = str(d.get("persona_hash") or "")
                self._persona_compiled_hash = _ph or (_sha256(self.persona_text) if self.persona_text else "")
                _schema = d.get("schema")
                if isinstance(_schema, list):
                    self.schema_texts = [str(x).strip()[:60] for x in _schema
                                         if str(x).strip()][:6]
                _style = d.get("style")
                if isinstance(_style, dict):
                    _tag = str(_style.get("intimacy_style") or "neutral")
                    if _tag not in ("neutral", "playful", "gentle", "reserved"):
                        _tag = "neutral"
                    _terms = [str(x).strip()[:12] for x in (_style.get("address_terms") or [])
                              if str(x).strip()][:3]
                    self.persona_style = {"intimacy_style": _tag, "address_terms": _terms}
                logger.info("[biocore] loaded profile %s", PROFILE_PATH)
        except Exception as exc:
            logger.warning("[biocore] profile load failed: %s", exc)

    async def _persona_text(self, event) -> str:
        try:
            pm = self.context.persona_manager
            _pid = str(getattr(self, "persona_id", "") or self.config.get("persona_id") or "").strip()
            if _pid:
                try:
                    _p = pm.get_persona_v3_by_id(_pid)
                except Exception:
                    _p = None
                if _p:
                    if isinstance(_p, dict):
                        return str(_p.get("prompt") or _p.get("system_prompt") or "")
                    return str(getattr(_p, "prompt", "") or getattr(_p, "system_prompt", "") or "")
            p = await pm.get_default_persona_v3(getattr(event, "unified_msg_origin", None))
            if isinstance(p, dict):
                return str(p.get("prompt") or p.get("system_prompt") or "")
            return str(getattr(p, "prompt", "") or getattr(p, "system_prompt", "") or "")
        except Exception as exc:
            logger.warning("[biocore] persona read failed: %s", exc)
            return ""

    def _function_cfg(self, kind: str) -> dict:
        _name = LLM_FUNCTION_ALIASES.get(str(kind or ""), str(kind or ""))
        _all = getattr(self, "llm_functions", None)
        if not isinstance(_all, dict):
            return {"enabled": True, "provider": "follow_llm"}
        _cfg = _all.get(_name)
        if not isinstance(_cfg, dict):
            _cfg = {}
        return {
            "enabled": bool(_cfg.get("enabled", LLM_FUNCTION_DEFAULTS.get(_name, True))),
            "provider": str(_cfg.get("provider") or "follow_llm"),
        }

    def _llm_allowed(self, kind: str) -> bool:
        """Per-function LLM switch (replaces the old global strict flag)."""
        _all = getattr(self, "llm_functions", None)
        if not isinstance(_all, dict):
            # Test harness / legacy object created before this feature: keep
            # the old llm_only_reply_summary semantics when present.
            _strict = getattr(self, "llm_only_reply_summary", None)
            if _strict is None:
                return True
            return (not bool(_strict)) or str(kind or "") in ("reply", "summary")
        if not self._function_cfg(kind)["enabled"]:
            return False
        # P1-3: global background-LLM daily budget (calls + estimated cost).
        if str(kind) in LLM_BACKGROUND_KINDS:
            try:
                _today = time.strftime("%Y-%m-%d")
                if str(self._bg_llm_usage.get("day") or "") != _today:
                    self._bg_llm_usage = {"day": _today, "calls": 0, "cost": 0.0}
                _limit_calls = int(getattr(self, "bg_llm_daily_calls", 200) or 0)
                _limit_cost = float(getattr(self, "bg_llm_daily_cost", 2.0) or 0.0)
                if ((_limit_calls and int(self._bg_llm_usage.get("calls", 0)) >= _limit_calls)
                        or (_limit_cost and float(self._bg_llm_usage.get("cost", 0.0)) >= _limit_cost)):
                    self._bg_budget_blocked = True
                    self._record_llm_telemetry(kind, "budget_blocked")
                    return False
            except Exception:
                pass
        return True

    def _provider_kind(self, provider) -> str:
        """Classify a provider by id/model/type (chat / vision / embedding / tts / rerank)."""
        try:
            cfg = getattr(provider, "provider_config", {}) or {}
            raw = " ".join(str(x or "") for x in (
                cfg.get("id"), cfg.get("model"),
                cfg.get("provider_type"), type(provider).__name__,
            )).lower()
        except Exception:
            raw = ""
        if any(x in raw for x in ("img", "image", "vision", "t2i", "dall", "stable", "midjourney", "exusiai-img")):
            return "vision"
        if any(x in raw for x in ("tts", "speech", "voice")):
            return "tts"
        if any(x in raw for x in ("embed", "bge", "text-embedding")):
            return "embedding"
        if "rerank" in raw:
            return "rerank"
        return "chat"

    async def _provider_for(self, kind: str, event=None):
        """Resolve the LLM provider for one function.

        Default ("follow_llm") uses AstrBot's current chat provider. A configured
        provider_id is looked up via get_provider_by_id; if it is missing we log
        a warning and fall back to the main LLM instead of failing the feature.
        """
        _cfg = self._function_cfg(kind)
        _override = _cfg["provider"]
        _umo = str(getattr(event, "unified_msg_origin", "") or "") if event is not None else ""
        if _override and _override not in ("follow_llm", "main", "default", ""):
            _p = None
            try:
                _p = self.context.get_provider_by_id(_override)
            except Exception as exc:
                logger.warning("[biocore] provider lookup failed for %s (%s): %s", kind, _override, exc)
                _p = None
            if _p is not None:
                if self._provider_kind(_p) == "chat":
                    return _p
                logger.warning("[biocore] llm function %s provider %s is not a chat provider; fallback to main LLM",
                               kind, _override)
            else:
                logger.warning("[biocore] llm function %s provider %s not found; fallback to main LLM", kind, _override)
        try:
            return await self.context.get_using_provider_async(_umo)
        except Exception as exc:
            logger.warning("[biocore] main LLM provider lookup failed for %s: %s", kind, exc)
            return None


    # ------------------------------------------------------------------
    # LLM v2 (L-T01..L-T12): proposal-only model calls.
    #
    # Contract:
    #   * every function is registered in LLM_FUNCTIONS and defaults to OFF;
    #   * prompt text + output parsing only live in interpretation.py;
    #   * a model output is validated before storage (relationship_meta);
    #   * no function writes core v/a/d/trust/goals or generates a reply;
    #   * strict/legacy mode (_llm_allowed) skips every extra call.
    # ------------------------------------------------------------------
    @staticmethod
    def _truncate_at_sentence(text, cap) -> str:
        """P1-3: bounded sentence-boundary truncation for refusal brevity."""
        value = str(text or "").strip()
        try:
            limit = max(1, int(cap or 0))
        except Exception:
            limit = 160
        if len(value) <= limit:
            return value
        head = value[:limit]
        idx = -1
        for boundary in ("。", "！", "？", "；", "…", "\n", ".", "!", "?"):
            pos = head.rfind(boundary)
            if pos > idx:
                idx = pos
        if idx >= max(1, int(limit * 0.4)):
            return head[:idx + 1].strip()
        return head.rstrip()

    def _cost_for(self, input_tokens=0, output_tokens=0,
                  cached_tokens=0) -> float:
        """task-37: CNY cost from the configurable price table (per 1M tokens)."""
        try:
            tin = max(0, int(input_tokens or 0))
            tout = max(0, int(output_tokens or 0))
            tcached = max(0, min(tin, int(cached_tokens or 0)))
        except Exception:
            return 0.0
        price_in = float(getattr(self, "cost_input_per_1m", 2.0) or 0.0)
        price_out = float(getattr(self, "cost_output_per_1m", 8.0) or 0.0)
        price_cache = float(getattr(self, "cost_cache_per_1m", 0.5) or 0.0)
        return round(((tin - tcached) * price_in
                      + tcached * price_cache
                      + tout * price_out) / 1_000_000.0, 6)

    def _record_token_budget(self, session, *, input_tokens=0,
                             output_tokens=0, cached_tokens=0,
                             estimated=True, core=None,
                             count_call=True) -> None:
        """task-37: measured/estimated token + cost counters (read-only)."""
        try:
            store = self._token_budget if isinstance(
                getattr(self, "_token_budget", None), dict) else {}
            sessions = store.get("sessions") if isinstance(store.get("sessions"), dict) else {}
            key = str(session or "default")[:80]
            item = sessions.get(key) if isinstance(sessions.get(key), dict) else {}
            tin = int(input_tokens or 0)
            tout = int(output_tokens or 0)
            tcached = int(cached_tokens or 0)
            item["input_tokens"] = int(item.get("input_tokens", 0) or 0) + tin
            item["output_tokens"] = int(item.get("output_tokens", 0) or 0) + tout
            item["cached_tokens"] = int(item.get("cached_tokens", 0) or 0) + tcached
            # P2: a turn has one input call and one output call -> count the
            # round only on the output call (request passes count_call=False).
            if count_call:
                item["calls"] = int(item.get("calls", 0) or 0) + 1
            item["estimated_calls"] = (int(item.get("estimated_calls", 0) or 0)
                                       + (1 if estimated else 0))
            item["estimated"] = bool(estimated) or bool(item.get("estimated"))
            item["last_input"] = tin
            item["last_output"] = tout
            item["last_estimated"] = bool(estimated)
            item["cost"] = round(float(item.get("cost", 0.0) or 0.0)
                                 + self._cost_for(tin, tout, tcached), 6)
            sessions[key] = item
            store["sessions"] = sessions
            if count_call:
                store["calls"] = int(store.get("calls", 0) or 0) + 1
            today = time.strftime("%Y-%m-%d")
            day = store.get("today") if isinstance(store.get("today"), dict) else {}
            if str(day.get("date") or "") != today:
                day = {"date": today, "input_tokens": 0, "output_tokens": 0,
                       "cached_tokens": 0, "cost": 0.0, "calls": 0,
                       "estimated_calls": 0, "estimated": False}
            day["input_tokens"] = int(day.get("input_tokens", 0) or 0) + tin
            day["output_tokens"] = int(day.get("output_tokens", 0) or 0) + tout
            day["cached_tokens"] = int(day.get("cached_tokens", 0) or 0) + tcached
            day["cost"] = round(float(day.get("cost", 0.0) or 0.0)
                                + self._cost_for(tin, tout, tcached), 6)
            if count_call:
                day["calls"] = int(day.get("calls", 0) or 0) + 1
            day["estimated_calls"] = (int(day.get("estimated_calls", 0) or 0)
                                      + 1)
            day["estimated"] = bool(day.get("estimated")) or bool(estimated)
            store["today"] = day
            self._token_budget = store
            if core is not None and getattr(self, "token_budget_enabled", True):
                core.token_usage = dict(item)
        except Exception:
            pass

    @staticmethod
    def _reflect_template(triggers, reverse=None, core=None) -> str:
        labels = getattr(core, "labels", {}) if core is not None else {}
        labels = labels if isinstance(labels, dict) else {}
        emo = str(labels.get("emotion") or "neutral")[:10]
        need = str(labels.get("need") or "talk")[:10]
        action = {"low_confidence": "先确认再回答",
                  "violations": "少下结论、先核对",
                  "user_ask": "先复述再解释",
                  "relationship": "先接住情绪"}.get(
                      (triggers or ["generic"])[0], "先接住情绪")
        text = ("自我检查（%s）：情绪=%s 需要=%s；下一轮：%s"
                % ("/".join((triggers or ["generic"])[:2]), emo, need, action))
        return text[:120]

    async def _reflect_llm_text(self, key, prompt):
        """Optional cheaper-model reflection: 24h cache, silent fallback."""
        try:
            cache = self._reflect_cache if isinstance(
                getattr(self, "_reflect_cache", None), dict) else {}
            now = time.time()
            hit = cache.get(key)
            if isinstance(hit, tuple) and len(hit) == 2 and now - float(hit[0]) < 86400:
                return str(hit[1])[:120], "cached"
            provider = None
            if getattr(self, "think_reflect_provider", ""):
                try:
                    provider = self.context.get_provider_by_id(
                        self.think_reflect_provider)
                except Exception:
                    provider = None
            if provider is None:
                return "", "no_provider"
            try:
                resp = await provider.text_chat(prompt=prompt)
                text = str(getattr(resp, "completion_text", "") or "").strip()[:120]
            except Exception:
                return "", "error"
            if not text:
                return "", "empty"
            cache[key] = (now, text)
            self._reflect_cache = dict(list(cache.items())[-20:])
            return text, "llm"
        except Exception:
            return "", "error"

    async def _maybe_think_reflect(self, event, core, reply, user_text="") -> bool:
        """task-39 F2: one bounded reflection when a trigger fires (default OFF)."""
        try:
            _umo = str(getattr(event, "unified_msg_origin", "default") or "default")
            if (getattr(self, "think_reflect_private_only", True)
                    and not self._is_private_event(event)):
                stats = self._reflect_stats.setdefault(_umo, {"count": 0, "day": ""})
                stats["blocked_private"] = int(stats.get("blocked_private", 0) or 0) + 1
                return False
            triggers = []
            _ansc = (getattr(self, "_last_memory_meta", {}) or {}).get("answer_confidence")
            try:
                if _ansc is not None and float(_ansc) < 0.40:
                    triggers.append("low_confidence")
            except Exception:
                pass
            _rc = getattr(self, "_last_reverse_check", None)
            if isinstance(_rc, dict) and len(_rc.get("violations") or []) >= 2:
                triggers.append("violations")
            if any(w in str(user_text or "") for w in ("你想想", "想想为什么", "反思", "为什么")):
                triggers.append("user_ask")
            try:
                _rel = self._relationship_of(self._user_record(event))
                _state = _rel.get("state") if isinstance(_rel.get("state"), dict) else {}
                if float(_state.get("conflict", 0.0) or 0.0) >= 0.60:
                    triggers.append("relationship")
            except Exception:
                pass
            if not triggers:
                return False
            today = time.strftime("%Y-%m-%d")
            stats = self._reflect_stats.setdefault(_umo, {"count": 0, "day": ""})
            if str(stats.get("day") or "") != today:
                stats["day"] = today
                stats["count"] = 0
            cap = max(1, int(getattr(self, "think_reflect_daily_cap", 3) or 3))
            if int(stats.get("count", 0) or 0) >= cap:
                stats["blocked_daily"] = int(stats.get("blocked_daily", 0) or 0) + 1
                return False
            template = self._reflect_template(triggers, _rc, core)
            text = template
            fallback = True
            if getattr(self, "think_reflect_llm_enabled", False):
                key = _sha256(str(triggers) + str(_umo) + str(reply)[:80])[:16]
                llm_text, source = await self._reflect_llm_text(
                    key, "用不超过120字、只做一次自我检查：%s" % template)
                if llm_text:
                    text = llm_text
                    fallback = False
                stats["last_source"] = source
            try:
                tree = getattr(core, "reflection_tree", None)
                if not isinstance(tree, dict):
                    tree = {"roots": [], "count": 0}
                node = {"ts": time.time(), "insight": text,
                        "emotion": str((getattr(core, "labels", {}) or {}).get("emotion") or "neutral"),
                        "source": "think_reflect", "trigger": list(triggers[:3]),
                        "fallback": bool(fallback), "children": []}
                roots = tree.get("roots") or []
                if roots:
                    roots[-1].setdefault("children", []).append(node)
                else:
                    roots.append(node)
                tree["roots"] = roots[-10:]
                tree["count"] = int(tree.get("count", 0)) + 1
                core.reflection_tree = tree
            except Exception:
                pass
            stats["count"] = int(stats.get("count", 0) or 0) + 1
            stats["last_trigger"] = list(triggers[:3])
            stats["last_fallback"] = bool(fallback)
            self._reflect_hint = ("先核对再回答；少下结论" if "violations" in triggers
                                  else "先确认对方状态")[:140]
            try:
                if getattr(self, "think_repeat_guard_enabled", False):
                    self._repeat_hint = self._repeat_hint or "换一种说法"
            except Exception:
                pass
            return True
        except Exception:
            return False

    @staticmethod
    def _mood_multiplier(v) -> float:
        """task-38: mood-consistent recall multiplier (0.90–1.10, default OFF)."""
        try:
            value = max(-1.0, min(1.0, float(v or 0.0)))
        except Exception:
            value = 0.0
        return max(0.90, min(1.10, 1.0 + 0.10 * value))

    @staticmethod
    def _emotion_gate_params(stress, v) -> dict:
        """task-38: emotion gating (raise threshold / lower top-k when stressed)."""
        try:
            s = max(0.0, min(1.0, float(stress or 0.0)))
            val = max(-1.0, min(1.0, float(v or 0.0)))
        except Exception:
            s, val = 0.0, 0.0
        active = bool(s >= 0.65 or val <= -0.50)
        return {"active": active,
                "threshold_bonus": 0.05 if active else 0.0,
                "top_k_cap": 2 if active else 0}

    # ---- task-54/55 expression / relationship / learning (default OFF) ----
    def _learning_for(self, session) -> dict:
        store = self._learning if isinstance(getattr(self, "_learning", None), dict) else {}
        key = str(session or "default")[:80]
        st = store.get(key) if isinstance(store.get(key), dict) else {}
        day = time.strftime("%Y-%m-%d")
        if str(st.get("day") or "") != day:
            st = {"day": day, "cap_base": float(st.get("cap_base", 30.0) or 30.0),
                  "cap_delta_today": 0.0, "rel_delta_today": 0.0,
                  "k1": float(st.get("k1", 1.0) or 1.0),
                  "k3": float(st.get("k3", 1.0) or 1.0),
                  "repair_mult": float(st.get("repair_mult", 1.0) or 1.0),
                  "worth_bias": float(st.get("worth_bias", 0.0) or 0.0),
                  "updates": 0, "reward_baseline": float(st.get("reward_baseline", 0.0) or 0.0)}
        for k, v in (("cap_base", 30.0), ("cap_delta_today", 0.0),
                     ("rel_delta_today", 0.0), ("k1", 1.0), ("k3", 1.0),
                     ("repair_mult", 1.0), ("worth_bias", 0.0),
                     ("updates", 0), ("reward_baseline", 0.0)):
            st.setdefault(k, v)
        st["last_ts"] = time.time()
        store[key] = st
        # P2: bounded session map (oldest dropped, never unbounded growth).
        if len(store) > 50:
            _keep = sorted(store.items(), key=lambda kv: float(
                (kv[1] or {}).get("last_ts", 0.0) or 0.0), reverse=True)[:50]
            store = dict(_keep)
        self._learning = store
        return st

    def _learning_publish(self, core, session) -> None:
        if core is None:
            return
        if any(getattr(self, k, False) for k in (
                "learning_bandit_enabled", "learning_relationship_enabled",
                "learning_worthiness_enabled")):
            core.learning_state = dict(self._learning_for(session))

    @staticmethod
    def _learning_reward(prev_len, user_len, same_emotion=False) -> float:
        try:
            pl = max(1, int(prev_len or 0))
            ul = max(0, int(user_len or 0))
        except Exception:
            pl, ul = 1, 0
        engagement = min(1.0, ul / float(pl))
        emotion_cont = 1.0 if same_emotion else 0.0
        awkward = 1.0 if ul < 4 else 0.0
        shortened = 1.0 if ul < 0.5 * pl else 0.0
        return round(0.25 * engagement + 0.25 * emotion_cont
                     - 0.25 * awkward - 0.25 * shortened, 4)

    def _learning_bandit_update(self, core, session, reward) -> dict:
        st = self._learning_for(session)
        eta = 0.02
        baseline = float(st.get("reward_baseline", 0.0) or 0.0)
        target = float(st.get("cap_base", 30.0) or 30.0) + eta * (float(reward) - baseline)
        target = max(30.0, min(240.0, target))
        allowed = max(0.0, 5.0 - abs(float(st.get("cap_delta_today", 0.0) or 0.0)))
        step = max(-allowed, min(allowed, target - float(st.get("cap_base", 30.0))))
        st["cap_base"] = round(float(st["cap_base"]) + step, 4)
        st["cap_delta_today"] = round(float(st.get("cap_delta_today", 0.0)) + step, 4)
        st["reward_baseline"] = round(0.9 * baseline + 0.1 * float(reward), 4)
        st["updates"] = int(st.get("updates", 0)) + 1
        self._learning_publish(core, session)
        return dict(st)

    def _learning_relationship_update(self, core, session, disclosure=0.0,
                                      overreach=0.0) -> dict:
        st = self._learning_for(session)
        step = 0.01
        d1 = step * (1.0 if disclosure else 0.0) - step * (1.0 if overreach else 0.0)
        d3 = step * (1.0 if overreach else 0.0)
        d_rep = 0.01 if disclosure else -0.01
        # P1-3: hard daily cap ±0.03 across calls (all relationship coeffs).
        used = float(st.get("rel_delta_today", 0.0) or 0.0)
        remaining = 0.03 - abs(used)
        total = d1 + d3 + d_rep
        if abs(total) > remaining:
            scale = remaining / abs(total) if total else 0.0
            d1, d3, d_rep = d1 * scale, d3 * scale, d_rep * scale
        st["k1"] = round(max(0.50, min(1.50, float(st["k1"]) + d1)), 4)
        st["k3"] = round(max(0.50, min(1.50, float(st["k3"]) + d3)), 4)
        st["repair_mult"] = round(max(0.80, min(1.20, float(st["repair_mult"]) + d_rep)), 4)
        st["rel_delta_today"] = round(used + d1 + d3 + d_rep, 4)
        st["updates"] = int(st.get("updates", 0)) + 1
        self._learning_publish(core, session)
        return dict(st)

    def _learning_worthiness_step(self, core, session, important=True) -> dict:
        st = self._learning_for(session)
        delta = 0.01 if important else -0.01
        st["worth_bias"] = round(max(-0.05, min(0.05,
                                   float(st.get("worth_bias", 0.0)) + delta)), 4)
        st["updates"] = int(st.get("updates", 0)) + 1
        self._learning_publish(core, session)
        return dict(st)

    def _expression_hint(self, core, session, user_text="") -> str:
        labels = getattr(core, "labels", {}) or {}
        expr = str(labels.get("expression") or "normal")
        elaboration = {"open": 1.0, "normal": 0.6, "short": 0.25}.get(expr, 0.6)
        stress = float(getattr(core, "stress", 0.0) or 0.0)
        st = self._learning_for(session)
        cap_base = float(st.get("cap_base", 30.0)) if getattr(
            self, "learning_bandit_enabled", False) else 30.0
        if getattr(self, "big5_effect_enabled", False) and isinstance(
                getattr(core, "big5_effect", None), dict):
            elaboration += (float(core.big5_effect.get("openness", 0.5)) - 0.5) * 0.2
        suppression = float(getattr(core, "suppression", 0.0) or 0.0)
        if not suppression:
            try:
                _m = getattr(self, "_last_memory_meta", {}) or {}
                suppression = 0.5 if _m.get("abstain") else 0.0
            except Exception:
                suppression = 0.0
        cap_t = interpretation.expression_length_cap(
            elaboration, suppression=suppression, stress=stress, cap_base=cap_base)
        try:
            rel = self._relationship_of(self._user_record_from_text(user_text))
            state = rel.get("state") if isinstance(rel.get("state"), dict) else {}
            distance = 1.0 - float(state.get("closeness", 0.5) or 0.5)
            trust = float(state.get("trust", 0.5) or 0.5)
        except Exception:
            distance, trust = 0.5, 0.5
        risk = interpretation.politeness_risk(distance, trust, stress)
        strategy = interpretation.politeness_strategy(risk)
        allowed = False
        try:
            meta = getattr(self, "_last_memory_meta", {}) or {}
            if int(meta.get("count", 0) or 0) > 0:
                mode = "explicit" if any(w in str(user_text) for w in (
                    "记得", "上次", "之前", "你忘")) else "none"
                allowed = interpretation.memory_citation_allowed(
                    mode,
                    continuity_seconds=float(meta.get("continuity_seconds", 0.0) or 0.0),
                    open_loop=bool(getattr(core, "open_loops", None)),
                    milestone=bool(meta.get("milestone")),
                    confidence=float(meta.get("confidence", 0.0) or 0.0),
                    already_cited=0)
        except Exception:
            allowed = False
        return interpretation.expression_prompt_hint(
            cap_t, strategy, "可引用1条" if allowed else "不点破记忆")

    def _user_record_from_text(self, text):
        try:
            return self._relationship_of({})
        except Exception:
            return {}

    def _big5_effect(self, core) -> dict:
        prof = getattr(core, "profile", {}) if isinstance(
            getattr(core, "profile", {}), dict) else {}
        traits = prof.get("traits") if isinstance(prof.get("traits"), dict) else (
            prof.get("big5") if isinstance(prof.get("big5"), dict) else {})
        cue = max(0.0, min(1.0, (float(getattr(core, "a", 0.5) or 0.0)
                                 + (0.5 + 0.5 * float(getattr(core, "v", 0.0) or 0.0))) / 2.0))
        out = {}
        for name in ("openness", "conscientiousness", "extraversion",
                     "agreeableness", "neuroticism"):
            try:
                trait = float(traits.get(name, 0.5) or 0.5)
            except Exception:
                trait = 0.5
            out[name] = interpretation.big5_trait_effect(trait, cue)
        return out

    def _apply_relationship_chain(self, event, core, user_text, reply) -> None:
        try:
            data = self._user_record(event)
            rel = data.get("relationship") if isinstance(data, dict) else None
            if not isinstance(rel, dict):
                return
            state = rel.get("state") if isinstance(rel.get("state"), dict) else {}
            trust = float(state.get("trust", 0.5) or 0.5)
            conflict = float(state.get("conflict", 0.5) or 0.5)
            closeness = float(state.get("closeness", 0.5) or 0.5)
            repair = float(state.get("repair", 0.0) or 0.0)
            dyn = relationship_meta.attachment_dynamics(trust, conflict, closeness)
            text = str(user_text or "")
            disclosure = min(1.0, sum(1 for w in ("其实", "感觉", "最近", "压力",
                                                  "难过", "开心", "害怕", "喜欢")
                                      if w in text) / 3.0)
            response = 1.0 if any(w in str(reply or "") for w in (
                "我在", "听起来", "理解", "然后呢", "嗯，")) else 0.0
            overreach = 1.0 if interpretation._OVERREACH_RE.search(str(reply or "")) else 0.0
            st = self._learning_for(str(getattr(event, "unified_msg_origin", "default")))
            k1 = float(st.get("k1", 1.0)) if getattr(
                self, "learning_relationship_enabled", False) else 1.0
            k3 = float(st.get("k3", 1.0)) if getattr(
                self, "learning_relationship_enabled", False) else 1.0
            d_close = relationship_meta.closeness_step(disclosure, response, overreach, k1, k3)
            conflict_step = repair_act_step = 0.0
            horsemen = {}
            _writes = bool(getattr(self, "relationship_chain_enabled", False))
            if _writes and getattr(self, "gottman_enabled", False):
                horsemen, conflict_step = relationship_meta.gottman_conflict_step(text)
                _, repair_act_step = relationship_meta.repair_step(reply, dyn["repair_speed"])
                try:
                    repair_act_step *= float(st.get("repair_mult", 1.0) or 1.0)
                except Exception:
                    pass
            # P1-2: every per-round relationship delta is clipped to ±0.03.
            d_close = max(-0.03, min(0.03, d_close))
            conflict_step = max(-0.03, min(0.03, conflict_step))
            repair_act_step = max(-0.03, min(0.03, repair_act_step))
            closeness = max(0.0, min(1.0, closeness + d_close))
            conflict = max(0.0, min(1.0, conflict + conflict_step))
            repair = max(0.0, min(1.0, repair + repair_act_step))
            if _writes:
                rel["state"] = dict(state, trust=round(trust, 3), closeness=round(closeness, 3),
                                    conflict=round(conflict, 3), repair=round(repair, 3),
                                    predictability=state.get("predictability", 0.5))
                data["relationship"] = rel
                self._save_user_record(event, data)
            core.relationship_dynamics = dict(dyn, d_closeness=d_close,
                                              conflict_step=conflict_step,
                                              repair_step=repair_act_step,
                                              gottman=horsemen)
            if getattr(self, "learning_relationship_enabled", False):
                self._learning_relationship_update(
                    core, str(getattr(event, "unified_msg_origin", "default")),
                    disclosure=disclosure, overreach=overreach)
            if getattr(self, "big5_effect_enabled", False):
                core.big5_effect = self._big5_effect(core)
            _b = getattr(self, "_core_bridge", None)
            if _b is not None and getattr(_b, "enabled", False) and str(getattr(_b, "mode", "off")) == "primary":
                try:
                    _b.relation_update({"trust_delta": 0.0, "intimacy_delta": round(d_close, 4), "event": str(user_text or "")[:120]})
                except Exception:
                    pass
        except Exception:
            pass

    # ---- P2: startup self-check + transactional restore ----
    def _run_env_selfcheck(self) -> dict:
        warnings = []
        checks = {}
        try:
            probe = DATA_DIR / (".write_probe_" + str(int(time.time())))
            probe.write_text("ok", encoding="utf-8")
            probe.unlink(missing_ok=True)
            checks["data_writable"] = True
        except Exception:
            checks["data_writable"] = False
            warnings.append("data 目录不可写")
        version = ""
        try:
            import astrbot as _astrbot
            version = str(getattr(_astrbot, "__version__", "") or "")
        except Exception:
            version = ""
        version_ok = False
        try:
            _parts = [int(x) for x in re.findall(r"\d+", version)[:2]]
            if len(_parts) >= 2:
                version_ok = (4, 16) <= (_parts[0], _parts[1]) < (5, 0)
        except Exception:
            version_ok = False
        if not version:
            warnings.append("AstrBot 版本读取失败")
        elif not version_ok:
            warnings.append("AstrBot 版本不在 >=4.16,<5 范围: " + version)
        persona_present = PROFILE_PATH.exists()
        missing_config = []
        if not persona_present:
            missing_config.append("persona")
            warnings.append("未设置 persona（persona_profile.json 缺失）")
        api_ok = False
        try:
            _api = json.loads(API_CONFIG_PATH.read_text(encoding="utf-8"))
            _blob = json.dumps(_api, ensure_ascii=False).lower()
            api_ok = any(k in _blob for k in ("api_key", "apikey")) and "****" not in _blob
        except Exception:
            api_ok = False
        if not api_ok:
            missing_config.append("api_key")
            warnings.append("未配置 API Key（api_config.json 缺失或为空）")
        checks.update({"astrbot_version": version, "version_ok": version_ok,
                       "persona_present": persona_present, "api_key_present": api_ok,
                       "missing_config": missing_config, "warnings": warnings})
        try:
            (DATA_DIR / "env_checks.json").write_text(
                json.dumps(checks, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            pass
        return checks

    def _commit_restore(self, staged_files, rollback_files) -> tuple:
        """P2: replace files via os.replace; on failure roll back and report."""
        import os as _os
        import shutil as _shutil
        done = []
        created = []
        try:
            for rel, staged in staged_files.items():
                dest = DATA_DIR / rel
                existed = dest.exists()
                dest.parent.mkdir(parents=True, exist_ok=True)
                if getattr(self, "_restore_fail_inject", False):
                    raise RuntimeError("injected restore failure")
                _os.replace(str(staged), str(dest))
                done.append(rel)
                if not existed:
                    created.append(rel)
            return len(done), ""
        except Exception as exc:
            for rel in done:
                backup = rollback_files.get(rel)
                dest = DATA_DIR / rel
                if backup and backup.exists():
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    _shutil.copyfile(str(backup), str(dest))
            # P2: remove files newly created by this failed restore.
            for rel in created:
                try:
                    (DATA_DIR / rel).unlink(missing_ok=True)
                except Exception:
                    pass
            return len(done), str(exc)

    def _record_llm_telemetry(self, kind, outcome, detail="") -> None:
        """task-36: bounded read-only LLM failure/fallback telemetry."""
        if not getattr(self, "llm_telemetry_enabled", False):
            return
        try:
            tele = self._llm_telemetry if isinstance(
                getattr(self, "_llm_telemetry", None), dict) else {"counters": {}, "recent": []}
            counters = tele.get("counters") if isinstance(tele.get("counters"), dict) else {}
            key = "%s:%s" % (str(kind or "?")[:24], str(outcome or "?")[:16])
            counters[key] = min(10 ** 6, int(counters.get(key, 0) or 0) + 1)
            tele["counters"] = dict(sorted(counters.items(), key=lambda kv: -kv[1])[:20])
            recent = tele.get("recent") if isinstance(tele.get("recent"), list) else []
            tele["recent"] = ([{"ts": round(time.time(), 3), "kind": str(kind or "?")[:24],
                                "outcome": str(outcome or "?")[:16],
                                "detail": str(detail or "")[:120]}]
                              + [x for x in recent if isinstance(x, dict)])[:20]
            self._llm_telemetry = tele
        except Exception:
            pass

    @staticmethod
    def _extract_token_usage(response):
        """task-36: read provider usage if present; never guess/estimate."""
        candidates = []
        try:
            candidates.append(getattr(response, "usage", None))
            candidates.append(getattr(response, "usage_metadata", None))
            candidates.append(getattr(response, "token_usage", None))
            raw = getattr(response, "raw_completion", None)
            if isinstance(raw, dict):
                candidates.append(raw.get("usage"))
            elif raw is not None:
                candidates.append(getattr(raw, "usage", None))
        except Exception:
            pass
        for item in candidates:
            data = item if isinstance(item, dict) else None
            if data is None and item is not None:
                try:
                    data = {"prompt_tokens": getattr(item, "prompt_tokens", None),
                            "completion_tokens": getattr(item, "completion_tokens", None),
                            "total_tokens": getattr(item, "total_tokens", None)}
                except Exception:
                    data = None
            if not isinstance(data, dict):
                continue
            try:
                prompt = int(data.get("prompt_tokens") or 0)
                completion = int(data.get("completion_tokens") or 0)
                total = int(data.get("total_tokens") or (prompt + completion))
                cached = int(data.get("cached_tokens")
                             or data.get("prompt_cache_hit_tokens")
                             or data.get("cache_read_input_tokens") or 0)
            except Exception:
                continue
            if prompt or completion or total:
                return {"prompt_tokens": max(0, prompt),
                        "completion_tokens": max(0, completion),
                        "total_tokens": max(0, total),
                        "cached_tokens": max(0, cached)}
        return None

    def _record_token_usage(self, session, usage) -> None:
        if not getattr(self, "token_usage_enabled", False) or not isinstance(usage, dict):
            return
        try:
            store = self._token_usage if isinstance(
                getattr(self, "_token_usage", None), dict) else {"available": False, "sessions": {}}
            sessions = store.get("sessions") if isinstance(store.get("sessions"), dict) else {}
            key = str(session or "default")[:80]
            item = sessions.get(key) if isinstance(sessions.get(key), dict) else {}
            item["calls"] = min(10 ** 6, int(item.get("calls", 0) or 0) + 1)
            for field in ("prompt_tokens", "completion_tokens", "total_tokens"):
                item[field] = min(10 ** 12, int(item.get(field, 0) or 0)
                                  + int(usage.get(field, 0) or 0))
            item["last_ts"] = round(time.time(), 3)
            sessions[key] = item
            store["sessions"] = sessions
            store["available"] = True
            self._token_usage = store
        except Exception:
            pass

    # ---- P2: persisted, concurrency-safe background LLM budget ----
    def _bg_budget_file(self):
        return DATA_DIR / "background_budget.json"

    def _bg_budget_reserve(self, kind) -> bool:
        import threading
        import json as _json
        lock = getattr(self, "_bg_lock", None)
        if lock is None:
            lock = threading.Lock()
            self._bg_lock = lock
        with lock:
            path = self._bg_budget_file()
            day = time.strftime("%Y-%m-%d")
            state = {}
            try:
                if path.exists():
                    state = _json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                state = {}
            if str(state.get("day") or "") != day:
                state = {"day": day, "calls": 0, "cost": 0.0}
            limit_calls = int(getattr(self, "bg_llm_daily_calls", 200) or 0)
            limit_cost = float(getattr(self, "bg_llm_daily_cost", 2.0) or 0.0)
            if ((limit_calls and int(state.get("calls", 0)) >= limit_calls)
                    or (limit_cost and float(state.get("cost", 0.0)) >= limit_cost)):
                self._bg_llm_usage = state
                return False
            state["calls"] = int(state.get("calls", 0)) + 1
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(_json.dumps(state), encoding="utf-8")
            except Exception:
                pass
            self._bg_llm_usage = state
            return True

    def _bg_budget_add_cost(self, cost) -> None:
        import threading
        import json as _json
        lock = getattr(self, "_bg_lock", None)
        if lock is None:
            lock = threading.Lock()
            self._bg_lock = lock
        try:
            with lock:
                path = self._bg_budget_file()
                day = time.strftime("%Y-%m-%d")
                state = {}
                if path.exists():
                    state = _json.loads(path.read_text(encoding="utf-8"))
                if str(state.get("day") or "") != day:
                    state = {"day": day, "calls": 0, "cost": 0.0}
                state["cost"] = round(float(state.get("cost", 0.0)) + float(cost or 0.0), 6)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(_json.dumps(state), encoding="utf-8")
                self._bg_llm_usage = state
        except Exception:
            pass

    async def _bg_llm_direct(self, kind, provider, prompt, timeout_ms=None):
        """P1-5: budget + timeout wrapper for direct provider.text_chat paths."""
        try:
            if not self._bg_budget_reserve(kind):
                self._record_llm_telemetry(kind, "budget_blocked")
                return None
        except Exception:
            pass
        try:
            _tmo = max(2.0, min(20.0, float(
                timeout_ms or getattr(self, "summary_llm_timeout_ms", 8000)) / 1000.0))
            _call = provider.text_chat(prompt=prompt)
            if _SERVICES is not None:
                resp = await _SERVICES.llm(_call, _tmo)
            else:
                resp = await asyncio.wait_for(_call, timeout=_tmo)
        except asyncio.TimeoutError:
            self._record_llm_telemetry(kind, "timeout")
            return None
        except Exception:
            self._record_llm_telemetry(kind, "call_error")
            return None
        raw = str(getattr(resp, "completion_text", "") or "")
        try:
            self._bg_budget_add_cost(self._cost_for(
                max(1, int(len(prompt) / 2.2)), max(1, int(len(raw) / 2.2))))
        except Exception:
            pass
        return resp

    async def _llm_v2_call(self, kind, prompt, parser, event=None, system_prompt=None):
        if not self._llm_allowed(kind):
            return None
        try:
            provider = await self._provider_for(kind, event)
        except Exception as exc:
            logger.warning("[biocore] llm v2 provider failed (%s): %s", kind, exc)
            self._record_llm_telemetry(kind, "provider_error", str(exc))
            return None
        if provider is None:
            self._record_llm_telemetry(kind, "no_provider")
            return None
        if str(kind) in LLM_BACKGROUND_KINDS:
            try:
                if not self._bg_budget_reserve(kind):
                    self._record_llm_telemetry(kind, "budget_blocked")
                    return None
            except Exception:
                pass
        try:
            _tmo = float(getattr(self, "outbound_timeout_ms", 3000)) / 1000.0
            _call = (provider.text_chat(prompt=prompt, system_prompt=system_prompt)
                     if system_prompt else provider.text_chat(prompt=prompt))
            if _SERVICES is not None:
                resp = await _SERVICES.llm(_call, _tmo)
            else:
                resp = await asyncio.wait_for(_call, timeout=_tmo)
            raw = str(getattr(resp, "completion_text", "") or "").strip()
            if str(kind) in LLM_BACKGROUND_KINDS:
                try:
                    _in = max(1, int(len(prompt) / 2.2))
                    _out = max(1, int(len(raw) / 2.2))
                    self._bg_budget_add_cost(self._cost_for(_in, _out))
                except Exception:
                    pass
            if not raw:
                self._record_llm_telemetry(kind, "empty")
                return None
            return parser(raw)
        except asyncio.TimeoutError:
            self._record_llm_telemetry(kind, "timeout")
            return None
        except Exception as exc:
            logger.warning("[biocore] llm v2 call/paser failed (%s): %s", kind, exc)
            self._record_llm_telemetry(kind, "call_error", str(exc))
            return None

    def _llm_v2_cooldown_ok(self, kind):
        try:
            last = float((getattr(self, "_llm_v2_last", {}) or {}).get(kind, 0.0) or 0.0)
        except Exception:
            last = 0.0
        return (time.time() - last) >= float(LLM_V2_COOLDOWNS.get(kind, 600))

    def _llm_v2_mark(self, kind):
        if not isinstance(getattr(self, "_llm_v2_last", None), dict):
            self._llm_v2_last = {}
        self._llm_v2_last[kind] = time.time()

    def _user_record(self, event):
        try:
            path = self._user_path(event)
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    return data
        except Exception:
            pass
        return {}

    def _save_user_record(self, event, data):
        try:
            if not isinstance(data, dict):
                return
            path = self._user_path(event)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as exc:
            logger.warning("[biocore] user record save failed: %s", exc)

    def _record_calibration(self, event, source, predicted, correct) -> None:
        """Persist one calibration sample in the user relationship doc.

        Record-only: writes relationship.calibration (EWMA/Brier per evidence
        source) via the single user-file writer; it never rewrites trust or any
        other biological field. Called from the memory-conflict branch.
        """
        path = self._user_path(event)
        if not path.exists():
            return
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return
        if not isinstance(data, dict):
            return
        rel = dict(data.get("relationship")) if isinstance(data.get("relationship"), dict) else {}
        rel["calibration"] = relationship_meta.calibration_update(
            rel.get("calibration"), source, predicted, correct)
        try:
            rel["calibration_last_delta"] = self._calibration_step(
                abs(float(predicted) - float(correct)),
                int((rel.get("calibration") or {}).get("samples", 1) or 1))
        except Exception:
            pass
        data["relationship"] = rel
        self._save_user_record(event, data)

    def _relationship_of(self, user_data):
        rel = (user_data or {}).get("relationship") if isinstance(user_data, dict) else None
        return rel if isinstance(rel, dict) else {}

    def _deterministic_hint(self, text, user_data, events_raw, memory_meta, core=None):
        """One bounded deterministic token; interpretation owns the wording."""
        rel = self._relationship_of(user_data)
        repair_state = rel.get("repair_state") if isinstance(rel.get("repair_state"), dict) else {}
        hint = interpretation.repair_strategy_block(repair_state)
        if not hint:
            # G2/L9: refusal is a posture token derived from boundary state. It
            # is not a gate and never decides whether a reply is sent.
            try:
                _state = rel.get("state") if isinstance(rel.get("state"), dict) else {}
                _protocol = relationship_meta.refusal_protocol({
                    "boundary_pressure": float(getattr(core, "boundary_pressure", 0.0) or 0.0),
                    "trust": float(_state.get("trust", 0.5) or 0.5),
                    "conflict": float(_state.get("conflict", 0.0) or 0.0),
                })
                hint = interpretation.refusal_strategy_block(_protocol)
            except Exception:
                hint = ""
        if not hint:
            # A4: deterministic empathy token from core affect (no LLM call).
            try:
                hint = interpretation.empathy_strategy_block(core)
            except Exception:
                hint = ""
        if not hint and interpretation.cause_question(text):
            hint = interpretation.cause_trace_block(getattr(self, "_last_cause_trace", []))
        if not hint:
            hint = interpretation.memory_receipt_block(memory_meta, text)
        if not hint:
            hint = interpretation.grounding_check_block(memory_meta, text)
        if not hint:
            hint = interpretation.response_strategy_block(events_raw)
        return hint

    async def _maybe_llm_hints(self, event, core, user_data, events_raw, memory_meta, text):
        """Optional per-turn strategy refinement; only when a function is ON."""
        parts = [self._deterministic_hint(text, user_data, events_raw, memory_meta, core)]
        rel = self._relationship_of(user_data)
        state = rel.get("state") if isinstance(rel.get("state"), dict) else {}
        repair_state = rel.get("repair_state") if isinstance(rel.get("repair_state"), dict) else {}
        phase = str(repair_state.get("phase") or "stable")
        gate = str((memory_meta or {}).get("gate") or "none")
        try:
            conflict = float(state.get("conflict", 0.5) or 0.5)
            trust = float(state.get("trust", 0.5) or 0.5)
        except Exception:
            conflict, trust = 0.5, 0.5
        try:
            if phase != "stable" and self._llm_v2_cooldown_ok("repair_hint"):
                tag = await self._llm_v2_call(
                    "repair_hint", interpretation.repair_hint_prompt(repair_state),
                    interpretation.parse_repair_hint, event)
                if tag:
                    parts.append("llm_repair=" + tag)
                    self._llm_v2_mark("repair_hint")
            elif events_raw and self._llm_v2_cooldown_ok("empathy_hint"):
                tag = await self._llm_v2_call(
                    "empathy_hint", interpretation.empathy_hint_prompt(events_raw),
                    interpretation.parse_empathy_hint, event)
                if tag:
                    parts.append("llm_empathy=" + tag)
                    self._llm_v2_mark("empathy_hint")
            elif gate in ("semi", "force") and self._llm_v2_cooldown_ok("pragmatics_hint"):
                tag = await self._llm_v2_call(
                    "pragmatics_hint", interpretation.pragmatics_hint_prompt(memory_meta),
                    interpretation.parse_pragmatics_hint, event)
                if tag:
                    parts.append("llm_pragma=" + tag)
                    self._llm_v2_mark("pragmatics_hint")
            elif (conflict < 0.45 and trust > 0.5 and self._llm_v2_cooldown_ok("humor_hint")):
                tag = await self._llm_v2_call(
                    "humor_hint", interpretation.humor_hint_prompt(rel),
                    interpretation.parse_humor_hint, event)
                if tag and tag != "none":
                    parts.append("humor=" + tag)
                    self._llm_v2_mark("humor_hint")
        except Exception as exc:
            logger.warning("[biocore] llm v2 hint failed: %s", exc)
        hint = interpretation.combine_strategy_hint(*parts)
        self._last_strategy_hint = hint
        return hint

    async def _maybe_tom_probe(self, event, core, text, user_data, memory_meta):
        """L-T06: optional bounded ToM annotation; never changes core state."""
        if not self._llm_allowed("tom_probe") or not self._llm_v2_cooldown_ok("tom_probe"):
            return
        try:
            recent = [str(h.get("text") or "") for h in (core.history or [])[-6:]]
            refs = [str(x) for x in (getattr(self, "_last_memory_entries", []) or []) if str(x)][:6]
            proposal = await self._llm_v2_call(
                "tom_probe",
                interpretation.tom_prompt(user_data, recent, memory_lines=refs),
                lambda raw: interpretation.parse_tom_update(raw, allowed_refs=refs),
                event)
            if not proposal:
                return
            updated = relationship_meta.apply_tom_update(user_data, proposal, allowed_refs=refs)
            if updated:
                self._save_user_record(event, updated)
                self._llm_v2_mark("tom_probe")
        except Exception as exc:
            logger.warning("[biocore] tom probe failed: %s", exc)

    async def _maybe_relationship_impression(self, event, core):
        """L-T01/A3: bounded impression writing; deterministic by default.

        The LLM path stays available behind the per-function switch (default
        OFF). With the switch off, the relation numbers are mapped to a short
        deterministic template. Neither path touches trust or core state.
        """
        if not self._llm_v2_cooldown_ok("relationship_impression"):
            return
        try:
            events = [e for e in self._event_archive(12) if isinstance(e, dict)]
            important = [e for e in events
                         if float(e.get("importance", 0.0) or 0.0) >= 0.6]
            if len(important) < 3:
                return
            allowed = [str(e.get("id") or "") for e in important if str(e.get("id") or "")]
            if len(allowed) < 3:
                return
            user_data = self._user_record(event)
            current = self._relationship_of(user_data)
            if self._llm_allowed("relationship_impression"):
                proposal = await self._llm_v2_call(
                    "relationship_impression",
                    interpretation.relationship_impression_prompt(important, current),
                    lambda raw: interpretation.parse_relationship_impression(
                        raw, allowed_refs=allowed),
                    event)
                if not proposal:
                    return
            else:
                proposal = interpretation.relationship_impression_template(
                    current, len(important))
                if not proposal.get("traits"):
                    return
                proposal["evidence_refs"] = allowed[:6]
            updated = relationship_meta.apply_relationship_impression(
                current, proposal, allowed_refs=allowed)
            if not updated:
                return
            user_data["relationship"] = updated
            self._save_user_record(event, user_data)
            self._llm_v2_mark("relationship_impression")
        except Exception as exc:
            logger.warning("[biocore] relationship impression failed: %s", exc)

    async def _maybe_diary(self, event, core):
        """L-T08: at most one bounded diary entry per cooldown (default OFF)."""
        if not self._llm_allowed("diary") or not self._llm_v2_cooldown_ok("diary"):
            return
        try:
            digests = [d for d in (getattr(core, "daily_digests", []) or [])
                       if isinstance(d, dict)]
            if not digests:
                return
            digest = digests[-1]
            allowed = [str(x) for x in (digest.get("event_ids") or []) if str(x)]
            if not allowed:
                return
            titles = [str(e.get("title") or "")
                      for e in self._event_archive(10) if isinstance(e, dict)]
            parsed = await self._llm_v2_call(
                "diary", interpretation.diary_prompt(digest, titles),
                lambda raw: interpretation.parse_diary(raw, allowed_event_ids=allowed),
                event)
            if not parsed:
                return
            diary = self.self_model.get("diary")
            if not isinstance(diary, list):
                diary = []
            diary.append({"ts": time.time(), "date": str(digest.get("date") or ""),
                          "text": parsed["diary"], "evidence": parsed["evidence"],
                          "generated": True})
            self.self_model["diary"] = diary[-30:]
            self._save_self_model()
            self._llm_v2_mark("diary")
        except Exception as exc:
            logger.warning("[biocore] diary failed: %s", exc)

    async def _maybe_relationship_narrative(self, event, core):
        """L-T12: manual/periodic bounded relationship narrative (default OFF)."""
        if not self._llm_allowed("relationship_narrative"):
            return
        if not self._llm_v2_cooldown_ok("relationship_narrative"):
            return
        try:
            user_data = self._user_record(event)
            rel = self._relationship_of(user_data)
            marks = [m for m in (rel.get("milestones") or []) if isinstance(m, dict)]
            allowed = [str(m.get("key") or m.get("type") or "") for m in marks
                       if str(m.get("key") or m.get("type") or "")]
            if not allowed:
                return
            parsed = await self._llm_v2_call(
                "relationship_narrative",
                interpretation.relationship_narrative_prompt(rel),
                lambda raw: interpretation.parse_relationship_narrative(
                    raw, allowed_refs=allowed), event)
            if not parsed:
                return
            items = self.self_model.get("relationship_narratives")
            if not isinstance(items, list):
                items = []
            items.append({"ts": time.time(), "text": parsed["narrative"],
                          "evidence_refs": parsed["evidence_refs"]})
            self.self_model["relationship_narratives"] = items[-5:]
            self._save_self_model()
            self._llm_v2_mark("relationship_narrative")
        except Exception as exc:
            logger.warning("[biocore] relationship narrative failed: %s", exc)


    def _vision_provider_for(self, event=None):
        """Resolve the vision provider for image caption (never a text LLM)."""
        _b = getattr(self, "_core_bridge", None)
        if _b is not None and getattr(_b, "enabled", False):
            try:
                _last = float(getattr(self, "_media_probe_last", 0.0) or 0.0)
                if time.time() - _last >= 3600:
                    self._media_probe_last = time.time()
                    _b.media_probe()
            except Exception:
                pass
        _cfg = self._function_cfg("image_caption")
        _override = _cfg["provider"]
        _pid = ""
        if _override and _override not in ("follow_llm", "main", "default", ""):
            _pid = _override
        if not _pid:
            try:
                _cfg_all = self.context.get_config()
                _ps = _cfg_all.get("provider_settings", {}) if isinstance(_cfg_all, dict) else {}
                _pid = str(_ps.get("default_image_caption_provider_id") or "exusiai-img")
            except Exception:
                _pid = "exusiai-img"
        try:
            _vp = self.context.get_provider_by_id(_pid)
        except Exception as exc:
            logger.warning("[biocore] vision provider lookup failed (%s): %s", _pid, exc)
            return None
        if _vp is not None and self._provider_kind(_vp) == "vision":
            return _vp
        if _vp is not None:
            logger.warning("[biocore] image_caption provider %s is not a vision provider; ignored", _pid)
        # Fall back to the configured default image provider, but never a text LLM.
        try:
            _cfg = self.context.get_config()
            _ps = _cfg.get("provider_settings", {}) if isinstance(_cfg, dict) else {}
            _def = str(_ps.get("default_image_caption_provider_id") or "")
            if _def and _def != _pid:
                _vp2 = self.context.get_provider_by_id(_def)
                if _vp2 is not None and self._provider_kind(_vp2) == "vision":
                    return _vp2
        except Exception:
            pass
        return None

    async def _compile_profile(self, event):
        text = await self._persona_text(event)
        if not text:
            self.profile = dict(DEFAULT_PROFILE)
            self.persona_text = ""
            self.schema_texts = []
            try:
                PROFILE_PATH.write_text(json.dumps(
                    {"persona": "", "profile": self.profile, "schema": [],
                     "style": dict(getattr(self, "persona_style", {}) or {})},
                    ensure_ascii=False, indent=1), encoding="utf-8")
            except Exception:
                pass
            return
        if not self._llm_allowed("persona_compile"):
            self.persona_text = text
            logger.info("[biocore] persona_compile disabled; keep saved profile")
            return
        _ph = _sha256(text)
        if getattr(self, "_persona_compiled_hash", "") == _ph and getattr(self, "profile", None):
            # Already compiled for this persona: no extra LLM call.
            self.persona_text = text
            logger.info("[biocore] persona already compiled; skip")
            return
        try:
            provider = await self._provider_for("persona_compile", event)
            if provider is None:
                self.profile = dict(DEFAULT_PROFILE)
                return
            # Prompt construction and output validation belong to the
            # interpretation layer; this wiring only calls it.
            system = interpretation.persona_compile_system()
            prompt = interpretation.persona_compile_prompt(text)
            resp = await provider.text_chat(prompt=prompt, system_prompt=system)
            raw = str(getattr(resp, "completion_text", "") or "")
            _compiled = interpretation.parse_persona_compile(raw, DEFAULT_PROFILE)
            self.profile = _compiled.get("profile") or dict(DEFAULT_PROFILE)
            self.schema_texts = list(_compiled.get("schema") or [])
            _style = _compiled.get("style") if isinstance(_compiled.get("style"), dict) else {}
            self.persona_style = {"intimacy_style": str(_style.get("intimacy_style") or "neutral"),
                                  "address_terms": list(_style.get("address_terms") or [])[:3]}
            logger.info("[biocore] persona schema slots=%s style=%s", len(self.schema_texts),
                        self.persona_style.get("intimacy_style"))
        except Exception as exc:
            logger.warning("[biocore] persona compile failed: %s", exc)
            self.profile = dict(DEFAULT_PROFILE)
        self.persona_text = text
        try:
            PROFILE_PATH.write_text(json.dumps(
                {"persona": self.persona_text, "profile": self.profile,
                 "schema": list(getattr(self, "schema_texts", []) or []),
                 "style": dict(getattr(self, "persona_style", {}) or {}),
                 "persona_hash": _sha256(self.persona_text or text)},
                ensure_ascii=False, indent=1), encoding="utf-8")
            self._persona_compiled_hash = _sha256(self.persona_text or text)
            logger.info("[biocore] first-run profile written: %s", PROFILE_PATH)
        except Exception as exc:
            logger.warning("[biocore] profile save failed: %s", exc)

    def _core(self, event) -> BioCore:
        key = str(getattr(event, "unified_msg_origin", "default") or "default")
        if key not in self.cores:
            core = BioCore(self.profile or DEFAULT_PROFILE)
            try:
                core.valence_decay_minutes = float(getattr(self, "valence_decay_minutes", 120.0))
                core.arousal_decay_minutes = float(getattr(self, "arousal_decay_minutes", 30.0))
                core.social_decay_minutes = float(getattr(self, "social_decay_minutes", 180.0))
            except Exception:
                pass
            try:
                safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in key)[:80]
                f = STATE_DIR / (safe + ".json")
                if f.exists():
                    core.load_state(json.loads(f.read_text(encoding="utf-8")))
            except Exception:
                pass
            # Task-15: readiness is owned by plugin config, never restored from
            # state; the optional noise seed is applied only when autonomy is on.
            core.autonomy_enabled = bool(getattr(self, "proactive_autonomy", False))
            # Task-28: loop switch + tuning are config-owned, never restored from
            # the state file; re-applied on every core build/config reload.
            core.autonomy_loop_enabled = bool(
                getattr(self, "autonomy_loop_enabled", False))
            core.autonomy_loop_theta_ig = self._loop_cfg_float(
                "autonomy_loop_theta_ig", AUTONOMY_LOOP_THETA_IG,
                AUTONOMY_LOOP_THETA_MIN, AUTONOMY_LOOP_THETA_MAX)
            core.autonomy_loop_margin = self._loop_cfg_float(
                "autonomy_loop_margin", AUTONOMY_LOOP_MARGIN,
                AUTONOMY_LOOP_MARGIN_MIN, AUTONOMY_LOOP_MARGIN_MAX)
            core.autonomy_loop_k_delay = self._loop_cfg_float(
                "autonomy_loop_k_delay", AUTONOMY_LOOP_K_DELAY,
                AUTONOMY_LOOP_K_MIN, AUTONOMY_LOOP_K_MAX)
            core.autonomy_loop_ior_seconds = self._loop_cfg_float(
                "autonomy_loop_ior_seconds", AUTONOMY_LOOP_IOR_SECONDS,
                AUTONOMY_LOOP_IOR_MIN, AUTONOMY_LOOP_IOR_MAX)
            core.autonomy_loop_c0 = self._loop_cfg_float(
                "autonomy_loop_c0", AUTONOMY_LOOP_C0, 0.0, 1.0)
            core.autonomy_loop_c1 = self._loop_cfg_float(
                "autonomy_loop_c1", AUTONOMY_LOOP_C1, 0.0, 1.0)
            core.autonomy_loop_c2 = self._loop_cfg_float(
                "autonomy_loop_c2", AUTONOMY_LOOP_C2, 0.0, 1.0)
            core.autonomy_loop_token_only = bool(
                getattr(self, "autonomy_loop_token_only", True))
            core.reply_consistency_enabled = bool(
                getattr(self, "reply_consistency_enabled", False))
            # 1.3.1 model-layer flags (read-only unless explicitly opt-in).
            core.think_selfcheck_trace_enabled = bool(
                getattr(self, "think_selfcheck_trace_enabled", True))
            core.think_selfcheck_hint_enabled = bool(
                getattr(self, "think_selfcheck_hint_enabled", False))
            core.soft_bound_enabled = bool(
                getattr(self, "soft_bound_enabled", False))
            core.soft_bound_k = float(getattr(self, "soft_bound_k", 0.10) or 0.10)
            core.soft_bound_m_frac = float(
                getattr(self, "soft_bound_m_frac", 0.08) or 0.08)
            core.soft_bound_lam = float(
                getattr(self, "soft_bound_lam", 0.10) or 0.10)
            core.token_budget_enabled = bool(
                getattr(self, "token_budget_enabled", True))
            core.temporal_validity_enabled = bool(
                getattr(self, "temporal_validity_enabled", False))
            core.mood_congruence_enabled = bool(
                getattr(self, "mood_congruence_enabled", False))
            core.emotion_gating_enabled = bool(
                getattr(self, "emotion_gating_enabled", False))
            core.path_monitor_enabled = bool(
                getattr(self, "path_monitor_enabled", False))
            core.injection_trace_enabled = bool(
                getattr(self, "bc_trace_enabled", False))
            core.conflict_gate_enabled = bool(
                getattr(self, "conflict_gate_enabled", False))
            core.rumination_effect_enabled = bool(
                getattr(self, "rumination_effect_enabled", False))
            core.anchor_update_enabled = bool(
                getattr(self, "anchor_update_enabled", False))
            core.identity_threat_stress_enabled = bool(
                getattr(self, "identity_threat_stress_enabled", False))
            core.anchor_weight = float(getattr(self, "anchor_weight", 0.25) or 0.25)
            core.sycophancy_check_enabled = bool(
                getattr(self, "sycophancy_check_enabled", True))
            core.expression_chain_enabled = bool(
                getattr(self, "expression_chain_enabled", False))
            core.relationship_chain_enabled = bool(
                getattr(self, "relationship_chain_enabled", False))
            core.gottman_enabled = bool(getattr(self, "gottman_enabled", False))
            core.big5_effect_enabled = bool(
                getattr(self, "big5_effect_enabled", False))
            core.learning_bandit_enabled = bool(
                getattr(self, "learning_bandit_enabled", False))
            core.learning_relationship_enabled = bool(
                getattr(self, "learning_relationship_enabled", False))
            core.learning_worthiness_enabled = bool(
                getattr(self, "learning_worthiness_enabled", False))
            core.bio_feedback_loops = bool(
                getattr(self, "bio_feedback_loops", False))
            core.bio_learning = bool(getattr(self, "bio_learning", True))
            core.retention_model = str(
                getattr(self, "retention_model", "power_law") or "power_law")
            if core.autonomy_enabled or core.autonomy_loop_enabled:
                try:
                    _seed = int(getattr(self, "noise_seed", 0) or 0)
                    core._noise_seed = max(0, _seed)
                    if _seed > 0:
                        core._rng = __import__("random").Random(_seed)
                except Exception:
                    pass
            self.cores[key] = core
        return self.cores[key]

    def _seed_trust_from_user(self, event, core) -> None:
        """G3: seed core.trust from the user record once per session core.

        Runs only on the first turn after a core is (re)built in this process;
        the core-side method caps the single-step delta at 0.05 and marks the
        core as seeded, so later turns cannot oscillate. User doc is read-only.
        """
        if core is None or getattr(core, "_user_trust_seeded", False):
            return
        try:
            path = self._user_path(event)
            if not path.exists():
                return
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                return
            core.seed_trust_from_user(
                data.get("trust", 0.5), TRUST_SEED_WEIGHT, TRUST_SEED_MAX_DELTA)
        except Exception:
            pass

    def _is_private_event(self, event) -> bool:
        """Task-15: only private chats can ever trigger autonomy output."""
        try:
            umo = str(getattr(event, "unified_msg_origin", "") or "")
            if "GroupMessage" in umo or "GuildMessage" in umo:
                return False
            check = getattr(event, "is_private_chat", None)
            if callable(check):
                return bool(check())
            return False
        except Exception:
            return False

    def _loop_cfg_float(self, key: str, default: float,
                        lo: float, hi: float) -> float:
        """Read one numeric autonomy-loop config value (finite + clamped)."""
        try:
            value = float(self.config.get(key, default))
        except Exception:
            return float(default)
        if value != value or value in (float("inf"), float("-inf")):
            return float(default)
        return max(float(lo), min(float(hi), value))

    def _update_autonomy_readiness(self, core, user_data=None) -> dict:
        """Task-15: ask L1 to compute readiness only when autonomy is enabled."""
        if not getattr(self, "proactive_autonomy", False) or core is None:
            return {}
        try:
            return core.autonomy_state(self._relationship_of(user_data))
        except Exception:
            return {}

    def _autonomy_template(self, core) -> str:
        """Task-15: state-style deterministic proactive text (no summaries/LLM).

        Uses only need + current emotion + closeness band, so the send cannot
        leak event titles or stale summaries and stays reproducible.
        """
        labels = getattr(core, "labels", {}) or {}
        need = str(labels.get("need") or "talk")
        emotion = str(labels.get("emotion") or "neutral")
        need_txt = {"space": "你先忙，我不打扰。",
                    "share": "想听听你今天的碎片。",
                    "vent": "要是想说，我在。",
                    "be_heard": "我在听。",
                    "talk": "想和你说两句。"}.get(need, "想和你说两句。")
        emotion_txt = {"joy": "心情还算轻",
                       "sadness": "心里有点沉",
                       "anger": "有点憋着火",
                       "fear": "有点不安",
                       "loneliness": "有点想人陪",
                       "neutral": "情绪平稳"}.get(emotion, "情绪平稳")
        try:
            rel = getattr(core, "relationship_context", None) or {}
            closeness = float((rel.get("state") or {}).get("closeness", 0.5) or 0.5)
        except Exception:
            closeness = 0.5
        if closeness >= 0.65:
            close_txt = "和你还挺亲近"
        elif closeness <= 0.35:
            close_txt = "和你有点距离"
        else:
            close_txt = "和你平常"
        return ("%s%s，%s。" % (need_txt, emotion_txt, close_txt))[:AUTONOMY_MAX_CHARS_MAX]

    def _autonomy_gate(self, core, relationship, now=None):
        """Task-15: L3 applies send gates to an L1 readiness result."""
        if core is None:
            return None, {"enabled": False}
        try:
            current = float(now if now is not None else time.time())
            state = core.autonomy_state(relationship, now=current)
            if not state.get("enabled") or not state.get("ready"):
                return None, state or {}
            # Stage-2: refusal_protocol is now a real gate, not a posture token.
            rel_state = relationship.get("state") if isinstance(relationship, dict) else {}
            rel_state = rel_state if isinstance(rel_state, dict) else {}
            try:
                protocol = relationship_meta.refusal_protocol({
                    "boundary_pressure": float(getattr(core, "boundary_pressure", 0.0) or 0.0),
                    "trust": float(rel_state.get("trust", 0.5) or 0.5),
                    "conflict": float(rel_state.get("conflict", 0.0) or 0.0),
                })
            except Exception:
                protocol = {"mode": "comply"}
            if str(protocol.get("mode") or "comply") == "decline":
                return None, state
            if str(protocol.get("mode") or "comply") == "negotiate":
                state = dict(state)
                _cap = 90
                # task-35: opt-in refusal brevity also tightens proactive output.
                if getattr(self, "refusal_brevity_enabled", False):
                    _cap = 60
                state["max_chars"] = min(int(state.get("max_chars") or 120), _cap)
            hour = time.localtime(current).tm_hour
            if AUTONOMY_QUIET_START_HOUR <= hour < AUTONOMY_QUIET_END_HOUR:
                return None, state
            last_ts = float(state.get("last_sent_ts", 0.0) or 0.0)
            if last_ts > 0 and (current - last_ts) < AUTONOMY_COOLDOWN_SECONDS:
                return None, state
            day = time.strftime("%Y-%m-%d", time.localtime(current))
            sent_count = int(state.get("sent_count", 0) or 0)
            if str(state.get("sent_day") or "") != day:
                sent_count = 0
            if sent_count >= AUTONOMY_DAILY_CAP:
                return None, state
            max_chars = int(state.get("max_chars") or 120)
            text = self._autonomy_template(core)[:max(1, max_chars)].strip()
            return (text or None), state
        except Exception:
            return None, {"enabled": False}

    async def _maybe_proactive_send(self, event, core, now=None) -> bool:
        """Task-15: private-only send of the deterministic template."""
        if not getattr(self, "proactive_autonomy", False):
            return False
        if not getattr(self, "proactive_send", False) or core is None:
            return False
        if not self._is_private_event(event):
            return False
        try:
            current = float(now if now is not None else time.time())
            try:
                user_data = self._user_record(event)
            except Exception:
                user_data = {}
            text, state = self._autonomy_gate(
                core, self._relationship_of(user_data), now=current)
            if not text:
                return False
            await event.send(MessageChain([Plain(text)]))
            day = time.strftime("%Y-%m-%d", time.localtime(current))
            sent_count = int(state.get("sent_count", 0) or 0)
            if str(state.get("sent_day") or "") != day:
                sent_count = 0
            core._proactive_autonomy.update({
                "last_sent_ts": round(current, 3),
                "sent_day": day,
                "sent_count": sent_count + 1,
                "last_sent_chars": len(text),
            })
            return True
        except Exception as exc:
            logger.warning("[biocore] proactive send failed: %s", exc)
            return False

    def _register_autonomy_session(self, event) -> None:
        """Task-15: remember one private session for the background generator."""
        try:
            umo = str(getattr(event, "unified_msg_origin", "") or "").strip()
            if not umo:
                return
            sid, sname = self._speaker(event)
            self._autonomy_private_sessions[umo] = {
                "umo": umo, "sender_id": sid, "sender_name": sname,
                "ts": round(time.time(), 3),
            }
            if len(self._autonomy_private_sessions) > 20:
                _items = sorted(self._autonomy_private_sessions.items(),
                                key=lambda kv: float(kv[1].get("ts", 0.0) or 0.0),
                                reverse=True)[:20]
                self._autonomy_private_sessions = dict(_items)
        except Exception:
            pass

    def _ensure_autonomy_task(self) -> None:
        """P0-1: start the generator only when task-15 or task-28 is on."""
        if not (getattr(self, "proactive_autonomy", False)
                or getattr(self, "autonomy_loop_enabled", False)):
            return
        try:
            task = getattr(self, "_autonomy_task", None)
            if task is None or task.done():
                self._autonomy_task = asyncio.create_task(self._autonomy_loop())
        except Exception:
            pass

    async def _autonomy_loop(self) -> None:
        """P0-1: 5-minute deterministic tick; exits immediately when disabled."""
        try:
            while (getattr(self, "proactive_autonomy", False)
                   or getattr(self, "autonomy_loop_enabled", False)):
                await asyncio.sleep(AUTONOMY_TICK_SECONDS)
                if not (getattr(self, "proactive_autonomy", False)
                        or getattr(self, "autonomy_loop_enabled", False)):
                    break
                try:
                    await self._autonomy_tick()
                except Exception:
                    pass
        except asyncio.CancelledError:
            return
        except Exception:
            return

    @staticmethod
    def _autonomy_exit_plan(acted: bool, loop_on: bool, proactive_on: bool,
                            proactive_send: bool, token_only: bool) -> str:
        """Single-exit decision for one autonomy tick (spec §7.1 / S20).

        Returns "token" (loop broadcast only; nothing is sent), "send" (the
        existing task-15 send gate may run) or "none". It can never return two
        exits for the same session/tick.
        """
        if not proactive_on or not proactive_send:
            return "token" if acted else "none"
        if acted and loop_on and token_only:
            return "token"
        return "send"

    async def _autonomy_tick(self, now=None) -> list:
        """One autonomous tick over remembered PRIVATE sessions (task-15+task-28).

        Task-28 adds the candidate/arbitration token broadcast. Exit mutual
        exclusion (S20): per session per tick, either the loop broadcasts one
        token (token-only => nothing sent) or the existing task-15 send gate may
        send at most once -- never both.
        """
        sent = []
        loop_on = bool(getattr(self, "autonomy_loop_enabled", False))
        proactive_on = bool(getattr(self, "proactive_autonomy", False))
        if not (loop_on or proactive_on):
            return sent
        try:
            current = float(now if now is not None else time.time())
        except Exception:
            current = time.time()
        for umo, info in list(getattr(self, "_autonomy_private_sessions", {}).items()):
            try:
                if current - float(info.get("ts", 0.0) or 0.0) > 86400:
                    continue
                cores = getattr(self, "cores", None)
                core = cores.get(umo) if isinstance(cores, dict) else None
                if core is None or not (getattr(core, "autonomy_enabled", False)
                                        or getattr(core, "autonomy_loop_enabled", False)):
                    continue
                # Unified noise model: one update point per tick.
                try:
                    core.noise_tick(now=current)
                except Exception:
                    pass
                target = _AutonomySendTarget(
                    self, umo, info.get("sender_id", ""),
                    info.get("sender_name", ""), private=True)
                acted = False
                if loop_on and getattr(core, "autonomy_loop_enabled", False):
                    try:
                        user_data = self._user_record(target)
                        loop_result = core.autonomy_loop_tick(
                            self._relationship_of(user_data), now=current,
                            private_chat=True)
                        acted = bool(loop_result.get("ignition"))
                    except Exception as exc:
                        logger.warning("[biocore] autonomy loop tick failed: %s", exc)
                        acted = False
                plan = self._autonomy_exit_plan(
                    acted, loop_on, proactive_on,
                    bool(getattr(self, "proactive_send", False)),
                    bool(getattr(self, "autonomy_loop_token_only", True)))
                if plan == "send":
                    if await self._maybe_proactive_send(target, core, now=current):
                        sent.append(umo)
            except Exception:
                continue
        return sent

    def _readiness_text(self, event) -> str:
        """Task-15: read-only /biocore readiness report (no side effects when off)."""
        if not getattr(self, "proactive_autonomy", False):
            return ("[BioCore] readiness: disabled (proactive_autonomy=false)\n"
                    "proactive_send=%s" % bool(getattr(self, "proactive_send", False)))
        try:
            core = self._core(event)
            try:
                user_data = self._user_record(event)
            except Exception:
                user_data = {}
            state = core.autonomy_state(self._relationship_of(user_data), persist=False)
            sources = state.get("sources") or {}
            noise = sources.get("noise") or {}
            return ("[BioCore] readiness: threshold=%.3f max_chars=%d impulse=%.3f "
                    "ema=%.3f ready=%s enabled=true send=%s\n"
                    "sources: chaos=%.3f echo=%.3f stress_load=%.3f drive_dev=%.3f "
                    "trust=%.3f closeness=%.3f gain=%.3f noise_seed=%s "
                    "noise(st=%s en=%s so=%s at=%s va=%s)" % (
                        float(state.get("threshold", 0.0)),
                        int(state.get("max_chars", 0)),
                        float(state.get("impulse", 0.0)),
                        float(state.get("impulse_ema", 0.0)),
                        bool(state.get("ready")),
                        bool(getattr(self, "proactive_send", False)),
                        float(state.get("chaos", 0.0)),
                        float(sources.get("echo_trace", 0.0)),
                        float(sources.get("stress_load", 0.0)),
                        float(sources.get("drive_dev", 0.0)),
                        float(sources.get("trust", 0.5)),
                        float(sources.get("closeness", 0.5)),
                        float(sources.get("autonomy_gain", 1.0)),
                        state.get("noise_seed", 0),
                        noise.get("stress", 0.0), noise.get("energy", 0.0),
                        noise.get("social", 0.0), noise.get("attention", 0.0),
                        noise.get("valence", 0.0)))
        except Exception as exc:
            logger.warning("[biocore] readiness report failed: %s", exc)
            return "[BioCore] readiness: error"

    @filter.command("biocore")
    async def biocore_command(self, event: AstrMessageEvent):
        """Task-15: /biocore readiness read-only output."""
        try:
            raw = str(getattr(event, "message_str", "") or "").strip()
        except Exception:
            raw = ""
        parts = raw.split(None, 1)
        sub = parts[1].strip().lower() if len(parts) > 1 else ""
        if sub == "readiness":
            event.set_result(MessageEventResult().message(
                self._readiness_text(event)).use_t2i(False))
            return
        if sub == "learning" or sub.startswith("learning "):
            core = self._core(event)
            if sub == "learning reset":
                try:
                    core._learning = {"version": 1,
                                      "params": {"regulation_q": {}, "trust_alpha": 0.30,
                                                 "learning_rate": LEARNING_Q_ALPHA},
                                      "last_update": 0.0, "updates_count": 0, "log": []}
                    event.set_result(MessageEventResult().message(
                        "[BioCore] learning reset done").use_t2i(False))
                except Exception:
                    event.set_result(MessageEventResult().message(
                        "[BioCore] learning reset failed").use_t2i(False))
                return
            try:
                state = json.dumps(core._learning, ensure_ascii=False)[:1500]
            except Exception:
                state = "{}"
            event.set_result(MessageEventResult().message(
                "[BioCore] learning enabled=%s retention=%s\n%s" % (
                    bool(getattr(core, "bio_learning", False)),
                    str(getattr(core, "retention_model", "power_law")), state)).use_t2i(False))
            return
        event.set_result(MessageEventResult().message(
            "用法：/biocore readiness | /biocore learning | /biocore learning reset").use_t2i(False))

    @filter.command("biocore_core")
    async def biocore_core_command(self, event: AstrMessageEvent):
        """Switch core mode from chat: /biocore_core off|shadow|primary (admin only)."""
        try:
            from .biocore_model import core_commands as _core_commands
        except Exception:
            from biocore_model import core_commands as _core_commands
        try:
            raw = str(getattr(event, "message_str", "") or "")
            reply = await _core_commands.run_core_command(self, raw, event, via="command")
        except Exception as exc:
            reply = "切换失败：" + type(exc).__name__
        event.set_result(MessageEventResult().message(reply).use_t2i(False))

    @filter.command("biocore_rollback")
    async def biocore_rollback_command(self, event: AstrMessageEvent):
        """One-click rollback to the old engine from chat (admin only)."""
        try:
            from .biocore_model import core_commands as _core_commands
        except Exception:
            from biocore_model import core_commands as _core_commands
        try:
            reply = await _core_commands.run_rollback_command(self, event, via="command")
        except Exception as exc:
            reply = "回退失败：" + type(exc).__name__
        event.set_result(MessageEventResult().message(reply).use_t2i(False))

    async def _ensure_profile(self, event):
        if not self.profile and self.first_run_persona_compile:
            await self._compile_profile(event)
        elif not self.profile:
            self.profile = dict(DEFAULT_PROFILE)
            self.persona_text = ""

    def _settings_path(self):
        return DATA_DIR / "settings.json"

    def _load_settings(self):
        try:
            p = self._settings_path()
            if p.exists():
                d = json.loads(p.read_text(encoding="utf-8"))
                # Single source of truth = AstrBot plugin config. Legacy dashboard
                # toggles in settings.json only apply when config does not define
                # the key (otherwise they silently overrode plugin config).
                for key in ("proactive_reply", "memory_dedup_embedding", "inject_intent",
                            "kb_enabled", "hybrid_retrieval", "safety_enabled",
                            "llm_memory_candidates", "llm_only_reply_summary",
                            "we_memory_enabled"):
                    if key in d and key not in self.config:
                        setattr(self, key, bool(d[key]))
                if "safety_enabled" in d and "safety_enabled" not in self.config:
                    self.safety_enabled = bool(d.get("safety_enabled"))
                    self.cross_session_memory = not self.safety_enabled
                    self.sensitive_memory_protection = self.safety_enabled
                if "persona_id" in d and "persona_id" not in self.config:
                    self.persona_id = str(d.get("persona_id") or "").strip()
                if isinstance(d.get("kb_names"), list) and "kb_names" not in self.config:
                    self.kb_names = [str(x) for x in d.get("kb_names") if str(x).strip()]
        except Exception as exc:
            logger.warning("[biocore] settings load failed: %s", exc)

    def _save_settings(self):
        try:
            self._settings_path().write_text(json.dumps({
                "proactive_reply": bool(self.proactive_reply),
                "memory_dedup_embedding": bool(self.memory_dedup_embedding),
                "hybrid_retrieval": bool(getattr(self, "hybrid_retrieval", True)),
                "safety_enabled": bool(getattr(self, "safety_enabled", False)),
                "llm_memory_candidates": bool(
                    getattr(self, "llm_memory_candidates", True)),
                "we_memory_enabled": bool(getattr(self, "we_memory_enabled", False)),
            "bc_prompt_mode": str(getattr(self, "bc_prompt_mode", "telemetry") or "telemetry"),
            "summary_max_chars": int(getattr(self, "summary_max_chars", 0) or 0),
            "llm_only_reply_summary": bool(
                    getattr(self, "llm_only_reply_summary", True)),
                "persona_id": str(getattr(self, "persona_id", "") or ""),
                "inject_intent": bool(self.inject_intent),
                "kb_enabled": bool(getattr(self, "kb_enabled", False)),
                "kb_names": list(getattr(self, "kb_names", [])),
            }, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as exc:
            logger.warning("[biocore] settings save failed: %s", exc)

    async def _persist_plugin_config(self, updates: dict):
        try:
            if isinstance(self.config, dict):
                self.config.update(updates)
                saver = getattr(self.config, "save_config_async", None)
                if saver:
                    await saver(updates)
                else:
                    saver2 = getattr(self.config, "save_config", None)
                    if saver2:
                        saver2(updates)
        except Exception as exc:
            logger.warning("[biocore] plugin config sync failed: %s", exc)

    def _rebuild_core_bridge(self) -> bool:
        """Rebuild CoreBridge from the just-saved config; False -> pending restart."""
        try:
            self._core_bridge = CoreBridge(self.config, DATA_DIR) if CoreBridge is not None else None
            return self._core_bridge is not None
        except Exception:
            self._core_bridge = None
            return False

    def _load_api_config(self):
        try:
            if API_CONFIG_PATH.exists():
                d = json.loads(API_CONFIG_PATH.read_text(encoding="utf-8"))
                if isinstance(d, dict):
                    self.api_config = d
        except Exception as exc:
            logger.warning("[biocore] api config load failed: %s", exc)
            self.api_config = {}
        self._load_llm_functions()

    def _load_llm_functions(self):
        """Load per-function LLM switches and provider overrides.

        Embedding/rerank model selection is intentionally NOT per-function:
        the deterministic event-ranking pipeline always follows the API 接入
        defaults (global embedding, global rerank with deterministic local
        fallback). Legacy configs that stored embedding_provider/rerank_provider
        are migrated by dropping those keys.
        """
        _defaults = {
            _name: {"enabled": LLM_FUNCTION_DEFAULTS[_name],
                    "provider": "follow_llm"}
            for _name in LLM_FUNCTIONS
        }
        _saved = self.api_config.get("functions") if isinstance(self.api_config.get("functions"), dict) else None
        if _saved is None:
            # Legacy migration: strict=true meant "summaries only"; strict=false
            # meant all capabilities available.
            _legacy = bool(getattr(self, "llm_only_reply_summary", True))
            _defaults = {
                _name: {"enabled": (LLM_FUNCTION_DEFAULTS[_name] if _legacy else True),
                         "provider": "follow_llm"}
                for _name in LLM_FUNCTIONS
            }
            self.llm_functions = _defaults
            self.api_config["functions"] = _defaults
            self._save_api_config()
            return
        _merged = {}
        _dropped_legacy = False
        for _name in LLM_FUNCTIONS:
            _raw = _saved.get(_name)
            _item = _raw if isinstance(_raw, dict) else {}
            if isinstance(_raw, dict) and (
                    "embedding_provider" in _raw or "rerank_provider" in _raw):
                _dropped_legacy = True
            _merged[_name] = {
                "enabled": bool(_item.get("enabled", LLM_FUNCTION_DEFAULTS[_name])),
                "provider": str(_item.get("provider") or "follow_llm"),
            }
        self.llm_functions = _merged
        self.api_config["functions"] = _merged
        if _dropped_legacy:
            # Persist the migration once so the dead per-function model keys go
            # away from data/api_config.json.
            self._save_api_config()

    def _save_api_config(self):
        try:
            API_CONFIG_PATH.write_text(json.dumps(self.api_config, ensure_ascii=False, indent=1),
                                        encoding="utf-8")
        except Exception as exc:
            logger.warning("[biocore] api config save failed: %s", exc)

    def _config_providers(self):
        try:
            cfg = self.context.get_config()
            if isinstance(cfg, dict):
                return list(cfg.get("provider") or [])
            getter = getattr(cfg, "get", None)
            if getter:
                return list(getter("provider") or [])
        except Exception:
            pass
        return []

    def _config_provider_sources(self):
        try:
            cfg = self.context.get_config()
            if isinstance(cfg, dict):
                return list(cfg.get("provider_sources") or [])
            getter = getattr(cfg, "get", None)
            if getter:
                return list(getter("provider_sources") or [])
        except Exception:
            pass
        return []

    def _speaker(self, event):
        """Return the current sender's (id, display name) if available."""
        sid = ""
        name = ""
        try:
            fn = getattr(event, "get_sender_id", None)
            if callable(fn):
                sid = str(fn() or "")
        except Exception:
            pass
        try:
            fn = getattr(event, "get_sender_name", None)
            if callable(fn):
                name = str(fn() or "")
        except Exception:
            pass
        try:
            obj = getattr(event, "message_obj", None)
            sender = getattr(obj, "sender", None) if obj is not None else None
            if sender is not None:
                if not sid:
                    sid = str(getattr(sender, "user_id", "") or "")
                if not name:
                    name = str(getattr(sender, "nickname", "") or "")
        except Exception:
            pass
        return sid.strip(), name.strip()

    @staticmethod
    def _image_ref(img) -> str:
        if not isinstance(img, Image):
            return ""
        return str(getattr(img, "url", "") or getattr(img, "file", "") or getattr(img, "path", "") or "").strip()

    def _text_from_components(self, event) -> str:
        parts = []
        try:
            for msg in event.get_messages() or []:
                text = getattr(msg, "text", None)
                if isinstance(text, str):
                    parts.append(text)
        except Exception:
            pass
        return " ".join(parts)

    def _image_refs(self, event) -> list:
        if not getattr(self, "image_recognition_enabled", True):
            return []
        try:
            messages = event.get_messages() or []
        except Exception:
            return []
        refs = []
        private = bool(getattr(event, "is_private_chat", lambda: False)())
        raw_text = str(getattr(event, "message_str", "") or "") + " " + self._text_from_components(event)
        if private:
            for msg in messages:
                if isinstance(msg, Image):
                    ref = self._image_ref(msg)
                    if ref:
                        refs.append(ref)
                if isinstance(msg, Reply):
                    for child in (getattr(msg, "chain", None) or []):
                        ref = self._image_ref(child)
                        if ref:
                            refs.append(ref)
        else:
            if not any(w and w in raw_text for w in (getattr(self, "image_trigger_words", None) or [])):
                return []
            for msg in messages:
                if isinstance(msg, Reply):
                    for child in (getattr(msg, "chain", None) or []):
                        ref = self._image_ref(child)
                        if ref:
                            refs.append(ref)
        seen = set()
        out = []
        for ref in refs:
            if ref not in seen:
                seen.add(ref)
                out.append(ref)
        return out

    def _load_image_cache(self) -> dict:
        try:
            if IMAGE_CACHE_PATH.exists():
                d = json.loads(IMAGE_CACHE_PATH.read_text(encoding="utf-8"))
                if isinstance(d, dict):
                    return d
        except Exception:
            pass
        return {}

    def _save_image_cache(self, cache: dict) -> None:
        try:
            if len(cache) > self.image_cache_max_entries:
                items = sorted(cache.items(), key=lambda kv: float(kv[1].get("ts", 0) or 0), reverse=True)
                cache = dict(items[:self.image_cache_max_entries])
            IMAGE_CACHE_PATH.write_text(json.dumps(cache, ensure_ascii=False), encoding="utf-8")
        except Exception as exc:
            logger.warning("[biocore] image cache save failed: %s", exc)

    async def _image_health_ok(self) -> bool:
        if int(self.image_service_port or 0) <= 0:
            return False
        def _check() -> bool:
            try:
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self.image_service_port}/v1/models",
                    headers={"Accept": "application/json"})
                with urllib.request.urlopen(req, timeout=2) as resp:
                    return 200 <= int(resp.status) < 300
            except Exception:
                return False
        try:
            return await asyncio.to_thread(_check)
        except Exception:
            return False

    def _image_idle_watch(self):
        if self._image_proc is None:
            return
        if self._image_idle_task is not None and not self._image_idle_task.done():
            return
        self._image_idle_task = asyncio.create_task(self._image_idle_loop())

    async def _image_idle_loop(self):
        try:
            while True:
                await asyncio.sleep(5)
                if self._image_proc is None:
                    return
                if time.time() - float(self._image_last_used or 0.0) >= self.image_service_idle_seconds:
                    await self._stop_image_service()
                    return
        finally:
            self._image_idle_task = None

    async def _stop_image_service(self):
        proc = self._image_proc
        self._image_proc = None
        if proc is None:
            return
        try:
            if proc.poll() is None:
                subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               timeout=10, check=False)
        except Exception as exc:
            logger.warning("[biocore] image service stop failed: %s", exc)
        try:
            proc.wait(timeout=5)
        except Exception:
            pass
        logger.info("[biocore] image service stopped after idle")

    async def _ensure_image_service(self) -> bool:
        if int(self.image_service_port or 0) <= 0:
            return False
        self._image_last_used = time.time()
        if await self._image_health_ok():
            return True
        if self._image_service_lock is None:
            self._image_service_lock = asyncio.Lock()
        async with self._image_service_lock:
            if await self._image_health_ok():
                self._image_last_used = time.time()
                return True
            try:
                if (not self.image_llama_server or not self.image_llama_model
                        or not self.image_llama_server.is_file()
                        or not self.image_llama_model.is_file()):
                    logger.warning("[biocore] image service paths missing; configure image_llama_server / image_llama_model")
                    return False
                args = [str(self.image_llama_server), "-m", str(self.image_llama_model)]
                if self.image_llama_mmproj and self.image_llama_mmproj.is_file():
                    args += ["--mmproj", str(self.image_llama_mmproj)]
                args += ["--host", "127.0.0.1", "--port", str(self.image_service_port),
                         "-ngl", "99", "-c", "8192", "-np", "1", "-lm", "none",
                         "-cram", "0", "-ctxcp", "0", "--no-warmup"]
                flags = 0x08000000 if os.name == "nt" else 0
                self._image_proc = subprocess.Popen(args, stdout=subprocess.DEVNULL,
                                                    stderr=subprocess.DEVNULL,
                                                    creationflags=flags)
                logger.info("[biocore] image service starting pid=%s", self._image_proc.pid)
                # P0-4: never block the reply path >5s; background start continues.
                for _ in range(20):
                    if await self._image_health_ok():
                        self._image_last_used = time.time()
                        self._image_idle_watch()
                        return True
                    await asyncio.sleep(0.25)
                self._image_fail_count = int(getattr(self, "_image_fail_count", 0)) + 1
                logger.warning("[biocore] image service did not become ready (5s)")
                await self._stop_image_service()
                return False
            except Exception as exc:
                logger.warning("[biocore] image service start failed: %s", exc)
                self._image_proc = None
                return False

    def _load_self_model(self) -> dict:
        d = {
            "who_am_i": "一个会持续受聊天影响、但不会被单条消息完全定义的角色。",
            "boundaries": ["不接受被当作没有感受的工具", "不会被一次互动改写全部立场"],
            "consistency": ["情绪会变，但核心立场不因单次互动翻转"],
            "narrative": "",
            "version": 0,
            "_history": [],
        }
        try:
            if SELF_MODEL_PATH.exists():
                raw = json.loads(SELF_MODEL_PATH.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    for k in d:
                        if k in raw:
                            d[k] = raw[k]
        except Exception:
            pass
        try:
            if not SELF_MODEL_PATH.exists():
                self.self_model = d
                self._save_self_model()
        except Exception:
            pass
        return d

    def _save_self_model(self) -> None:
        try:
            SELF_MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
            self.self_model["version"] = int(self.self_model.get("version", 0) or 0) + 1
            _h = list(self.self_model.get("_history") or [])[-20:]
            _h.append({"ts": __import__("time").time(),
                       "who_am_i": self.self_model.get("who_am_i", ""),
                       "narrative": self.self_model.get("narrative", "")})
            self.self_model["_history"] = _h[-20:]
            SELF_MODEL_PATH.write_text(json.dumps(self.self_model, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            pass

    def _update_self_narrative(self, title: str, reflection: str) -> None:
        try:
            if not (title or reflection):
                return
            line = ("%s：%s" % (title, reflection)).strip("： ")
            old = str(self.self_model.get("narrative") or "").strip()
            self.self_model["narrative"] = (line + ("；" + old if old else ""))[:600]
            self._save_self_model()
        except Exception:
            pass

    def _user_path(self, event) -> Path:
        sid, _ = self._speaker(event)
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in (sid or "unknown"))[:60]
        return USER_DIR / (safe + ".json")

    def _we_memory_candidates(self, entries) -> list:
        """Deterministic, evidence-gated we-memory proposals (default off)."""
        out = []
        patterns = (
            ("nickname", ("叫你", "喊你", "外号", "昵称")),
            ("ritual", ("每天", "每次", "习惯", "约好", "固定")),
            ("anniversary", ("纪念日", "周年", "第一次")),
            ("inside_joke", ("梗", "暗号", "约定")),
            ("shared_object", ("我们的", "一起买", "一起做", "送给")),
        )
        for entry in (entries if isinstance(entries, list) else [])[-100:]:
            if not isinstance(entry, dict):
                continue
            text = str(entry.get("text") or "").strip()
            if not text:
                continue
            for mtype, words in patterns:
                if not any(w in text for w in words):
                    continue
                snippet = text[:40]
                out.append({"type": mtype, "text": snippet, "confidence": 0.6,
                            "evidence_refs": [str(entry.get("id") or entry.get("ts") or "m")[:80]]})
                break
        return relationship_meta.merge_we_memory([], out)

    def _summary_cap(self, text) -> str:
        value = str(text or "")
        try:
            cap = int(getattr(self, "summary_max_chars", 0) or 0)
        except Exception:
            cap = 0
        return value[:cap] if cap > 0 else value

    def _event_excerpt(self, text, limit: int = 220) -> str:
        """Compact deterministic-event display text; raw evidence stays in source_texts."""
        value = re.sub(r"\s+", " ", str(text or "").replace("\n", " ")).strip()
        if len(value) <= limit:
            return value
        cut = value[:limit]
        pos = max(cut.rfind("。"), cut.rfind("！"), cut.rfind("？"), cut.rfind("；"))
        if pos >= int(limit * 0.5):
            return cut[:pos + 1].strip()
        return cut.rstrip() + "…"

    @staticmethod
    def _first_sentence(text) -> str:
        """First sentence of a raw event excerpt (used for <=80 summaries)."""
        value = re.sub(r"\s+", " ", str(text or "")).strip()
        if not value:
            return ""
        match = re.search(r"[。！？；!?;]", value)
        return value[:match.end()] if match else value

    def _dual_event_summary_fallback(self, text, title: str = ""):
        """Deterministic bounded big/small summary fallback for event records.

        No LLM is used here: big_summary is a bounded excerpt (<=220 chars) and
        small_summary is the first sentence (or the title) bounded to 80 chars.
        These records are marked summary_status="fallback" by the writers.
        """
        big = self._mask_if_safety(self._event_excerpt(text, 220))[:220]
        small = self._mask_if_safety(
            self._first_sentence(text) or str(title or "").strip())[:80]
        if not big:
            big = small
        if not small:
            small = big[:80]
        return big, small

    def _secondary_emotion(self, core) -> str:
        """Second-highest spectrum emotion excluding the current primary label."""
        if core is None:
            return ""
        try:
            primary = str((getattr(core, "labels", {}) or {}).get("emotion") or "neutral")
            probs = core._spectrum_probs() if callable(getattr(core, "_spectrum_probs", None)) else []
            for item in (probs or []):
                if not isinstance(item, dict):
                    continue
                key = str(item.get("key") or "").strip()[:32]
                if key and key != primary:
                    return key
        except Exception:
            pass
        return ""

    def _event_emotion_layers(self, core) -> list:
        """Emotion layers snapshot for the memory-ball rings (task-65).

        Top-4 EMOTION_SPECTRUM probabilities including the primary emotion,
        normalized to sum 1: [{"emotion": key, "p": weight}, ...]. The field
        is stored once with the archive record, so a later regenerate does not
        rewrite the historical layers. No spectrum data -> [] (rings then use
        the old secondary/inferred fallback; nothing is fabricated).
        """
        try:
            if core is None:
                return []
            probs = core._spectrum_probs() if callable(getattr(core, "_spectrum_probs", None)) else []
            rows = []
            for item in (probs or []):
                if not isinstance(item, dict):
                    continue
                key = str(item.get("key") or "").strip().lower()[:32]
                if not key:
                    continue
                try:
                    weight = float(item.get("p", 0) or 0)
                except Exception:
                    weight = 0.0
                if weight <= 0:
                    continue
                rows.append((key, weight))
            primary = str((getattr(core, "labels", {}) or {}).get("emotion") or "").strip().lower()
            if not rows:
                return [{"emotion": primary, "p": 1.0}] if primary else []
            merged = {}
            for key, weight in rows:
                merged[key] = merged.get(key, 0.0) + weight
            ordered = sorted(merged.items(), key=lambda pair: pair[1], reverse=True)[:4]
            picked = [{"emotion": key, "p": weight} for key, weight in ordered]
            if primary and primary not in [x["emotion"] for x in picked]:
                # The primary emotion must be part of the snapshot even when its
                # spectrum probability is missing/zero; give it a minimal weight
                # so normalization keeps it at the tail.
                picked = picked[:3] + [{"emotion": primary,
                                       "p": max(0.01, merged.get(primary, 0.0))}]
            total = sum(x["p"] for x in picked)
            if total <= 0:
                return []
            out = [{"emotion": x["emotion"], "p": round(x["p"] / total, 4)}
                   for x in picked if x["p"] > 0]
            out.sort(key=lambda x: x["p"], reverse=True)
            return out
        except Exception:
            return []

    def _event_emotion_intensity(self, core) -> float:
        """Emotion-intensity snapshot for ring speed (task-66).

        Prefers the core's own intensity(); otherwise arousal + |valence|.
        None / no core -> 0.0; the orb then falls back to importance or
        emotion_layers[0].p instead of fabricating a value.
        """
        try:
            if core is None:
                return 0.0
            fn = getattr(core, "_intensity", None)
            if callable(fn):
                raw = float(fn())
                if math.isfinite(raw):
                    return round(max(0.0, min(1.0, raw)), 4)
            arousal = float(getattr(core, "a", 0.4) or 0.4)
            valence = abs(float(getattr(core, "v", 0.0) or 0.0))
            return round(max(0.0, min(1.0, 0.5 * arousal + 0.5 * valence)), 4)
        except Exception:
            return 0.0

    def _event_secondary_for_record(self, record) -> str:
        """Secondary emotion for an archived event, from its session core.

        Only used to fill a MISSING emotion_secondary on regenerate: the
        highest spectrum probability is excluded (the primary emotion) and the
        next one wins. No core / no spectrum data -> "" (never fabricated).
        """
        try:
            rec = record if isinstance(record, dict) else {}
            session = str(rec.get("session") or "").strip()
            if not session:
                return ""
            core = None
            cores = getattr(self, "cores", None)
            if isinstance(cores, dict):
                core = cores.get(session)
            if core is None:
                try:
                    core = self._core(types.SimpleNamespace(unified_msg_origin=session))
                except Exception:
                    core = None
            if core is None:
                return ""
            primary = str((getattr(core, "labels", {}) or {}).get("emotion") or "neutral")
            probs = core._spectrum_probs() if callable(getattr(core, "_spectrum_probs", None)) else []
            ordered = []
            for item in (probs or []):
                if not isinstance(item, dict):
                    continue
                key = str(item.get("key") or "").strip()[:32]
                if not key:
                    continue
                try:
                    weight = float(item.get("p", 0) or 0)
                except Exception:
                    weight = 0.0
                ordered.append((weight, key))
            ordered.sort(key=lambda pair: pair[0], reverse=True)
            for _weight, key in ordered:
                if key != primary:
                    return key
        except Exception as exc:
            logger.warning("[biocore] event secondary lookup failed: %s", exc)
        return ""

    @staticmethod
    def _normalize_emotion_nuance(value) -> list:
        """Hidden/composite emotion layer from event_summary (task-64).

        Delegates to the interpretation-layer cleaner: max 3 short Chinese
        labels, deduped, empties dropped. Unknown/garbage input returns [] so
        the deterministic fallback never fabricates a nuance layer.
        """
        try:
            return interpretation.clean_emotion_nuance(value, 3)
        except Exception:
            return []

    def _mask_if_safety(self, text) -> str:
        value = str(text or "")
        try:
            if getattr(self, "safety_enabled", False):
                return memory_meta.mask_sensitive(value)
        except Exception:
            pass
        return value

    def _touch_user(self, event, core=None) -> dict:
        try:
            sid, name = self._speaker(event)
            USER_DIR.mkdir(parents=True, exist_ok=True)
            path = self._user_path(event)
            d = {}
            if path.exists():
                try:
                    d = json.loads(path.read_text(encoding="utf-8"))
                except Exception:
                    d = {}
            d["sender_id"] = sid
            d["sender_name"] = name or d.get("sender_name", "")
            try:
                _prev_last_seen = float(d.get("last_seen", 0) or 0)
            except Exception:
                _prev_last_seen = 0.0
            d["interactions"] = int(d.get("interactions", 0) or 0) + 1
            _now_seen = time.time()
            d["absence"] = relationship_meta.absence_state(_prev_last_seen, _now_seen)
            d["last_seen"] = _now_seen
            d.setdefault("first_seen", time.time())
            _session_key = str(getattr(event, "unified_msg_origin", "") or "").strip()
            if _session_key:
                _sessions = d.get("sessions") if isinstance(d.get("sessions"), list) else []
                _sessions = [str(x) for x in _sessions if str(x) and str(x) != _session_key]
                d["sessions"] = (_sessions[-19:] + [_session_key])[-20:]
            try:
                _ct = float(getattr(core, "trust", 0.5)) if core is not None else 0.5
                _old_trust = float(d.get("trust", 0.5) or 0.5)
                if core is not None and getattr(core, "bio_learning", False):
                    # Nassar 2010 adaptive alpha for the trust EMA.
                    _alpha = memory_meta.nassar_alpha(_ct - _old_trust)
                else:
                    _alpha = 0.30
                _new_trust = _old_trust + _alpha * (_ct - _old_trust)
                if getattr(self, "anchor_update_enabled", False):
                    try:
                        _new_trust = core.blend_prior(
                            _new_trust, _old_trust,
                            float(getattr(core, "anchor_weight", 0.25) or 0.25))
                    except Exception:
                        pass
                d["trust"] = round(max(0.0, min(1.0, _new_trust)), 3)
            except Exception:
                d["trust"] = d.get("trust", 0.5)
            try:
                _prev_rel = d.get("relationship") if isinstance(d.get("relationship"), dict) else {}
                _prev_state = _prev_rel.get("state") if isinstance(_prev_rel.get("state"), dict) else None
                _opp = getattr(core, "opponent", {}) if core is not None else {}
                _opp_v = _opp.get("v", 0.0) if isinstance(_opp, dict) else 0.0
                _rel_state = relationship_meta.relationship_state(
                    trust=d.get("trust", 0.5),
                    social=getattr(core, "social", 0.5) if core is not None else 0.5,
                    stress=getattr(core, "stress", 0.5) if core is not None else 0.5,
                    opponent=_opp_v,
                    previous=_prev_state,
                )
                _mem_doc = self._load_memory(event)
                _entries = _mem_doc.get("entries") if isinstance(_mem_doc, dict) else []
                try:
                    _social_world = relationship_meta.build_social_world(_entries)
                except Exception:
                    _social_world = []
                _we_memory = []
                try:
                    if getattr(self, "we_memory_enabled", False):
                        _we_memory = self._we_memory_candidates(_entries)
                except Exception:
                    _we_memory = []
                _milestones = []
                try:
                    for _ev in self._event_archive(20):
                        _mk = relationship_meta.milestone_from_text(
                            str(_ev.get("title") or "") + " " + str(_ev.get("event") or ""))
                        if _mk:
                            _mk["ts"] = float(_ev.get("ts", 0) or 0)
                            _milestones.append(_mk)
                except Exception:
                    _milestones = []
                d["relationship"] = relationship_meta.update_relationship_record(
                    _prev_rel,
                    state=_rel_state,
                    ts=d.get("last_seen", time.time()),
                    transactive_map=relationship_meta.build_transactive_map(_entries),
                    destination_map=relationship_meta.build_destination_map(_entries),
                    absence=d.get("absence"),
                    social_world=_social_world,
                    milestones=_milestones,
                    we_memory=_we_memory,
                    interactions=d.get("interactions", 0),
                    repair_success=int((_prev_rel.get("repair_state") or {}).get("repair_attempts", 0) or 0),
                    promises_kept=len([x for x in _milestones if x.get("type") == "promise_kept"]),
                    annotations=(_prev_rel.get("annotations")
                                 if isinstance(_prev_rel.get("annotations"), list) else None),
                )
                if core is not None:
                    try:
                        core.set_relationship_context(d.get("relationship"))
                    except Exception:
                        pass
                    # Task-15: relationship delta feeds L1 social/valence noise.
                    try:
                        _rel_now = d.get("relationship") if isinstance(d.get("relationship"), dict) else {}
                        _rel_st = _rel_now.get("state") if isinstance(_rel_now.get("state"), dict) else {}
                        core.integrate_noise(
                            "relationship",
                            social=0.004 * (float(_rel_st.get("closeness", 0.5) or 0.5) - 0.5),
                            valence=0.004 * (float(_rel_st.get("trust", 0.5) or 0.5) - 0.5))
                    except Exception:
                        pass
            except Exception:
                pass
            path.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
            return d
        except Exception:
            return {}

    def _event_archive(self, limit: int = 5, read_only: bool = False) -> list:
        try:
            if not EVENT_ARCHIVE_PATH.exists():
                return []
            lines = EVENT_ARCHIVE_PATH.read_text(encoding="utf-8").splitlines()
            out = []
            forgotten = []
            for line in lines[-max(1, limit * 3):]:
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                if not isinstance(d, dict):
                    continue
                if not d.get("peripheral_forgotten"):
                    try:
                        _age_days = (time.time() - float(d.get("ts", 0) or 0)) / 86400.0
                        _central = float(d.get("centrality", 0.5) or 0.5)
                        if _age_days > (14.0 - 10.0 * _central):
                            d["peripheral_details"] = ""
                            d["peripheral_retention"] = min(float(d.get("peripheral_retention", 1.0) or 1.0), 0.05)
                            d["peripheral_forgotten"] = True
                            forgotten.append(dict(d))
                    except Exception:
                        pass
                # task-46: old records never carried summary_status. Mark them
                # legacy on read only (no rewrite of the stored full text).
                if not str(d.get("summary_status") or "").strip():
                    d["summary_status"] = "legacy"
                out.append(d)
            if forgotten and not read_only:
                self._persist_peripheral_forgetting(forgotten)
            # Recall/event_context are de-duplicated by normalized event_key,
            # newest first; appended duplicates from older versions collapse here.
            dedup = []
            seen = set()
            for d in out[-max(1, limit) * 3:][::-1]:
                key = self._normalize_event_key(
                    str(d.get("event_key") or d.get("title") or ""),
                    str(d.get("title") or ""))
                if key in seen:
                    continue
                seen.add(key)
                dedup.append(d)
                if len(dedup) >= limit:
                    break
            return dedup
        except Exception:
            return []

    @staticmethod
    def _same_archive_event(obj: dict, target: dict) -> bool:
        try:
            if not isinstance(obj, dict) or not isinstance(target, dict):
                return False
            tid = str(target.get("id") or "").strip()
            did = str(obj.get("id") or "").strip()
            if tid and did:
                return tid == did
            if str(obj.get("title") or "") != str(target.get("title") or ""):
                return False
            return abs(float(obj.get("ts", 0) or 0) - float(target.get("ts", 0) or 0)) <= 1.0
        except Exception:
            return False

    def _rewrite_jsonl_atomic(self, path, mutate) -> int:
        """Rewrite a JSONL archive through a sibling temp file + os.replace.

        mutate(obj) returns True when it changed the row. Unparsable lines are
        preserved verbatim and nothing is written unless a row changed.
        """
        tmp = None
        try:
            path = Path(path)
            if not path.exists():
                return 0
            rows = []
            changed = 0
            for line in path.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    rows.append(("raw", line))
                    continue
                try:
                    _changed = bool(mutate(obj))
                except Exception:
                    _changed = False
                if _changed:
                    changed += 1
                rows.append(("obj", obj))
            if not changed:
                return 0
            tmp = path.with_name(path.name + ".tmp_%s_%s" % (os.getpid(), int(time.time() * 1000)))
            with open(tmp, "w", encoding="utf-8") as f:
                for kind, value in rows:
                    if kind == "raw":
                        f.write(str(value) + "\n")
                    else:
                        f.write(json.dumps(value, ensure_ascii=False) + "\n")
            os.replace(tmp, path)
            tmp = None
            return changed
        except Exception as exc:
            logger.warning("[biocore] archive rewrite failed %s: %s", path, exc)
            return 0
        finally:
            try:
                if tmp is not None and Path(tmp).exists():
                    Path(tmp).unlink()
            except Exception:
                pass

    # ---- task-33: deterministic memory-point worthiness + feedback ----
    @staticmethod
    def _worth_num(value, default: float = 0.0, lo: float = 0.0,
                   hi: float = 1.0) -> float:
        """Finite bounded float for worthiness inputs (NaN/Inf -> default)."""
        try:
            number = float(value)
        except Exception:
            return default
        if number != number or number in (float("inf"), float("-inf")):
            return default
        return max(lo, min(hi, number))

    def _worthiness_inputs_for(self, record, core, relationship=None, *,
                               text: str = "", title: str = "",
                               schema=None) -> dict:
        """Build the raw deterministic inputs for compute_worthiness (no LLM)."""
        rec = record if isinstance(record, dict) else {}
        body = str(text or rec.get("event") or rec.get("title") or "")
        heading = str(title or rec.get("title") or "")
        if schema is None:
            try:
                schema = memory_meta.schema_congruence(
                    body or heading, self._self_schema_texts(core))
            except Exception:
                schema = 0.0
        try:
            intensity = float(core._intensity()) if core is not None else 0.0
        except Exception:
            intensity = 0.0
        appraisal = (getattr(core, "appraisal", None)
                     if core is not None else None)
        appraisal = appraisal if isinstance(appraisal, dict) else {}
        importance = self._worth_num(rec.get("importance"), 0.5)
        schema_v = self._worth_num(schema, 0.0)
        self_defining = memory_meta.event_self_defining(schema_v, importance)
        try:
            milestone = 1.0 if relationship_meta.milestone_from_text(
                heading + " " + body) else 0.0
        except Exception:
            milestone = 0.0
        rel = relationship if isinstance(relationship, dict) else {}
        rel_state = rel.get("state") if isinstance(rel.get("state"), dict) else {}
        trust = self._worth_num(rel_state.get("trust"), 0.5)
        closeness = self._worth_num(rel_state.get("closeness"), 0.5)
        conflict = self._worth_num(rel_state.get("conflict"), 0.0)
        repair = self._worth_num(rel_state.get("repair"), 0.0)
        novelty = self._worth_num(appraisal.get("novelty"), 0.0)
        routine = False
        try:
            routine = bool(memory_meta.is_routine_event(
                body or heading, intensity=intensity, novelty=novelty,
                schema=schema_v))
        except Exception:
            routine = False
        # K (core-impact) proxies from existing L1 state.
        momentum = getattr(core, "momentum", None) if core is not None else None
        momentum = momentum if isinstance(momentum, dict) else {}
        pad_delta = self._worth_num(
            2.0 * (abs(self._worth_num(momentum.get("v"), 0.0, -1.0, 1.0))
                   + abs(self._worth_num(momentum.get("a"), 0.0, -1.0, 1.0))
                   + abs(self._worth_num(momentum.get("d"), 0.0, -1.0, 1.0))),
            0.0)
        self_delta = self._worth_num(
            abs(self._worth_num(getattr(core, "boundary_pressure", 0.0), 0.0))
            + abs(self._worth_num(getattr(core, "refusal_readiness", 0.0), 0.0)))
        homeo = getattr(core, "homeostasis", None) if core is not None else None
        homeo = homeo if isinstance(homeo, dict) else {}
        drives_delta = self._worth_num(homeo.get("L_int"), 0.0)
        trust_dev = abs(trust - 0.5) * 2.0
        close_dev = abs(closeness - 0.5) * 2.0
        rel_delta = self._worth_num(
            0.50 * (trust_dev + close_dev) / 2.0
            + 0.30 * conflict + 0.20 * repair)
        persistence = self._worth_num(
            0.40 + 0.60 * max(intensity, drives_delta, self_delta, rel_delta))
        return {
            "intensity": intensity, "schema_congruence": schema_v,
            "self_defining": self_defining, "milestone": milestone,
            "boundary_score": rec.get("boundary_score", 0.0),
            "recall_count": rec.get("recall_count", 0),
            "merge_count": rec.get("merge_count", 0),
            "goal_relevance": appraisal.get("goal_relevance", 0.0),
            "novelty": novelty, "rel_trust": trust, "rel_closeness": closeness,
            "rel_conflict": conflict, "rel_repair": repair, "routine": routine,
            "pad_delta": pad_delta, "self_delta": self_delta,
            "rel_delta": rel_delta, "drives_delta": drives_delta,
            "persistence": persistence,
        }

    @staticmethod
    def _worthiness_inputs_public(inputs) -> dict:
        """Bounded JSON-safe raw inputs stored on the event (task-34 re-eval)."""
        src = inputs if isinstance(inputs, dict) else {}
        out = {}
        for key in ("intensity", "schema_congruence", "milestone", "boundary_score",
                    "goal_relevance", "novelty", "rel_trust", "rel_closeness",
                    "rel_conflict", "rel_repair", "pad_delta", "self_delta",
                    "rel_delta", "drives_delta", "persistence"):
            out[key] = round(BioCorePlugin._worth_num(src.get(key), 0.0), 4)
        out["self_defining"] = bool(src.get("self_defining", False))
        out["routine"] = bool(src.get("routine", False))
        out["recall_count"] = max(0, int(BioCorePlugin._worth_num(
            src.get("recall_count"), 0.0, 0.0, 10 ** 6)))
        out["merge_count"] = max(0, int(BioCorePlugin._worth_num(
            src.get("merge_count"), 0.0, 0.0, 10 ** 6)))
        return out

    def _worth_k_proxies(self, core, rel_delta: float = 0.0) -> dict:
        """Live core proxies for K (task-34 re-evaluation); bounded."""
        momentum = getattr(core, "momentum", None) if core is not None else None
        momentum = momentum if isinstance(momentum, dict) else {}
        pad_delta = self._worth_num(
            2.0 * (abs(self._worth_num(momentum.get("v"), 0.0, -1.0, 1.0))
                   + abs(self._worth_num(momentum.get("a"), 0.0, -1.0, 1.0))
                   + abs(self._worth_num(momentum.get("d"), 0.0, -1.0, 1.0))))
        self_delta = self._worth_num(
            abs(self._worth_num(getattr(core, "boundary_pressure", 0.0), 0.0))
            + abs(self._worth_num(getattr(core, "refusal_readiness", 0.0), 0.0)))
        homeo = getattr(core, "homeostasis", None) if core is not None else None
        homeo = homeo if isinstance(homeo, dict) else {}
        drives_delta = self._worth_num(homeo.get("L_int"), 0.0)
        try:
            intensity = float(core._intensity()) if core is not None else 0.0
        except Exception:
            intensity = 0.0
        persistence = self._worth_num(
            0.40 + 0.60 * max(intensity, drives_delta, self_delta,
                              self._worth_num(rel_delta, 0.0)))
        # NOTE (P1-1): this helper is K-only on purpose. Re-evaluation must keep
        # the archived intensity (stored inputs) instead of overwriting it with
        # the live core value; intensity here only feeds the persistence factor.
        return {"pad_delta": pad_delta, "self_delta": self_delta,
                "drives_delta": drives_delta, "persistence": persistence}

    def _event_worthiness_bundle(self, record, core, relationship=None, *,
                                 text: str = "", title: str = "",
                                 schema=None):
        """(worthiness, public raw inputs) or (None, None) when the gate is OFF."""
        if not getattr(self, "memory_worthiness_enabled", True):
            return None, None
        inputs = self._worthiness_inputs_for(
            record, core, relationship, text=text, title=title, schema=schema)
        return (memory_meta.compute_worthiness(**inputs),
                self._worthiness_inputs_public(inputs))

    def _event_worthiness_for(self, record, core, relationship=None, **kw):
        """task-33/34: deterministic W/W_her/K for one event (None when OFF)."""
        worth, _inputs = self._event_worthiness_bundle(
            record, core, relationship, **kw)
        return worth

    # ---- task-59: reevaluate evidence guard (insufficient / protected) ----
    _REEVALUATE_PROTECT_CUES = ("表白", "喜欢", "爱上", "承诺", "发誓", "誓言",
                                "纪念日", "求婚", "身份", "我是谁")
    _REEVALUATE_TOOL_CUES = ("翻译", "查询", "天气", "现在几点", "计算", "命令",
                             "帮我查", "搜索", "提醒我", "定时")

    @staticmethod
    def _reevaluate_text(record) -> str:
        rec = record if isinstance(record, dict) else {}
        return " ".join(str(rec.get(k) or "") for k in
                        ("title", "event", "big_summary", "small_summary")).strip()

    def _reevaluate_tool_cue(self, record) -> bool:
        rec = record if isinstance(record, dict) else {}
        text = self._reevaluate_text(rec)
        return any(cue in text for cue in self._REEVALUATE_TOOL_CUES)

    def _reevaluate_protection_reason(self, record) -> str:
        """Relationship/self/milestone events must not vanish on low W.

        P2: a tool-Q&A whitelist wins over the weaker keyword list (a weather
        query must not be "protected" just because it contains a common word);
        explicit relationship/self markers still always protect.
        """
        rec = record if isinstance(record, dict) else {}
        text = self._reevaluate_text(rec)
        markers = (rec.get("relationship_event") or rec.get("self_defining")
                   or rec.get("milestone") or rec.get("identity_relevant"))
        kind = str(rec.get("event_type") or rec.get("type") or "").lower()
        if markers or kind in ("relationship", "self", "milestone", "identity"):
            return "type_marker"
        if self._reevaluate_tool_cue(rec):
            return ""
        if any(cue in text for cue in self._REEVALUATE_PROTECT_CUES):
            return "keyword"
        return ""

    def _reevaluate_insufficient_reason(self, record, inputs, source) -> str:
        """Do not rewrite when evidence is absent/degenerate (or test data)."""
        rec = record if isinstance(record, dict) else {}
        text = self._reevaluate_text(rec)
        if not text:
            return "no_text"
        sess = str(rec.get("session") or "").lower()
        if "test" in sess or "测试" in text:
            return "test_event"
        if source == "recomputed":
            return "missing_inputs"
        if not isinstance(inputs, dict):
            return "missing_fields"
        required = ("I", "S", "C", "G", "PE", "R", "P", "N")
        if not all(k in inputs for k in required):
            return "missing_fields"
        try:
            strong = sum(1 for k in ("I", "S", "G", "PE", "R")
                         if float(inputs.get(k) or 0.0) >= 0.05)
        except Exception:
            return "bad_inputs"
        if strong == 0:
            # All evidence dimensions are ~zero: this is missing evidence, not
            # a genuine "not worth remembering" judgement.
            return "degenerate_inputs"
        return ""

    def _reevaluate_tool_only(self, record) -> bool:
        rec = record if isinstance(rec := record, dict) else {}
        if self._reevaluate_protection_reason(rec):
            return False
        return self._reevaluate_tool_cue(rec)

    def _reevaluate_worthiness(self, record, core=None):
        """task-34: recompute worthiness from stored inputs/parts + core proxies.

        Returns (worthiness, public_inputs|None, source) or (None, None, None)
        when memory_worthiness_enabled=false. Deterministic, never calls an LLM
        and never writes biological state.
        """
        if not getattr(self, "memory_worthiness_enabled", True):
            return None, None, None
        rec = record if isinstance(record, dict) else {}
        stored = rec.get("worthiness_inputs")
        if isinstance(stored, dict):
            inputs = self._worthiness_inputs_public(stored)
            if core is not None:
                # P1-1: refresh ONLY the K proxies (pad/self/drives/persistence);
                # the archived I/S/C/G/PE/R/P/N must stay exactly as stored.
                _k = self._worth_k_proxies(
                    core, self._worth_num(inputs.get("rel_delta"), 0.0))
                for _key in ("pad_delta", "self_delta", "drives_delta",
                             "persistence"):
                    if _key in _k:
                        inputs[_key] = _k[_key]
            return (memory_meta.compute_worthiness(**inputs),
                    self._worthiness_inputs_public(inputs), "inputs")
        parts = rec.get("worthiness")
        if isinstance(parts, dict) and all(
                key in parts for key in ("I", "S", "C", "G", "PE", "R", "P", "N")):
            k_vals = {"pad_delta": 0.0, "self_delta": 0.0, "rel_delta": 0.0,
                      "drives_delta": 0.0, "persistence": 0.4}
            if core is not None:
                proxies = self._worth_k_proxies(
                    core, self._worth_num(parts.get("R"), 0.0))
                k_vals.update(proxies)
            k_raw = _clip(0.35 * k_vals["pad_delta"] + 0.25 * k_vals["self_delta"]
                          + 0.20 * k_vals["rel_delta"]
                          + 0.20 * k_vals["drives_delta"], 0.0, 1.0)
            k_val = _clip(k_raw * k_vals["persistence"], 0.0, 1.0)
            worth = memory_meta.worthiness_from_parts(
                I=parts.get("I", 0.0), S=parts.get("S", 0.0),
                C=parts.get("C", 0.0), G=parts.get("G", 0.0),
                PE=parts.get("PE", 0.0), R=parts.get("R", 0.0),
                P=parts.get("P", 0.0), N=parts.get("N", 0), K=k_val)
            return worth, None, "parts"
        inputs = self._worthiness_inputs_for(
            rec, core, None, text=str(rec.get("event") or ""),
            title=str(rec.get("title") or ""))
        return (memory_meta.compute_worthiness(**inputs),
                self._worthiness_inputs_public(inputs), "recomputed")

    def _event_worthiness_decision(self, record, core, relationship=None, **kw):
        """Gate wrapper -> (worthiness|None, decision); OFF => legacy memory_point."""
        worth = self._event_worthiness_for(record, core, relationship, **kw)
        if worth is None:
            return None, "memory_point"
        return worth, str(worth.get("decision") or "archive_only")

    @staticmethod
    def _memory_point_snapshot(record) -> dict:
        rec = record if isinstance(record, dict) else {}
        worth = rec.get("worthiness") if isinstance(rec.get("worthiness"), dict) else None
        return {"importance": rec.get("importance", 0.5),
                "user_marked": bool(rec.get("user_marked", False)),
                "title": str(rec.get("title") or "")[:80],
                "small_summary": str(rec.get("small_summary") or "")[:80],
                # task-34: restore must undo a reevaluate downgrade too.
                "memory_point": bool(rec.get("memory_point", True)),
                "worthiness": dict(worth) if worth is not None else None}

    def _apply_memory_point_feedback(self, record, event_id: str,
                                     action: str, body=None) -> bool:
        """Atomic-mutation helper for the feedback API (audit/snapshot kept)."""
        if not isinstance(record, dict):
            return False
        if str(record.get("id") or "") != str(event_id or ""):
            return False
        action = str(action or "").strip().lower()
        data = body if isinstance(body, dict) else {}
        if action not in MEMORY_POINT_FEEDBACK_ACTIONS:
            return False
        if action in ("important", "unimportant") and getattr(
                self, "learning_worthiness_enabled", False):
            try:
                self._learning_worthiness_step(
                    None, str(record.get("session") or record.get("user_id") or "default"),
                    action == "important")
            except Exception:
                pass
        if action == "reevaluate":
            # Handled by _apply_memory_point_reevaluate (needs the verdict).
            return False
        if action == "restore":
            # Prefer the most recent pre-change snapshot: reevaluate_prev (with
            # its ts) over a manual feedback_prev; restore supports both.
            _cands = []
            _hist = record.get("reevaluate_history")
            if isinstance(_hist, list) and _hist and isinstance(_hist[0], dict)                     and isinstance(_hist[0].get("snapshot"), dict):
                _cands.append((float(_hist[0].get("ts") or 0.0),
                               _hist[0]["snapshot"]))
            _re = record.get("reevaluate_prev")
            if isinstance(_re, dict) and isinstance(_re.get("snapshot"), dict):
                _cands.append((float(_re.get("ts") or 0.0), _re["snapshot"]))
            _fb = record.get("feedback_prev")
            if isinstance(_fb, dict):
                _cands.append((float(_fb.get("ts") or 0.0), _fb))
            if not _cands:
                return False
            prev = max(_cands, key=lambda item: item[0])[1]
            for key in ("importance", "user_marked", "title", "small_summary",
                        "memory_point", "worthiness"):
                if key in prev:
                    record[key] = prev[key]
            record.pop("downgraded_by_reevaluate", None)
            if isinstance(_hist, list) and _hist and isinstance(_hist[0], dict):
                record["reevaluate_history"] = _hist[1:]
            else:
                record.pop("reevaluate_prev", None)
            record["reevaluate_restored_ts"] = round(time.time(), 3)
            record["last_feedback_action"] = "restore"
            record["feedback_ts"] = round(time.time(), 3)
            return True
        before = self._memory_point_snapshot(record)
        record["feedback_prev"] = before
        if action == "important":
            base = self._worth_num(record.get("importance"), 0.5)
            record["importance"] = round(min(1.0, base + 0.15), 4)
            record["user_marked"] = True
            record["memory_point"] = True
        elif action == "unimportant":
            record["importance"] = 0.15
            record["user_marked"] = False
        elif action == "edit_label":
            title = re.sub(r"\s+", " ", str(data.get("title") or "")).strip()
            small = str(data.get("small_summary") or "").strip()
            if not title and not small:
                return False
            if title:
                record["title"] = self._mask_if_safety(title)[:80]
            if small:
                record["small_summary"] = self._mask_if_safety(small)[:80]
            elif data.get("small_summary") is not None:
                record["small_summary"] = ""
            record["label_edited"] = True
            record["user_marked"] = True
        history = record.get("feedback_history")
        history = history if isinstance(history, list) else []
        record["feedback_history"] = ([{"action": action,
                                        "ts": round(time.time(), 3),
                                        "before": before}]
                                      + [h for h in history if isinstance(h, dict)])[:20]
        record["last_feedback_action"] = action
        record["feedback_ts"] = round(time.time(), 3)
        return True

    def _apply_memory_point_reevaluate(self, record, event_id: str,
                                       worth: dict, verdict: dict,
                                       inputs=None) -> bool:
        """task-34 atomic mutation: write verdict, downgrade when not a point."""
        if not isinstance(record, dict):
            return False
        if str(record.get("id") or "") != str(event_id or ""):
            return False
        if not isinstance(worth, dict) or not isinstance(verdict, dict):
            return False
        before = self._memory_point_snapshot(record)
        now = round(time.time(), 3)
        # Always keep a dedicated reevaluate snapshot; never overwrite a manual
        # feedback_prev (that one belongs to the user's earlier edit).
        # P1-7: keep the FIRST reevaluate snapshot; append newest to history.
        if not isinstance(record.get("reevaluate_prev"), dict):
            record["reevaluate_prev"] = {"snapshot": dict(before), "ts": now,
                                         "source": "reevaluate"}
        _hist = record.get("reevaluate_history")
        _hist = _hist if isinstance(_hist, list) else []
        record["reevaluate_history"] = (
            [{"snapshot": dict(before), "ts": now}]
            + [x for x in _hist if isinstance(x, dict)])[:5]
        if not isinstance(record.get("feedback_prev"), dict):
            record["feedback_prev"] = dict(before)
        decision = str(verdict.get("decision") or worth.get("decision") or "archive_only")
        record["worthiness"] = dict(worth)
        if isinstance(inputs, dict):
            record["worthiness_inputs"] = dict(inputs)
        record["reevaluate_ts"] = now
        record["reevaluate_verdict"] = {
            "decision": decision,
            "W": worth.get("W", 0.0),
            "W_her": worth.get("W_her", 0.0),
            "K": worth.get("K", 0.0),
            "reasons": list(verdict.get("reasons") or [worth.get("reason") or ""]),
            "ts": now,
        }
        if decision in ("archive_only", "skip"):
            # Downgrade in place: keep the row (no physical delete) so 恢复 works.
            record["memory_point"] = False
            record["importance"] = 0.15
            record["user_marked"] = False
            record["downgraded_by_reevaluate"] = True
        else:
            record["memory_point"] = True
            record["downgraded_by_reevaluate"] = False
        history = record.get("feedback_history")
        history = history if isinstance(history, list) else []
        record["feedback_history"] = ([{"action": "reevaluate", "ts": now,
                                        "before": before, "decision": decision}]
                                      + [h for h in history if isinstance(h, dict)])[:20]
        record["last_feedback_action"] = "reevaluate"
        record["feedback_ts"] = now
        return True

    @staticmethod
    def _parse_memory_point_feedback_request(body):
        data = body if isinstance(body, dict) else {}
        event_id = str(data.get("event_id") or "").strip()
        action = str(data.get("action") or "").strip().lower()
        if not event_id:
            return "", "", "缺少 event_id"
        if action not in MEMORY_POINT_FEEDBACK_ACTIONS:
            return event_id, action, "未知操作"
        return event_id, action, ""

    def _memory_point_public(self, record) -> dict:
        rec = record if isinstance(record, dict) else {}
        worth = rec.get("worthiness") if isinstance(rec.get("worthiness"), dict) else None
        _re_prev = rec.get("reevaluate_prev")
        return {"event_id": str(rec.get("id") or ""),
                "downgraded_by_reevaluate": bool(
                    rec.get("downgraded_by_reevaluate", False)),
                "can_restore": bool(isinstance(rec.get("feedback_prev"), dict)
                                    or isinstance(_re_prev, dict)
                                    or (isinstance(rec.get("reevaluate_history"), list)
                                        and bool(rec.get("reevaluate_history")))),
                "reevaluate_verdict": (dict(rec.get("reevaluate_verdict"))
                                       if isinstance(rec.get("reevaluate_verdict"), dict)
                                       else None),
                "title": str(rec.get("title") or "")[:80],
                "small_summary": str(rec.get("small_summary") or "")[:80],
                "big_summary": str(rec.get("big_summary") or "")[:EVENT_SUMMARY_HARD_MAX],
                "importance": round(self._worth_num(rec.get("importance"), 0.5), 4),
                "user_marked": bool(rec.get("user_marked", False)),
                "memory_point": bool(rec.get("memory_point", True)),
                "label_edited": bool(rec.get("label_edited", False)),
                "last_feedback_action": str(rec.get("last_feedback_action") or "")[:20],
                "worthiness": dict(worth) if worth is not None else None,
                "reevaluate_ts": round(self._worth_num(
                    rec.get("reevaluate_ts"), 0.0, 0.0, 10 ** 12), 3),
                "reevaluate_verdict": (dict(rec.get("reevaluate_verdict"))
                                       if isinstance(rec.get("reevaluate_verdict"), dict)
                                       else None),
                "summary_status": str(rec.get("summary_status") or "legacy"),
                "summary_edited": bool(rec.get("summary_edited", False)),
                "summary_updated_ts": round(self._worth_num(
                    rec.get("summary_updated_ts"), 0.0, 0.0, 10 ** 12), 3)}

    async def _page_memory_point_reevaluate(self, record, event_id: str):
        """task-34: recompute W/W_her/K, downgrade/keep, return record+verdict."""
        if not getattr(self, "memory_worthiness_enabled", True):
            return {"status": "error",
                    "message": "判定关闭（memory_worthiness_enabled=false），未修改记录"}
        core = None
        try:
            cores = getattr(self, "cores", None)
            if isinstance(cores, dict):
                core = cores.get(str(record.get("session") or ""))
        except Exception:
            core = None
        worth, inputs, source = self._reevaluate_worthiness(record, core)
        if not isinstance(worth, dict):
            return {"status": "error",
                    "message": "判定关闭（memory_worthiness_enabled=false），未修改记录"}
        # P0: insufficient evidence or protected/test event => never rewrite.
        _insufficient = self._reevaluate_insufficient_reason(record, worth, source)
        if _insufficient:
            verdict = {"decision": "insufficient_data",
                       "W": worth.get("W", 0.0), "W_her": worth.get("W_her", 0.0),
                       "K": worth.get("K", 0.0), "source": source,
                       "reason": _insufficient,
                       "reasons": [_insufficient]}
            return {"status": "ok",
                    "data": {"record": self._memory_point_public(record),
                             "verdict": verdict, "changed": False,
                             "message": "证据不足，未修改"}}
        _protect = self._reevaluate_protection_reason(record)
        if _protect and str(worth.get("decision") or "") in ("archive_only", "skip")                 and not self._reevaluate_tool_only(record):
            verdict = {"decision": "retained_protected",
                       "W": worth.get("W", 0.0), "W_her": worth.get("W_her", 0.0),
                       "K": worth.get("K", 0.0), "source": source,
                       "reason": _protect, "reasons": [_protect]}
            return {"status": "ok",
                    "data": {"record": self._memory_point_public(record),
                             "verdict": verdict, "changed": False,
                             "message": "关系/自我相关事件，已保留（待人工确认）"}}
        verdict = {"decision": str(worth.get("decision") or "archive_only"),
                   "W": worth.get("W", 0.0),
                   "W_her": worth.get("W_her", 0.0),
                   "K": worth.get("K", 0.0),
                   "reasons": [str(worth.get("reason") or "")],
                   "source": source}
        try:
            changed = self._rewrite_jsonl_atomic(
                EVENT_ARCHIVE_PATH,
                lambda obj: self._apply_memory_point_reevaluate(
                    obj, event_id, worth, verdict, inputs))
        except Exception as exc:
            logger.warning("[biocore] memory point reevaluate failed: %s", exc)
            changed = 0
        if changed <= 0:
            return {"status": "error", "message": "事件不存在或写入失败"}
        try:
            session = str(record.get("session") or "")
            if session:
                self._rewrite_jsonl_atomic(
                    self._event_session_file(session),
                    lambda obj: self._apply_memory_point_reevaluate(
                        obj, event_id, worth, verdict, inputs))
        except Exception:
            pass
        saved = self._find_event_summary_record(event_id) or {}
        return {"status": "ok",
                "data": {"record": self._memory_point_public(saved),
                         "verdict": verdict}}

    async def page_memory_point_feedback(self):
        """POST memory-point feedback: important/unimportant/edit_label/restore/reevaluate."""
        from quart import request
        try:
            body = await request.get_json(silent=True) or {}
        except Exception:
            body = {}
        event_id, action, error = self._parse_memory_point_feedback_request(body)
        if error:
            return {"status": "error", "message": error}
        record = self._find_event_summary_record(event_id)
        if record is None:
            return {"status": "error", "message": "事件不存在"}
        if action == "reevaluate":
            return await self._page_memory_point_reevaluate(record, event_id)
        if action == "edit_label":
            title = str(body.get("title") or "").strip()
            small = str(body.get("small_summary") or "").strip()
            if not title and not small:
                return {"status": "error", "message": "至少提供标题或小标签"}
            if len(title) > 80:
                return {"status": "error", "message": "标题不能超过 80 字"}
            if len(small) > 80:
                return {"status": "error", "message": "小标签不能超过 80 字"}
        if (action == "restore"
                and not isinstance(record.get("feedback_prev"), dict)
                and not isinstance(record.get("reevaluate_prev"), dict)):
            return {"status": "error", "message": "没有可恢复的反馈前版本"}
        try:
            changed = self._rewrite_jsonl_atomic(
                EVENT_ARCHIVE_PATH,
                lambda obj: self._apply_memory_point_feedback(obj, event_id, action, body))
        except Exception as exc:
            logger.warning("[biocore] memory point feedback rewrite failed: %s", exc)
            changed = 0
        if changed <= 0:
            return {"status": "error", "message": "事件不存在或写入失败"}
        # Per-session copy stays in sync (best effort; same atomic rewrite).
        try:
            session = str(record.get("session") or "")
            if session:
                self._rewrite_jsonl_atomic(
                    self._event_session_file(session),
                    lambda obj: self._apply_memory_point_feedback(
                        obj, event_id, action, body))
        except Exception:
            pass
        saved = self._find_event_summary_record(event_id) or {}
        return {"status": "ok", "data": self._memory_point_public(saved)}

    # ---- task-47: regenerate / edit one archived event summary ----
    @staticmethod
    def _parse_event_summary_request(body):
        """Validate an event_summary POST body -> (event_id, action, error)."""
        data = body if isinstance(body, dict) else {}
        event_id = str(data.get("event_id") or "").strip()
        action = str(data.get("action") or "").strip().lower()
        if not event_id:
            return "", "", "缺少 event_id"
        if action not in EVENT_SUMMARY_ACTIONS:
            return event_id, action, "未知操作"
        return event_id, action, ""

    @staticmethod
    def _validate_edited_event_summary(big, small, max_chars: int = 0):
        """Validate a manual summary edit -> (big, small, error)."""
        big_text = str(big or "").strip()
        small_text = str(small or "").strip()
        if not big_text:
            return "", "", "大总结不能为空"
        if len(small_text) > EVENT_SUMMARY_SMALL_MAX:
            return "", "", "小总结不能超过 %d 字" % EVENT_SUMMARY_SMALL_MAX
        try:
            cap = int(max_chars or 0)
        except Exception:
            cap = 0
        limit = EVENT_SUMMARY_HARD_MAX
        if cap > 0:
            limit = min(cap, EVENT_SUMMARY_HARD_MAX)
        return big_text[:limit], small_text, ""

    @staticmethod
    def _validate_edited_event_title(title):
        """Validate a manual event title -> (title, error); 1-80 chars."""
        text = re.sub(r"\s+", " ", str(title or "")).strip()
        if not text:
            return "", "标题不能为空"
        if len(text) > 80:
            return "", "标题不能超过 80 字"
        return text[:80], ""

    @staticmethod
    def _apply_event_summary_fields(record, event_id: str, updates: dict) -> bool:
        """Mutation for _rewrite_jsonl_atomic: touch only the target row."""
        if not isinstance(record, dict) or not isinstance(updates, dict):
            return False
        if str(record.get("id") or "") != str(event_id or ""):
            return False
        record.update(updates)
        return True

    @staticmethod
    def _event_summary_history_source(record) -> str:
        """Where the OLD summary came from: edit / regenerate / legacy."""
        if not isinstance(record, dict):
            return "legacy"
        status = str(record.get("summary_status") or "legacy").strip().lower()
        if record.get("summary_edited") is True or status == "edited":
            return "edit"
        if not status or status == "legacy":
            return "legacy"
        return "regenerate"

    def _event_summary_history_entry(self, record) -> dict:
        rec = record if isinstance(record, dict) else {}
        try:
            ts = float(rec.get("summary_updated_ts") or rec.get("ts") or time.time())
        except Exception:
            ts = time.time()
        status = str(rec.get("summary_status") or "legacy").strip().lower() or "legacy"
        return {"ts": ts,
                "title": str(rec.get("title") or "")[:80],
                "summary_status": status,
                "big_summary": str(rec.get("big_summary") or "")[:EVENT_SUMMARY_HARD_MAX],
                "small_summary": str(rec.get("small_summary") or "")[:EVENT_SUMMARY_SMALL_MAX],
                "source": self._event_summary_history_source(rec)}

    def _apply_event_summary_with_history(self, record, event_id: str, updates: dict) -> bool:
        """Mutation for the atomic rewrite: archive the old summary, then update.

        Keeps the newest 20 versions (newest first) so regenerating/editing never
        loses what the panel used to show.
        """
        if not isinstance(record, dict) or not isinstance(updates, dict):
            return False
        if str(record.get("id") or "") != str(event_id or ""):
            return False
        old_big = str(record.get("big_summary") or "").strip()
        old_small = str(record.get("small_summary") or "").strip()
        if old_big or old_small:
            entry = self._event_summary_history_entry(record)
            history = record.get("summary_history")
            if not isinstance(history, list):
                history = []
            kept = [h for h in history if isinstance(h, dict)]
            record["summary_history"] = [entry] + kept
            record["summary_history"] = record["summary_history"][:EVENT_SUMMARY_HISTORY_MAX]
        elif "summary_history" in record and not isinstance(record.get("summary_history"), list):
            record["summary_history"] = []
        record.update(updates)
        return True

    def _find_event_summary_record(self, event_id: str):
        try:
            target = str(event_id or "").strip()
            if not target or not EVENT_ARCHIVE_PATH.exists():
                return None
            for line in EVENT_ARCHIVE_PATH.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except Exception:
                    continue
                if isinstance(row, dict) and str(row.get("id") or "") == target:
                    return row
        except Exception as exc:
            logger.warning("[biocore] event summary lookup failed: %s", exc)
        return None

    @staticmethod
    def _event_summary_source_texts(record) -> list:
        try:
            source = [str(t or "").strip() for t in (record.get("source_texts") or [])
                      if str(t or "").strip()]
            if source:
                return source[:12]
        except Exception:
            pass
        out = []
        for value in (record.get("event"), record.get("central_details"),
                      record.get("title")):
            text = str(value or "").strip()
            if text:
                out.append(text)
        return out[:12]

    async def _regenerate_event_summary_fields(self, record) -> dict:
        """Regenerate big/small: LLM when enabled+available, else bounded fallback."""
        record = record if isinstance(record, dict) else {}
        title = str(record.get("title") or "").strip()
        texts = self._event_summary_source_texts(record)
        source_text = "\n".join(texts) if texts else str(record.get("event") or "")
        now = time.time()
        big = small = ""
        new_title = ""
        nuance = []
        summary_layers = []
        status = "fallback"
        llm_ok = False
        try:
            if self._llm_allowed("event_summary"):
                provider = await self._provider_for("event_summary", None)
                if provider is not None:
                    prompt = interpretation.event_summary_prompt(texts or [source_text])
                    resp = await self._bg_llm_direct(
                        "event_summary", provider, prompt,
                        timeout_ms=getattr(self, "summary_llm_timeout_ms", 8000))
                    raw = str(getattr(resp, "completion_text", "") or "").strip()
                    data = interpretation.parse_event_summary(
                        raw, getattr(self, "summary_max_chars", 0))
                    llm_big = str(data.get("big_summary") or "").strip()
                    llm_small = str(data.get("small_summary") or "").strip()
                    llm_title = interpretation.clean_event_title(
                        data.get("title"), 80)
                    if llm_big or llm_small:
                        try:
                            cap = int(getattr(self, "summary_max_chars", 0) or 0)
                        except Exception:
                            cap = 0
                        limit = EVENT_SUMMARY_HARD_MAX
                        if cap > 0:
                            limit = min(cap, EVENT_SUMMARY_HARD_MAX)
                        big = self._mask_if_safety(str(llm_big or llm_small))[:limit]
                        small = self._mask_if_safety(
                            str(llm_small or llm_big))[:EVENT_SUMMARY_SMALL_MAX]
                        if llm_title:
                            new_title = llm_title[:80]
                        nuance = interpretation.clean_emotion_nuance(
                            data.get("emotion_nuance"))
                        summary_layers = interpretation.clean_emotion_layers(
                            data.get("emotion_layers"))
                        llm_ok = True
        except Exception as exc:
            logger.warning("[biocore] event summary regenerate via LLM failed: %s", exc)
            llm_ok = False
        if not llm_ok:
            big, small = self._dual_event_summary_fallback(source_text, title)
            status = "fallback"
            nuance = []   # deterministic fallback never fabricates a nuance layer
            summary_layers = []
            self._record_llm_telemetry("event_summary", "fallback")
        else:
            status = "llm"
        if not new_title:
            # deterministic title: cleaned first sentence -> meaning -> old title
            new_title = (interpretation.clean_event_title(source_text)
                         or interpretation.clean_event_title(record.get("meaning_to_her"))
                         or interpretation.clean_event_title(title)
                         or "对话事件")
        updates = {"title": str(new_title or "对话事件")[:80],
                   "big_summary": str(big or "")[:EVENT_SUMMARY_HARD_MAX],
                   "small_summary": str(small or "")[:EVENT_SUMMARY_SMALL_MAX],
                   "emotion_nuance": interpretation.clean_emotion_nuance(nuance),
                   "summary_status": status,
                   "summary_edited": False,
                   "summary_updated_ts": now}
        # task-68 correction: emotion proportions come from the summary itself
        # (normalized p, including the primary emotion). No fixed 50/30/20
        # weights and no fabrication: no layers in the output -> keep the old
        # value (possibly null) untouched.
        if summary_layers:
            updates["emotion_layers"] = summary_layers
            updates["emotion_layers_source"] = "summary"
        return updates

    async def page_event_summary(self):
        """Regenerate (LLM/fallback) or manually edit one archived event summary."""
        from quart import request
        try:
            body = await request.get_json(silent=True) or {}
        except Exception:
            body = {}
        event_id, action, error = self._parse_event_summary_request(body)
        if error:
            return {"status": "error", "message": error}
        record = self._find_event_summary_record(event_id)
        if record is None:
            return {"status": "error", "message": "事件不存在"}
        try:
            if action == "regenerate":
                updates = await self._regenerate_event_summary_fields(record)
            else:
                big, small, error = self._validate_edited_event_summary(
                    body.get("big_summary"), body.get("small_summary"),
                    getattr(self, "summary_max_chars", 0))
                if error:
                    return {"status": "error", "message": error}
                updates = {"big_summary": big, "small_summary": small,
                           "summary_status": "edited", "summary_edited": True,
                           "summary_updated_ts": time.time()}
                if body.get("title") is not None:
                    checked_title, title_error = self._validate_edited_event_title(
                        body.get("title"))
                    if title_error:
                        return {"status": "error", "message": title_error}
                    updates["title"] = checked_title
        except Exception as exc:
            logger.warning("[biocore] event summary %s failed: %s", action, exc)
            return {"status": "error", "message": "处理失败"}
        # task-51: a regenerate fills a missing secondary emotion from the live
        # core spectrum (primary excluded). update never rewrites it; no core
        # data keeps the field empty instead of fabricating one.
        if action == "regenerate" and not str(record.get("emotion_secondary") or "").strip():
            _secondary = self._event_secondary_for_record(record)
            if _secondary:
                updates["emotion_secondary"] = _secondary
        try:
            changed = self._rewrite_jsonl_atomic(
                EVENT_ARCHIVE_PATH,
                lambda obj: self._apply_event_summary_with_history(obj, event_id, updates))
        except Exception as exc:
            logger.warning("[biocore] event summary rewrite failed: %s", exc)
            changed = 0
        if changed <= 0:
            return {"status": "error", "message": "事件不存在或写入失败"}
        saved = self._find_event_summary_record(event_id) or {}
        history = saved.get("summary_history")
        payload = dict({"event_id": event_id, "action": action}, **updates)
        if "emotion_secondary" not in payload and str(saved.get("emotion_secondary") or "").strip():
            payload["emotion_secondary"] = str(saved.get("emotion_secondary") or "").strip()
        if isinstance(saved.get("emotion_nuance"), list):
            payload["emotion_nuance"] = list(saved.get("emotion_nuance") or [])[:3]
        if isinstance(saved.get("emotion_layers"), list):
            payload["emotion_layers"] = [dict(x) for x in (saved.get("emotion_layers") or [])[:4]
                                         if isinstance(x, dict)]
        try:
            payload["emotion_intensity"] = round(
                float(saved.get("emotion_intensity", 0.0) or 0.0), 4)
        except Exception:
            pass
        if str(saved.get("emotion_layers_source") or "").strip():
            payload["emotion_layers_source"] = str(
                saved.get("emotion_layers_source") or "").strip()
        payload["summary_history"] = history if isinstance(history, list) else []
        return {"status": "ok", "data": payload}

    def _event_pair_duplicate(self, row, prev,
                              window: float = EVENT_DEDUPE_CLEANUP_WINDOW) -> bool:
        """Multi-signal duplicate test for two rows of one canonical session.

        The two real rows from the ":"/"_" key generations share the same
        original conversation but their archive timestamps can be days apart,
        so the comparison uses the real event time (time_span) and accepts a
        merge when source texts overlap strongly or the summaries/titles are
        near-identical. False positives are limited by requiring the text
        signals, not just the canonical session.
        """
        try:
            gap = abs(event_effective_time(row) - event_effective_time(prev))
        except Exception:
            gap = 0.0
        if gap > window:
            return False
        try:
            title_sim = self._text_similarity(str(row.get("title") or ""),
                                              str(prev.get("title") or ""))
            body_sim = self._text_similarity(str(row.get("event") or ""),
                                             str(prev.get("event") or ""))
            summary_sim = max(
                self._text_similarity(str(row.get("big_summary") or ""),
                                      str(prev.get("big_summary") or "")),
                self._text_similarity(str(row.get("small_summary") or ""),
                                      str(prev.get("small_summary") or "")))
            left = {str(x) for x in (row.get("source_texts") or []) if str(x)}
            right = {str(x) for x in (prev.get("source_texts") or []) if str(x)}
            source_overlap = (len(left & right) / float(len(left | right))
                              if (left and right) else 0.0)
        except Exception:
            return False
        if source_overlap >= 0.5:
            return True
        if body_sim >= 0.6:
            return True
        if summary_sim >= 0.5 and (source_overlap >= 0.2 or title_sim >= 0.25
                                   or body_sim >= 0.3):
            return True
        if title_sim >= 0.5 and body_sim >= 0.2:
            return True
        return False

    @staticmethod
    def _drop_ids_from_jsonl(path, ids) -> int:
        """Remove rows with the given ids from a JSONL file atomically."""
        try:
            target = Path(path)
            drop = {str(x) for x in (ids or []) if str(x)}
            if not drop or not target.exists():
                return 0
            kept = []
            dropped = 0
            for line in target.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    kept.append(line)
                    continue
                if isinstance(obj, dict) and str(obj.get("id") or "") in drop:
                    dropped += 1
                    continue
                kept.append(json.dumps(obj, ensure_ascii=False))
            if not dropped:
                return 0
            tmp = target.with_name(target.name + ".tmp_%s_%s" % (
                os.getpid(), int(time.time() * 1000)))
            tmp.write_text("\n".join(kept) + ("\n" if kept else ""), encoding="utf-8")
            os.replace(tmp, target)
            return dropped
        except Exception:
            return 0

    def _cleanup_duplicate_events(self, force: bool = False) -> int:
        """One-time cross-key duplicate cleanup for events.jsonl (task-56).

        Canonical sessions unify ":"/"_" key generations. Rows of one real
        conversation are grouped by canonical session + real event time
        (time_span) + text signals (source_texts/title/summary/body); the
        richer/newer row is kept and the poorer row is merged into it
        (source_texts union, importance/centrality/recall maxima, provenance,
        summary_history). Group sessions -- including the 664198103 test group
        -- and unrelated rows are never touched. The global archive and every
        affected per-session archive are rewritten atomically; each merge is
        appended to dedupe_log.jsonl and a marker keeps the migration
        idempotent.
        """
        try:
            EVENT_ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
            marker = EVENT_ARCHIVE_DIR / "dedupe_v1.done"
            if not force and marker.exists():
                return 0
            if not EVENT_ARCHIVE_PATH.exists():
                return 0
            rows, raw_keep = [], []
            for line in EVENT_ARCHIVE_PATH.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    raw_keep.append(line)
                    continue
                (rows if isinstance(obj, dict) else raw_keep).append(obj)
        except Exception:
            return 0

        def _score(row):
            status = str(row.get("summary_status") or "").lower()
            score = {"llm": 2.0, "edited": 1.5, "fallback": 0.5}.get(status, 0.0)
            try:
                score += float(row.get("importance", 0) or 0) * 0.5
            except Exception:
                pass
            if isinstance(row.get("summary_history"), list) and row.get("summary_history"):
                score += 0.20
            if row.get("event_embedding"):
                score += 0.10
            if isinstance(row.get("time_span"), dict):
                score += 0.10
            try:
                score += float(row.get("summary_updated_ts", 0) or 0) * 1e-9
            except Exception:
                pass
            try:
                score += float(row.get("ts", 0) or 0) * 1e-10
            except Exception:
                pass
            return score

        def _merge_into(rich, poor):
            try:
                src = [str(x) for x in (rich.get("source_texts") or []) if str(x)]
                for text in [str(x) for x in (poor.get("source_texts") or []) if str(x)]:
                    if text not in src:
                        src.append(text)
                rich["source_texts"] = src[-24:]
            except Exception:
                pass
            for key in ("importance", "centrality", "recall_count", "strength",
                        "confidence", "source_count", "last_recall"):
                try:
                    rich[key] = max(float(rich.get(key, 0) or 0),
                                    float(poor.get(key, 0) or 0))
                except Exception:
                    continue
            try:
                hist = []
                for item in (list(poor.get("summary_history") or [])
                             + list(rich.get("summary_history") or [])):
                    if isinstance(item, dict) and item not in hist:
                        hist.append(item)
                if hist:
                    rich["summary_history"] = hist[:EVENT_SUMMARY_HISTORY_MAX]
            except Exception:
                pass
            try:
                merged = [str(x) for x in (rich.get("merged_event_keys") or [])]
                for item in (poor.get("merged_event_keys") or []):
                    if str(item) and str(item) not in merged:
                        merged.append(str(item))
                poor_key = str(poor.get("event_key") or "")
                if poor_key and poor_key not in merged:
                    merged.append(poor_key)
                if merged:
                    rich["merged_event_keys"] = merged[:12]
            except Exception:
                pass
            try:
                prov = dict(rich.get("provenance") or {})
                sources = [x for x in (prov.get("sources") or [])
                           if isinstance(x, dict)][-24:]
                for item in ((poor.get("provenance") or {}).get("sources") or []):
                    if isinstance(item, dict) and item not in sources:
                        sources.append(item)
                prov["sources"] = sources[-24:]
                refs = [str(x) for x in (prov.get("message_refs") or []) if str(x)]
                for ref in ((poor.get("provenance") or {}).get("message_refs") or []):
                    ref = str(ref or "")
                    if ref and ref not in refs:
                        refs.append(ref)
                if refs:
                    prov["message_refs"] = refs[:12]
                rich["provenance"] = prov
            except Exception:
                pass
            try:
                rich["merge_count"] = int(rich.get("merge_count", 0) or 0) + 1
                merged_from = [str(x) for x in (rich.get("merged_from") or [])]
                poor_id = str(poor.get("id") or "")
                if poor_id and poor_id not in merged_from:
                    merged_from.append(poor_id)
                if merged_from:
                    rich["merged_from"] = merged_from[-8:]
            except Exception:
                pass

        kept, dropped_ids, dropped_sessions, log_rows = [], set(), set(), []
        for row in rows:
            session = canonical_session_key(row.get("session"))
            row_id = str(row.get("id") or "")
            if not session or not row_id:
                kept.append(row)
                continue
            # Requirement: group events (the 664198103 test group and other
            # group chats) are out of scope for this private-session migration.
            if ":GroupMessage:" in session or ":GuildMessage:" in session:
                kept.append(row)
                continue
            current = None
            for prev in kept:
                if canonical_session_key(prev.get("session")) != session:
                    continue
                if self._event_pair_duplicate(row, prev):
                    current = prev
                    break
            if current is None:
                kept.append(row)
                continue
            keep_new = _score(row) > _score(current)
            rich = row if keep_new else current
            poor = current if keep_new else row
            rich_id = str(rich.get("id") or "")
            poor_id = str(poor.get("id") or "")
            if not rich_id or not poor_id:
                kept.append(row)
                continue
            try:
                gap_seconds = round(abs(event_effective_time(rich)
                                        - event_effective_time(poor)), 3)
            except Exception:
                gap_seconds = 0.0
            _merge_into(rich, poor)
            if keep_new:
                try:
                    kept[kept.index(current)] = row
                except Exception:
                    kept.append(row)
            dropped_ids.add(poor_id)
            dropped_sessions.add(canonical_session_key(poor.get("session")))
            log_rows.append({
                "ts": round(time.time(), 3),
                "action": "dedupe_merge",
                "reason": "canonical_cross_key_duplicate",
                "session": session,
                "kept_id": rich_id,
                "kept_title": str(rich.get("title") or "")[:80],
                "dropped_id": poor_id,
                "dropped_title": str(poor.get("title") or "")[:80],
                "dropped_sessions": sorted({str(poor.get("session") or ""),
                                            str(rich.get("session") or "")}),
                "gap_seconds": gap_seconds,
                "merged_importance": rich.get("importance"),
                "merged_source_texts": len(rich.get("source_texts") or []),
            })
        if not dropped_ids:
            try:
                marker.write_text(str(time.time()), encoding="utf-8")
            except Exception:
                pass
            return 0
        removed = 0
        try:
            out = [json.dumps(r, ensure_ascii=False) for r in rows
                   if str(r.get("id") or "") not in dropped_ids]
            out += raw_keep
            tmp = EVENT_ARCHIVE_PATH.with_name(
                EVENT_ARCHIVE_PATH.name + ".tmp_%s_%s" % (
                    os.getpid(), int(time.time() * 1000)))
            tmp.write_text("\n".join(out) + ("\n" if out else ""), encoding="utf-8")
            os.replace(tmp, EVENT_ARCHIVE_PATH)
            removed = len(dropped_ids)
        except Exception as exc:
            logger.warning("[biocore] dedupe global rewrite failed: %s", exc)
            return 0
        # ":" and "_" variants sanitize to the same per-session file name.
        for session in dropped_sessions:
            if not session:
                continue
            try:
                safe = "".join(c if c.isalnum() or c in "-_" else "_"
                               for c in session)[:80]
                self._drop_ids_from_jsonl(EVENT_SESSION_DIR / safe / "events.jsonl",
                                          dropped_ids)
            except Exception:
                continue
        try:
            with open(EVENT_ARCHIVE_DIR / "dedupe_log.jsonl", "a",
                      encoding="utf-8") as log:
                for entry in log_rows:
                    log.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            pass
        try:
            marker.write_text(str(time.time()), encoding="utf-8")
        except Exception:
            pass
        logger.info("[biocore] canonical duplicate cleanup removed %s event(s)",
                    removed)
        return removed

    def _decayed_merge_count(self, event) -> int:
        """G11: merge_count decays on the same schedule as peripheral forgetting."""
        try:
            count = int(event.get("merge_count", 0) or 0)
            if count <= 0:
                return 0
            ts = float(event.get("ts", 0) or 0)
            if ts <= 0:
                return count
            age_days = max(0.0, (time.time() - ts) / 86400.0)
            decay = memory_meta.time_decay(age_days)
            return max(0, int(round(count * decay)))
        except Exception:
            return 0

    def _persist_peripheral_forgetting(self, events) -> None:
        """Persist periphery forgetting to both archive layers.

        The returned view already hides forgotten details; this keeps the
        global events.jsonl and archives/sessions/<session>/events.jsonl in
        sync through atomic rewrites instead of append-only drift. G11: the
        event merge_count is decayed (30-day half-life) in the same rewrite.
        """
        try:
            targets = [d for d in (events or []) if isinstance(d, dict)]
            if not targets:
                return

            def _mutate(obj):
                for target in targets:
                    if not self._same_archive_event(obj, target):
                        continue
                    obj["merge_count"] = self._decayed_merge_count(obj)
                    obj["peripheral_details"] = ""
                    obj["peripheral_retention"] = min(
                        float(obj.get("peripheral_retention", 1.0) or 1.0), 0.05)
                    obj["peripheral_forgotten"] = True
                    return True
                return False

            self._rewrite_jsonl_atomic(EVENT_ARCHIVE_PATH, _mutate)
            seen = set()
            for target in targets:
                _sess = str(target.get("session") or "default")
                _safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in _sess)[:80]
                if _safe in seen:
                    continue
                seen.add(_safe)
                self._rewrite_jsonl_atomic(EVENT_SESSION_DIR / _safe / "events.jsonl", _mutate)
        except Exception as exc:
            logger.warning("[biocore] peripheral forgetting persist failed: %s", exc)

    def _bump_event_recall(self, ids) -> None:
        try:
            if not EVENT_ARCHIVE_PATH.exists() or not ids:
                return
            wanted = set(ids)
            rows = []
            for line in EVENT_ARCHIVE_PATH.read_text(encoding="utf-8").splitlines():
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                if isinstance(d, dict) and d.get("id") in wanted:
                    d["recall_count"] = int(d.get("recall_count", 0) or 0) + 1
                    d["last_recall"] = time.time()
                rows.append(d)
            EVENT_ARCHIVE_PATH.write_text(
                "\n".join(json.dumps(r, ensure_ascii=False) for r in rows) + "\n",
                encoding="utf-8")
        except Exception:
            pass

    def _event_context(self, event) -> str:
        events = self._event_archive(9)
        if not events:
            return ""
        events = sorted(events, key=lambda e: float(e.get("importance", 0.0) or 0.0) *
                        (0.5 + 0.5 * float(e.get("centrality", 0.5) or 0.5)), reverse=True)[:3]
        lines = []
        for ev in events:
            title = str(ev.get("title") or "").strip()
            body = str(ev.get("central_details") or ev.get("event") or "").strip()
            meaning = str(ev.get("meaning_to_her") or "").strip()
            reflection = str(ev.get("reflection") or "").strip()
            if body:
                lines.append("- %s：%s%s%s" % (
                    title or "事件", body,
                    ("；意义：" + meaning) if meaning else "",
                    ("；反思：" + reflection) if reflection else ""))
        if not lines:
            return ""
        self._bump_event_recall([str(e.get("id") or "") for e in events])
        return "\n".join(lines)

    def _insights(self, limit: int = 5) -> list:
        try:
            if not INSIGHT_ARCHIVE_PATH.exists():
                return []
            out = []
            for line in INSIGHT_ARCHIVE_PATH.read_text(encoding="utf-8").splitlines()[-limit * 2:]:
                try:
                    d = json.loads(line)
                    if isinstance(d, dict):
                        try:
                            _age_days = (time.time() - float(d.get("ts", 0) or 0)) / 86400.0
                            _central = float(d.get("centrality", 0.5) or 0.5)
                            if _age_days > (14.0 - 10.0 * _central):
                                d["peripheral_details"] = ""
                                d["peripheral_retention"] = min(float(d.get("peripheral_retention", 1.0) or 1.0), 0.05)
                                d["peripheral_forgotten"] = True
                        except Exception:
                            pass
                        out.append(d)
                except Exception:
                    continue
            return out[-limit:][::-1]
        except Exception:
            return []

    def _append_insight(self, record: dict) -> None:
        try:
            EVENT_ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
            with open(INSIGHT_ARCHIVE_PATH, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def _insight_state_path(self):
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return DATA_DIR / "insight_trigger.json"

    def _load_insight_state(self) -> dict:
        try:
            path = self._insight_state_path()
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    return data
        except Exception:
            pass
        return {"last_run_ts": 0.0, "last_event_ts": 0.0, "seen_ids": []}

    def _save_insight_state(self, state: dict) -> None:
        try:
            self._insight_state_path().write_text(
                json.dumps(state, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as exc:
            logger.warning("[biocore] insight trigger state save failed: %s", exc)

    def _insight_trigger_decision(self, state: dict, events: list, now: float | None = None) -> dict:
        """Decide whether the unified insight entry should fire.

        Rules:
        - dedupe by event id + event ts (only events newer than last_event_ts count);
        - >= insight_min_new_events (default 3) new important events
          (importance >= 0.6) AND cooldown >= insight_cooldown_minutes (default 60);
        - 24h ultra-long fallback can fire with at least 1 new important event.
        """
        current = time.time() if now is None else float(now)
        st = state if isinstance(state, dict) else {}
        try:
            last_run = float(st.get("last_run_ts", 0.0) or 0.0)
        except Exception:
            last_run = 0.0
        try:
            last_event_ts = float(st.get("last_event_ts", 0.0) or 0.0)
        except Exception:
            last_event_ts = 0.0
        seen = st.get("seen_ids") if isinstance(st.get("seen_ids"), list) else []
        seen_set = {str(x) for x in seen}
        new_events = []
        for ev in (events or []):
            if not isinstance(ev, dict):
                continue
            try:
                imp = float(ev.get("importance", 0) or 0)
            except Exception:
                imp = 0.0
            if imp < 0.6:
                continue
            eid = str(ev.get("id") or "")
            try:
                ets = float(ev.get("ts", 0) or 0)
            except Exception:
                ets = 0.0
            if eid and eid in seen_set:
                continue
            if ets and ets <= last_event_ts:
                continue
            new_events.append(ev)
        count = len(new_events)
        elapsed = current - last_run if last_run > 0 else None
        _min_new = max(1, int(getattr(self, "_insight_min_new_events",
                                      INSIGHT_MIN_NEW_EVENTS) or INSIGHT_MIN_NEW_EVENTS))
        _cooldown_s = max(60, int(getattr(self, "_insight_cooldown_minutes",
                                          INSIGHT_COOLDOWN_SECONDS // 60)
                                  or (INSIGHT_COOLDOWN_SECONDS // 60)) * 60)
        cooldown_ok = (last_run <= 0) or (elapsed is not None and elapsed >= _cooldown_s)
        fallback_ok = (last_run > 0 and elapsed is not None and
                       elapsed >= self._insight_fallback_hours * 3600)
        ready = (count >= _min_new and cooldown_ok) or (count >= 1 and fallback_ok)
        return {"ready": bool(ready), "new_count": count,
                "new_events": new_events,
                "last_run_ts": last_run, "last_event_ts": last_event_ts}

    async def _maybe_archive_insight(self, event, core, trigger: str = "event_archive"):
        """Automatic long-term insight entry (compression / event archive).

        Only runs when the opt-in auto switch is ON *and* the insight LLM
        switch is ON. There is no silent deterministic fallback: with either
        switch off nothing is written in the background.
        """
        if not bool(getattr(self, "insight_auto_enabled", False)):
            return False
        if not self._llm_allowed("insight"):
            return False
        try:
            state = self._load_insight_state()
            events = self._event_archive(50)
            decision = self._insight_trigger_decision(state, events)
            if not decision["ready"]:
                logger.info("[biocore] insight trigger skipped (%s): new=%s cooldown/fallback not met",
                            trigger, decision["new_count"])
                return False
            new_events = decision["new_events"]
            # BUG-05: _event_archive returns newest-first; use [:6], not [-6:].
            recent = (events[:6] if len(events) >= 3 else new_events[:6])
            ok = await self._generate_insight(event, core, recent)
            if not ok:
                logger.info("[biocore] insight trigger produced nothing (%s); state not advanced", trigger)
                return False
            now = time.time()
            latest_ts = max([decision["last_event_ts"]] +
                            [float(e.get("ts", 0) or 0) for e in events] or [0.0])
            seen = [str(e.get("id") or "") for e in events if str(e.get("id") or "")]
            self._save_insight_state({
                "last_run_ts": now,
                "last_event_ts": latest_ts,
                "seen_ids": seen[-100:],
            })
            logger.info("[biocore] insight triggered (%s): new=%s events=%s",
                        trigger, decision["new_count"], len(recent))
            return True
        except Exception as exc:
            logger.warning("[biocore] insight trigger failed: %s", exc)
            return False

    async def _generate_insight(self, event, core, events):
        """Generate one long-term pattern insight from the given events.

        LLM-only: when the insight switch is off this returns False and writes
        nothing (no silent deterministic note in the background).
        """
        try:
            events = [e for e in (events or []) if isinstance(e, dict)]
            if not events:
                return False
            if not self._llm_allowed("insight"):
                return False
            provider = await self._provider_for("insight", event)
            if provider is None:
                return False
            prompt = interpretation.insight_prompt(events[:6])
            resp = await self._bg_llm_direct(
                "insight", provider, prompt,
                timeout_ms=getattr(self, "summary_llm_timeout_ms", 8000))
            raw = str(getattr(resp, "completion_text", "") or "").strip()
            insight = interpretation.parse_insight(raw)
            if not insight:
                return False
            self._append_insight({
                "ts": time.time(), "insight": insight,
                "emotion": str(getattr(core, "labels", {}).get("emotion") or "neutral") if core else "neutral",
            })
            try:
                if core is not None:
                    tree = getattr(core, "reflection_tree", None)
                    if not isinstance(tree, dict):
                        tree = {"roots": [], "count": 0}
                    node = {"ts": time.time(), "insight": insight,
                            "emotion": str(getattr(core, "labels", {}).get("emotion") or "neutral"),
                            "children": []}
                    roots = tree.get("roots") or []
                    if roots:
                        roots[-1].setdefault("children", []).append(node)
                    else:
                        roots.append(node)
                    tree["roots"] = roots[-10:]
                    tree["count"] = int(tree.get("count", 0)) + 1
                    core.reflection_tree = tree
                    core.integrate_noise("reflection", attention=0.006, valence=0.003)
            except Exception:
                pass
            logger.info("[biocore] long-term insight archived")
            return True
        except Exception as exc:
            logger.warning("[biocore] insight generation failed: %s", exc)
            return False

    async def _archive_cross_event_insight(self, event, core):
        """Compatibility wrapper for direct callers: uses the last 6 events."""
        events = self._event_archive(6)
        if len(events) < 3:
            return
        await self._generate_insight(event, core, events[:6])

    def _segment_event_texts(self, entries) -> list:
        try:
            rows = []
            for e in entries:
                txt = str(e.get("text", "")).strip()
                cap = str(e.get("image_caption", "") or "").strip()
                if cap:
                    txt = (txt + "\n[图片内容] " + cap).strip() if txt else ("[图片内容] " + cap)
                if txt:
                    rows.append((float(e.get("ts", 0) or 0), txt, e))
            rows.sort(key=lambda x: x[0])
        except Exception:
            return []
        segments = []
        current = []
        last = None
        for ts, txt, e in rows:
            _changed = False
            if current:
                try:
                    _changed = self._text_similarity(str(current[-1][0]), str(txt)) < 0.045 and len(str(txt)) > 8
                except Exception:
                    _changed = False
            if last is not None and ((ts - last > 1800) or _changed) and current:
                segments.append(current)
                current = []
            current.append((txt, e))
            last = ts
        if current:
            segments.append(current)
        out = []
        for seg in segments[-3:]:
            out.append([x[0] for x in seg])
        return out

    def _append_event_archive(self, record: dict) -> None:
        try:
            EVENT_ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
            if isinstance(record, dict):
                _raw_key = str(record.get("event_key") or record.get("title") or "")
                _norm_key = self._normalize_event_key(_raw_key, str(record.get("title") or ""))
                if _norm_key:
                    record["event_key"] = _norm_key
                # Batch5 H2-1: <=3 event-event edges (time proximity 1800s +
                # causal words), Radvansky & Zacks 2014; Trabasso 1985.
                if getattr(self, "memory_chain_enabled", False):
                    try:
                        _sess = str(record.get("session") or "default")
                        _recent = self._recent_session_events(_sess, 3)
                        _text = " ".join(str(record.get(k) or "") for k in
                                         ("title", "event", "big_summary"))
                        _causal = any(w in _text for w in
                                      ("因为", "所以", "导致", "于是", "结果", "因此", "然后", "后来"))
                        _rts = float(record.get("ts", 0) or 0)
                        _links = []
                        for _prev in _recent[-3:]:
                            if not isinstance(_prev, dict) or not _prev.get("id"):
                                continue
                            _gap = abs(_rts - float(_prev.get("ts", 0) or 0))
                            if _gap > 1800.0:
                                continue
                            _w = 1.0 if _causal else max(0.5, 1.0 - 0.5 * _gap / 1800.0)
                            _links.append({"id": str(_prev["id"]), "weight": round(_w, 3),
                                           "ts": _rts, "kind": "causal" if _causal else "temporal"})
                            if len(_links) >= 3:
                                break
                        if _links:
                            record["chain_links"] = _links
                    except Exception:
                        pass
            line = json.dumps(record, ensure_ascii=False)
            with open(EVENT_ARCHIVE_PATH, "a", encoding="utf-8") as f:
                f.write(line + "\n")
            _sess = str(record.get("session") or "default")
            _safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in _sess)[:80]
            _dir = EVENT_SESSION_DIR / _safe
            _dir.mkdir(parents=True, exist_ok=True)
            with open(_dir / "events.jsonl", "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception as exc:
            logger.warning("[biocore] event archive failed: %s", exc)

    def _chain_event_lines(self, session: str, query: str, limit: int = 2) -> list:
        """H2-1 read path: decayed event-chain expansion (default OFF).

        Only called when memory_chain_enabled. Seeds = same-session event with
        the highest character overlap with the query; follows its chain_links
        (hop<=1), applies 30-day decay, returns <=limit lines (no avalanche).
        """
        if not getattr(self, "memory_chain_enabled", False):
            return []
        try:
            events = [e for e in self._event_archive(100) if isinstance(e, dict)]
            sess = str(session or "")
            same = [e for e in events if str(e.get("session") or "default") == sess]
            if not same:
                return []
            q = set(str(query or ""))
            def _overlap(e):
                txt = str(e.get("title") or "") + " " + str(e.get("big_summary") or "")
                return len(q & set(txt))
            same.sort(key=lambda e: (-_overlap(e), -float(e.get("ts", 0) or 0)))
            seed = same[0]
            # task-35 H2-3: bounded multi-hop expansion (default OFF; hop<=2,
            # fan<=3, decay .5, new<=6). Off => the legacy 1-hop path below.
            if getattr(self, "memory_chain_multihop", False):
                try:
                    # activation decays 0.5/hop; min_weight 0.2 keeps hop-2
                    # reachable while hop-3 still fails (hop_limit=2).
                    # chain_expand consumes memory-entry "links"; archived events
                    # store the same edges as "chain_links", so map them here.
                    _nodes = [{
                        "id": str(e.get("id") or ""),
                        "text": (str(e.get("title") or "") + " "
                                 + str(e.get("big_summary") or "")).strip()[:160],
                        "links": [x for x in (e.get("chain_links") or [])
                                  if isinstance(x, dict)],
                    } for e in same]
                    rows = memory_meta.chain_expand(
                        _nodes, [str(seed.get("id") or "")], hop_limit=2,
                        fan_out=3, decay=0.5, min_weight=0.2, max_new=6)
                except Exception:
                    rows = []
                out = []
                for row in rows:
                    text = str(row.get("text") or "").strip().replace("\n", " ")
                    if text:
                        out.append("- 关联事件(多跳 %.2f)：%s" % (
                            float(row.get("activation") or 0.0), text[:160]))
                    if len(out) >= limit:
                        break
                return out
            out = []
            for link in (seed.get("chain_links") or [])[:3]:
                if not isinstance(link, dict):
                    continue
                lid = str(link.get("id") or "")
                target = next((e for e in same if str(e.get("id") or "") == lid), None)
                if not target:
                    continue
                w = memory_meta.decayed_chain_weight(link.get("weight", 1.0), link.get("ts", 0))
                if w < 0.1:
                    continue
                text = str(target.get("title") or target.get("big_summary") or "").strip().replace("\n", " ")
                if text:
                    out.append("- 关联事件(链 %.2f)：%s" % (w, text[:160]))
                if len(out) >= limit:
                    break
            return out
        except Exception:
            return []

    def _attachments_from_messages(self, event) -> list:
        out = []
        try:
            for m in event.get_messages() or []:
                if isinstance(m, Image):
                    ref = str(getattr(m, "url", "") or getattr(m, "file", "") or getattr(m, "path", "") or "").strip()
                    if ref:
                        out.append({"type": "image", "ref": ref[:500]})
                elif isinstance(m, Record):
                    ref = str(getattr(m, "url", "") or getattr(m, "file", "") or "").strip()
                    if ref:
                        out.append({"type": "voice", "ref": ref[:500]})
        except Exception:
            pass
        return out

    def _message_refs(self, event) -> list:
        refs = []
        try:
            for msg in event.get_messages() or []:
                got = False
                for attr in ("id", "message_id", "msg_id", "message_seq"):
                    try:
                        value = getattr(msg, attr, None)
                    except Exception:
                        value = None
                    if value:
                        refs.append(str(value)[:80])
                        got = True
                        break
                if not got:
                    text = str(getattr(msg, "text", "") or "")
                    if text:
                        refs.append(_sha256(text)[:16])
        except Exception:
            pass
        return refs[:8]

    def _memory_provenance(self, event, ts=None) -> dict:
        try:
            _sid, _sname = self._speaker(event)
        except Exception:
            _sid, _sname = "", ""
        return {"sender_id": _sid, "sender_name": _sname,
                "session": str(getattr(event, "unified_msg_origin", "") or ""),
                "ts": float(ts if ts is not None else time.time()),
                "message_refs": self._message_refs(event)}

    def _event_provenance(self, event, entries=None, ts=None) -> dict:
        prov = self._memory_provenance(event, ts)
        sources = []
        refs = list(prov.get("message_refs") or [])
        senders = {str(prov.get("sender_id") or "")}
        if entries:
            for e in entries[-24:]:
                p = e.get("provenance") if isinstance(e, dict) else None
                if not isinstance(p, dict):
                    continue
                item = {"sender_id": str(p.get("sender_id") or ""),
                        "sender_name": str(p.get("sender_name") or ""),
                        "session": str(p.get("session") or ""),
                        "ts": float(p.get("ts", 0) or 0),
                        "message_refs": list(p.get("message_refs") or [])[:6]}
                sources.append(item)
                senders.add(item["sender_id"])
                refs.extend(item["message_refs"])
        prov["sources"] = sources[-24:]
        prov["message_refs"] = list(dict.fromkeys([str(x) for x in refs if x]))[:12]
        prov["senders"] = sorted([x for x in senders if x])
        return prov

    @staticmethod
    def _source_check(text: str, texts, provenance=None, record_ts=None) -> dict:
        try:
            src = "".join(str(t) for t in texts)
            src_chars = {c for c in src if not c.isspace() and c not in "，。！？、；：,.!?;:"}
            body = {c for c in str(text or "") if not c.isspace() and c not in "，。！？、；：,.!?;:"}
            if not body:
                return {"overlap": 0.0, "coverage": 0.0, "novelty": 0.0,
                        "length_ratio": 0.0, "status": "empty",
                        "source_items": [], "time_ok": True, "speaker_ok": True,
                        "cross_ref": 0}
            overlap = sum(1 for c in body if c in src_chars) / max(1, len(body))
            covered = sum(1 for c in src_chars if c in body) / max(1, len(src_chars))
            novelty = max(0.0, len(body - src_chars) / max(1, len(body)))
            ratio = len(str(text or "")) / max(1, len(src))
            source_items = []
            try:
                prov = provenance if isinstance(provenance, dict) else {}
                _srcs = prov.get("sources") if isinstance(prov.get("sources"), list) else []
                if _srcs:
                    source_items = [dict(x) for x in _srcs if isinstance(x, dict)][:24]
                elif prov:
                    source_items = [{
                        "sender_id": str(prov.get("sender_id") or ""),
                        "sender_name": str(prov.get("sender_name") or ""),
                        "session": str(prov.get("session") or ""),
                        "ts": float(prov.get("ts", 0) or 0),
                        "message_refs": list(prov.get("message_refs") or []),
                    }]
            except Exception:
                source_items = []
            # time_ok: evidence cannot postdate the record and must be near it.
            time_ok = True
            try:
                _rts = float(record_ts if record_ts is not None else 0.0)
                _ts = [float(x.get("ts", 0) or 0) for x in source_items
                       if float(x.get("ts", 0) or 0) > 0]
                if _rts > 0 and _ts:
                    time_ok = (max(_ts) <= _rts + 300.0) and ((_rts - min(_ts)) <= 7 * 86400.0)
            except Exception:
                time_ok = True
            # speaker_ok: the claimed speaker must appear among the sources.
            speaker_ok = True
            try:
                _claim_sid = str((provenance or {}).get("sender_id") or "") if isinstance(provenance, dict) else ""
                _sids = {str(x.get("sender_id") or "") for x in source_items if str(x.get("sender_id") or "")}
                if _claim_sid and _sids:
                    speaker_ok = _claim_sid in _sids
            except Exception:
                speaker_ok = True
            # cross_ref: count independent evidence items / message refs.
            cross_ref = 0
            try:
                _refs = set()
                for x in source_items:
                    for r in (x.get("message_refs") or []):
                        _refs.add(str(r))
                cross_ref = max(len(source_items), len(_refs))
            except Exception:
                cross_ref = len(source_items)
            if overlap >= 0.55 and novelty <= 0.25 and ratio <= 1.6:
                status = "ok"
            elif overlap >= 0.35 and novelty <= 0.45:
                status = "weak"
            else:
                status = "suspect"
            if not time_ok or not speaker_ok:
                if status == "ok":
                    status = "weak"
            return {"overlap": round(overlap, 3), "coverage": round(covered, 3),
                    "novelty": round(novelty, 3), "length_ratio": round(ratio, 3),
                    "status": status, "source_items": source_items[:24],
                    "time_ok": bool(time_ok), "speaker_ok": bool(speaker_ok),
                    "cross_ref": int(cross_ref)}
        except Exception:
            return {"overlap": 0.0, "status": "unknown"}

    @staticmethod
    def _event_session_file(session: str) -> Path:
        _safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in str(session or "default"))[:80]
        return EVENT_SESSION_DIR / _safe / "events.jsonl"

    def _last_session_event(self, session: str):
        try:
            path = self._event_session_file(session)
            if not path.exists():
                return None
            for line in reversed(path.read_text(encoding="utf-8").splitlines()):
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                if isinstance(d, dict):
                    return d
        except Exception:
            pass
        return None

    def _event_boundary(self, session: str, body: str, ts: float) -> dict:
        """Zacks et al. (2007) event segmentation for the event archive.

        Boundary = weighted elapsed-time gap + content dissimilarity against
        the previous event in the same session. A boundary below the split
        threshold continues the previous episode and inherits its id as
        parent_event_id; a strong boundary starts a new root event.
        """
        prev = self._last_session_event(session)
        if not isinstance(prev, dict):
            return {"boundary_score": 0.0, "parent_event_id": "",
                    "gap_seconds": 0.0, "similarity": 0.0}
        try:
            gap = max(0.0, float(ts) - float(prev.get("ts", 0) or 0))
        except Exception:
            gap = 0.0
        try:
            sim = float(self._text_similarity(str(body or ""), str(prev.get("event") or prev.get("title") or "")))
        except Exception:
            sim = 0.0
        gap_norm = max(0.0, min(1.0, gap / EVENT_BOUNDARY_WINDOW_SECONDS))
        score = max(0.0, min(1.0, EVENT_BOUNDARY_TIME_WEIGHT * gap_norm
                            + EVENT_BOUNDARY_TEXT_WEIGHT * (1.0 - sim)))
        parent = ""
        if score < EVENT_BOUNDARY_PARENT_THRESHOLD:
            parent = str(prev.get("id") or "")
        return {"boundary_score": round(score, 3), "parent_event_id": parent,
                "gap_seconds": round(gap, 3), "similarity": round(sim, 3)}

    @staticmethod
    def _text_similarity(a: str, b: str) -> float:
        """Bigram Jaccard similarity shared by archive/dedupe paths (task-56).

        BioCore keeps its own copy for the state machine; the plugin-level
        archive code calls this through ``self`` so duplicate detection and
        event boundary scoring actually run instead of raising AttributeError
        inside the surrounding try/except.
        """
        return BioCore._text_similarity(a, b)

    @staticmethod
    def _normalize_event_key(key: str, title: str = "") -> str:
        """Normalize event identity: NFKC, lowercase, punctuation/joiners removed."""
        import unicodedata

        def _norm(value) -> str:
            s = unicodedata.normalize("NFKC", str(value or "")).strip().lower()
            s = s.replace("／", "/").replace("·", "")
            s = re.sub(r"[\s\-_/\\|｜&＆+＋~～,，.。、;；:：!！?？'\"“”‘’()（）\[\]【】<>《》]+", "", s)
            return s[:120]

        out = _norm(key)
        if not out:
            out = _norm(title)
        if not out:
            out = "evt_" + _sha256(str(key) + "|" + str(title))[:12]
        return out

    def _recent_session_events(self, session: str, limit: int = 20) -> list:
        try:
            path = self._event_session_file(session)
            if not path.exists():
                return []
            rows = []
            for line in reversed(path.read_text(encoding="utf-8").splitlines()):
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                if isinstance(d, dict):
                    rows.append(d)
                if len(rows) >= limit:
                    break
            return rows
        except Exception:
            return []

    def _find_duplicate_event(self, session: str, event_key: str, body: str, ts: float):
        """Return the same-session archived event this record duplicates."""
        try:
            for prev in self._recent_session_events(session, 20):
                prev_key = self._normalize_event_key(
                    str(prev.get("event_key") or prev.get("title") or ""),
                    str(prev.get("title") or ""))
                if not prev_key:
                    continue
                try:
                    # task-56: compare against the real event time so a
                    # re-archived row is not treated as a new event.
                    gap = abs(float(ts) - event_effective_time(prev))
                except Exception:
                    gap = 0.0
                if gap > EVENT_DUP_WINDOW_SECONDS:
                    continue
                if prev_key == event_key:
                    return prev
                if self._text_similarity(prev_key, event_key) >= EVENT_KEY_SIM_THRESHOLD:
                    body_sim = self._text_similarity(str(body or ""), str(prev.get("event") or ""))
                    if body_sim >= 0.45:
                        return prev
            # task-57: the same real session may be archived under ":" and "_"
            # variants; compare canonical keys across the archive too.
            target_session = canonical_session_key(session)
            try:
                _event_key = self._normalize_event_key(str(event_key or ""), "")
            except Exception:
                _event_key = str(event_key or "")
            for prev in self._event_archive(200):
                if canonical_session_key(prev.get("session")) != target_session:
                    continue
                try:
                    gap = abs(float(ts) - event_effective_time(prev))
                except Exception:
                    gap = 0.0
                if gap > EVENT_DUP_WINDOW_SECONDS:
                    continue
                prev_key = self._normalize_event_key(
                    str(prev.get("event_key") or prev.get("title") or ""),
                    str(prev.get("title") or ""))
                if prev_key and prev_key == _event_key:
                    return prev
                if prev_key and self._text_similarity(prev_key, _event_key) >= EVENT_KEY_SIM_THRESHOLD:
                    if self._text_similarity(str(body or ""), str(prev.get("event") or "")) >= 0.45:
                        return prev
                if self._text_similarity(str(body or ""), str(prev.get("event") or "")) >= 0.60:
                    return prev
        except Exception:
            pass
        return None

    def _find_global_duplicate_event(self, event_key: str, body: str, ts: float):
        """Cross-session event identity: same normalized key + body within window."""
        try:
            if not EVENT_ARCHIVE_PATH.exists():
                return None
            event_key = self._normalize_event_key(str(event_key or ""), "")
            lines = EVENT_ARCHIVE_PATH.read_text(encoding="utf-8").splitlines()
            for line in reversed(lines[-200:]):
                try:
                    prev = json.loads(line)
                except Exception:
                    continue
                if not isinstance(prev, dict):
                    continue
                prev_key = self._normalize_event_key(
                    str(prev.get("event_key") or prev.get("title") or ""),
                    str(prev.get("title") or ""))
                if not prev_key:
                    continue
                try:
                    gap = abs(float(ts) - event_effective_time(prev))
                except Exception:
                    gap = 0.0
                if gap > EVENT_DUP_WINDOW_SECONDS:
                    continue
                if prev_key == event_key:
                    return prev
                if self._text_similarity(prev_key, event_key) >= EVENT_KEY_SIM_THRESHOLD:
                    if self._text_similarity(str(body or ""),
                                             str(prev.get("event") or "")) >= 0.45:
                        return prev
        except Exception:
            pass
        return None

    def _find_any_duplicate_event(self, session: str, event_key: str, body: str, ts: float):
        """Same-session duplicate first, then cross-session global duplicate."""
        prev = self._find_duplicate_event(session, event_key, body, ts)
        if prev is not None:
            return prev
        return self._find_global_duplicate_event(event_key, body, ts)

    def _merge_archive_duplicate(self, prev: dict, record: dict) -> None:
        """Merge a duplicate event into the existing archive row atomically."""
        try:
            prev_id = str(prev.get("id") or "")
            if not prev_id:
                return
            _new_key = str(record.get("event_key") or "")
            _new_ts = float(record.get("ts", 0) or 0)
            _new_sources = list((record.get("provenance") or {}).get("sources") or [])[:12]
            _new_texts = list(record.get("source_texts") or [])[:12]

            def _mutate(obj):
                if str(obj.get("id") or "") != prev_id:
                    return False
                merged = [str(x) for x in (obj.get("merged_event_keys") or [])]
                if _new_key and _new_key not in merged:
                    merged.append(_new_key)
                obj["merged_event_keys"] = merged[:12]
                try:
                    obj["ts"] = max(float(obj.get("ts", 0) or 0), _new_ts)
                except Exception:
                    obj["ts"] = _new_ts
                obj["importance"] = round(max(float(obj.get("importance", 0) or 0),
                                              float(record.get("importance", 0) or 0)), 3)
                obj["centrality"] = round(max(float(obj.get("centrality", 0) or 0),
                                              float(record.get("centrality", 0) or 0)), 3)
                obj["merge_count"] = int(obj.get("merge_count", 0) or 0) + 1
                src = [str(x) for x in (obj.get("source_texts") or [])[-24:]]
                for _t in _new_texts:
                    if _t and _t not in src:
                        src.append(str(_t))
                obj["source_texts"] = src[-24:]
                prov = dict(obj.get("provenance") or {})
                sources = [x for x in (prov.get("sources") or []) if isinstance(x, dict)][-24:]
                for _item in _new_sources:
                    if isinstance(_item, dict) and _item not in sources:
                        sources.append(_item)
                prov["sources"] = sources[-24:]
                obj["provenance"] = prov
                return True

            session = str(prev.get("session") or record.get("session") or "default")
            self._rewrite_jsonl_atomic(EVENT_ARCHIVE_PATH, _mutate)
            self._rewrite_jsonl_atomic(self._event_session_file(session), _mutate)
            logger.info("[biocore] duplicate event merged: %s key=%s", prev.get("title"), _new_key)
        except Exception as exc:
            logger.warning("[biocore] duplicate merge failed: %s", exc)

    async def _archive_ranked_events_deterministic(self, event, core, entries):
        """Deterministic event candidate generation + embedding ranking.

        Used when the LLM event_ranking function is off (the default): split
        recent messages into event segments, score them with importance /
        self-schema congruence / embedding novelty / commitment cues, and
        archive the top candidates. The LLM is still optional via event_summary.
        """
        try:
            segments = self._segment_event_texts(entries)
            if not segments:
                return
            now = time.time()
            recent_events = self._event_archive(10)
            candidates = []
            for seg_texts in segments:
                seg_text = "\n".join(str(t) for t in seg_texts if str(t).strip()).strip()
                if len(seg_text) < 8:
                    continue
                seg_set = {str(t).strip() for t in seg_texts if str(t).strip()}
                seg_entries = [e for e in entries
                               if str(e.get("text", "")).strip() in seg_set]
                imp = 0.5
                vecs = []
                for e in seg_entries:
                    try:
                        imp = max(imp, float(e.get("importance", 0.5) or 0.5))
                    except Exception:
                        pass
                    _v = e.get("vector") if isinstance(e.get("vector"), list) else []
                    if _v:
                        vecs.append(_v)
                try:
                    schema = memory_meta.schema_congruence(
                        seg_text, self._self_schema_texts(core))
                except Exception:
                    schema = 0.0
                try:
                    # M1: an event segment that contains an already-tagged
                    # sensitive memory is withheld from the provider when safety
                    # is on (default off => identical to 1.2.98).
                    _seg_sensitive = any(bool(e.get("sensitive")) for e in seg_entries)
                    vec = await self._embedding_for(
                        "event_ranking", seg_text[:600],
                        sensitive=self._embed_skip_sensitive(_seg_sensitive))
                except Exception:
                    vec = []
                if not vec and vecs:
                    try:
                        dim = len(vecs[0])
                        vec = [sum(float(v[i]) for v in vecs if i < len(v)) / len(vecs)
                               for i in range(dim)]
                    except Exception:
                        vec = []
                novelty = 0.6
                max_cos = 0.0
                for ev in recent_events:
                    _ev = ev.get("event_embedding") if isinstance(ev, dict) else None
                    if isinstance(_ev, list) and _ev:
                        max_cos = max(max_cos, self._cosine(vec, _ev))
                if vec and max_cos > 0:
                    novelty = max(0.0, min(1.0, 1.0 - max_cos))
                cues = sum(1 for w in ("承诺", "答应", "喜欢", "讨厌", "对不起", "谢谢",
                                        "以后", "永远", "骗", "害怕", "难过", "别")
                           if w in seg_text)
                cue_score = min(1.0, cues / 3.0)
                score = 0.35 * imp + 0.25 * schema + 0.20 * novelty + 0.20 * cue_score
                if imp < 0.55 or score < 0.40:
                    continue
                candidates.append((score, seg_text, seg_entries, vec, schema, imp))
            if len(candidates) > 1 and getattr(self, "event_ranking_llm", False):
                _docs = [c[1] for c in candidates]
                _rs = await self._rerank_scores(
                    "event_ranking", "最近对话中值得记住的重要事件", _docs)
                if _rs:
                    candidates = [
                        (round(0.6 * c[0] + 0.4 * float(_rs.get(i, 0.0)), 4),
                         c[1], c[2], c[3], c[4], c[5])
                        for i, c in enumerate(candidates)
                    ]
            candidates.sort(key=lambda x: x[0], reverse=True)
            _digest_event_ids = []
            for score, body, seg_entries, vec, schema, imp in candidates[:2]:
                title = interpretation.clean_event_title(body) or "对话事件"
                _ekey = self._normalize_event_key(title, title)
                prov = self._event_provenance(event, entries, ts=now)
                check = self._source_check(body, [str(t) for t in seg_entries],
                                           provenance=prov, record_ts=now)
                # task-56: duplicate detection compares the real message time
                # (time_span end), not the archival moment, so a delayed
                # re-archive of the same conversation still dedupes.
                try:
                    _real_ts = max(float(e.get("ts", 0) or 0) for e in seg_entries
                                   if float(e.get("ts", 0) or 0) > 0)
                except Exception:
                    _real_ts = now
                dup = self._find_any_duplicate_event(
                    str(getattr(event, "unified_msg_origin", "") or ""), _ekey, body, _real_ts)
                if dup is not None:
                    continue
                _imp = round(max(0.55, min(1.0, imp * 0.7 + score * 0.3)), 3)
                _safe_title = self._mask_if_safety(title)
                _safe_body = self._mask_if_safety(self._event_excerpt(body, 220))
                _safe_big, _safe_small = self._dual_event_summary_fallback(body, title)
                record = {
                    "id": "evt_" + str(int(now)) + "_" + str(abs(hash(title + body)) % 100000),
                    "ts": now,
                    "session": str(getattr(event, "unified_msg_origin", "") or ""),
                    "title": _safe_title,
                    "event": _safe_body[:600],
                    "big_summary": _safe_big,
                    "small_summary": _safe_small,
                    "summary_status": "fallback",
                    "event_key": _ekey,
                    "centrality": round(max(0.0, min(1.0, schema)), 3),
                    "central_details": _safe_body[:180],
                    "peripheral_details": "",
                    "meaning_to_her": "",
                    "reflection": "",
                    "emotion": str((getattr(core, "labels", {}) or {}).get("emotion") or "neutral") if core else "neutral",
                    "emotion_secondary": self._secondary_emotion(core),
                    "emotion_nuance": [],
                    "emotion_layers": self._event_emotion_layers(core),
                    "emotion_layers_source": "core",
                    "emotion_intensity": self._event_emotion_intensity(core),
                    "importance": _imp,
                    "appraisal": dict(core.appraisal) if core is not None else {},
                    "confidence": round(max(0.2, min(1.0, 0.55 + 0.45 * float(check.get("overlap", 0)))), 3),
                    "source_count": len(seg_entries),
                    "source_check": check,
                    "provenance": prov,
                    "attachments": [],
                    "modalities": [],
                    "recall_count": 0,
                    "last_recall": now,
                    "strength": _imp,
                    "source_texts": [self._mask_if_safety(t) for t in seg_texts[:12]],
                    "ranking_mode": "deterministic_embedding",
                    "milestone": relationship_meta.milestone_from_text(title + " " + body),
                }
                if vec:
                    record["event_embedding"] = [round(float(x), 5) for x in vec]
                try:
                    times = [float(e.get("ts", 0) or 0) for e in seg_entries]
                    times = [t for t in times if t > 0]
                    if times:
                        record["time_span"] = {"start_ts": round(min(times), 3),
                                               "end_ts": round(max(times), 3),
                                               "span_seconds": round(max(times) - min(times), 3)}
                except Exception:
                    pass
                # task-33: worthiness gate (OFF => legacy: archive everything).
                _memory_point = True
                try:
                    _rel = self._relationship_of(self._user_record(event))
                except Exception:
                    _rel = {}
                _worth_inputs = None
                try:
                    _worth, _worth_inputs = self._event_worthiness_bundle(
                        record, core, _rel, text=body, title=title, schema=schema)
                except Exception as exc:
                    logger.warning("[biocore] worthiness failed: %s", exc)
                    _worth = None
                if _worth is not None:
                    record["worthiness"] = _worth
                    if _worth_inputs is not None:
                        record["worthiness_inputs"] = _worth_inputs
                    _memory_point = _worth.get("decision") == "memory_point"
                    record["memory_point"] = bool(_memory_point)
                    if _worth.get("decision") == "skip":
                        logger.info("[biocore] event below worthiness floor: %s W=%.3f reason=%s",
                                    title, _worth.get("W", 0.0), _worth.get("reason", ""))
                        continue
                self._append_event_archive(record)
                if _memory_point:
                    _digest_event_ids.append(record.get("id"))
                    if core is not None:
                        try:
                            core.integrate_noise("event_summary", attention=0.005)
                        except Exception:
                            pass
                logger.info("[biocore] deterministic event archived: %s score=%.2f mp=%s",
                            title, score, _memory_point)
        except Exception as exc:
            logger.warning("[biocore] deterministic event ranking failed: %s", exc)
        try:
            if core is not None:
                core.update_daily_digest(event_ids=_digest_event_ids)
        except Exception:
            pass
        await self._maybe_archive_insight(event, core, "event_archive")

    async def _archive_ranked_events(self, event, core, entries):
        """Deterministic embedding/rule event extraction (LLM is never used here).

        The event_ranking switch merely enables/disables this local pipeline;
        event summarization stays a separate optional function (event_summary).
        """
        if not entries:
            return
        if not self._llm_allowed("event_ranking"):
            return
        await self._archive_ranked_events_deterministic(event, core, entries)

    async def _archive_strong_event(self, event, core, texts, summary, attachments=None):
        if core is None:
            return
        intensity = float(core._intensity())
        strong = (intensity >= 0.35 or abs(float(core.v)) >= 0.40 or
                  float(core.a) >= 0.75 or float(core.stress) >= 0.65 or
                  (abs(float(core.v)) >= 0.28 and float(core.a) >= 0.60))
        if not strong or not texts:
            return
        if not self._llm_allowed("event_summary"):
            return
        texts = [self._mask_if_safety(t) for t in texts if str(t).strip()]
        try:
            provider = await self._provider_for("event_summary", event)
            data = {}
            if provider is not None:
                prompt = interpretation.event_summary_prompt(texts)
                resp = await self._bg_llm_direct(
                    "event_summary", provider, prompt,
                    timeout_ms=getattr(self, "summary_llm_timeout_ms", 8000))
                raw = str(getattr(resp, "completion_text", "") or "").strip()
                data = interpretation.parse_event_summary(
                    raw, getattr(self, "summary_max_chars", 0))
            else:
                # P2: provider missing => deterministic fallback record, never drop.
                _fb_big, _fb_small = self._dual_event_summary_fallback(
                    " ".join(texts), str(summary or ""))
                data = {"big_summary": _fb_big, "small_summary": _fb_small}
                self._record_llm_telemetry("event_summary", "fallback_no_provider")
            _llm_big = str(data.get("big_summary") or "").strip()
            _llm_small = str(data.get("small_summary") or "").strip()
            title = str(data.get("title") or summary or "重要事件").strip()[:80]
            title = self._mask_if_safety(title)
            ev = self._mask_if_safety(self._summary_cap(str(data.get("event") or summary or "").strip()))
            big_summary = self._mask_if_safety(self._summary_cap(
                str(_llm_big or ev or summary or "").strip()))
            small_summary = self._mask_if_safety(
                str(_llm_small or big_summary or ev).strip())[:80]
            summary_status = "llm" if (_llm_big or _llm_small) else "fallback"
            meaning = self._mask_if_safety(self._summary_cap(str(data.get("meaning_to_her") or "").strip()))
            reflection = self._mask_if_safety(self._summary_cap(str(data.get("reflection") or "").strip()))
            if not ev:
                return
            _prov = self._event_provenance(event, None, ts=time.time())
            _check = self._source_check(ev, texts, provenance=_prov, record_ts=_prov.get("ts"))
            _ekey = self._normalize_event_key(title, title)
            _conf = round(max(0.2, min(1.0, 0.55 + 0.45 * float(_check.get("overlap", 0)))), 3)
            record = {
                "id": "evt_" + str(int(time.time())) + "_" + str(abs(hash(summary)) % 100000),
                "ts": time.time(),
                "session": str(getattr(event, "unified_msg_origin", "") or ""),
                "title": title,
                "event": ev,
                "big_summary": big_summary,
                "small_summary": small_summary,
                "summary_status": summary_status,
                "event_key": _ekey,
                "meaning_to_her": meaning,
                "reflection": reflection,
                "emotion": str(core.labels.get("emotion") or "neutral"),
                "emotion_secondary": self._secondary_emotion(core),
                "emotion_nuance": self._normalize_emotion_nuance(
                    data.get("emotion_nuance")),
                "emotion_layers": (interpretation.clean_emotion_layers(
                    data.get("emotion_layers")) or None),
                "emotion_layers_source": ("summary"
                    if interpretation.clean_emotion_layers(
                        data.get("emotion_layers")) else ""),
                "emotion_intensity": self._event_emotion_intensity(core),
                "importance": round(max(0.5, min(1.0, intensity)), 3),
                "appraisal": dict(core.appraisal),
                "confidence": _conf,
                "source_count": len(texts),
                "source_check": _check,
                "provenance": _prov,
                "attachments": (attachments or [])[:20],
                "modalities": sorted(set(["图片"] if any(a.get("type") == "image" for a in (attachments or [])) else []) | set(["语音"] if any(a.get("type") == "voice" for a in (attachments or [])) else [])),
                "recall_count": 0,
                "last_recall": time.time(),
                "strength": round(max(0.5, min(1.0, intensity)), 3),
                "source_texts": [self._mask_if_safety(t) for t in texts[:12]],
            }
            # task-33: same worthiness gate as the deterministic path.
            _memory_point = True
            try:
                _rel = self._relationship_of(self._user_record(event))
            except Exception:
                _rel = {}
            _worth_inputs = None
            try:
                _worth, _worth_inputs = self._event_worthiness_bundle(
                    record, core, _rel, text=ev, title=title)
            except Exception as exc:
                logger.warning("[biocore] worthiness failed: %s", exc)
                _worth = None
            if _worth is not None:
                record["worthiness"] = _worth
                if _worth_inputs is not None:
                    record["worthiness_inputs"] = _worth_inputs
                _memory_point = _worth.get("decision") == "memory_point"
                record["memory_point"] = bool(_memory_point)
                if _worth.get("decision") == "skip":
                    logger.info("[biocore] strong event below worthiness floor: %s W=%.3f",
                                title, _worth.get("W", 0.0))
                    return
            _dup = self._find_any_duplicate_event(record.get("session") or "", _ekey, ev,
                                                 record.get("ts") or time.time())
            if _dup is not None:
                record["duplicate_of"] = str(_dup.get("id") or "")
                self._merge_archive_duplicate(_dup, record)
                return
            _bnd = self._event_boundary(record.get("session") or "", ev, record.get("ts") or time.time())
            record["boundary_score"] = _bnd.get("boundary_score", 0.0)
            record["parent_event_id"] = _bnd.get("parent_event_id", "")
            self._append_event_archive(record)
            if core is not None:
                try:
                    core.integrate_noise("event_summary", attention=0.005)
                except Exception:
                    pass
            await self._maybe_archive_insight(event, core, "event_archive")
            try:
                if core is not None:
                    core.update_daily_digest(event_ids=[record.get("id")])
            except Exception:
                pass
            if _memory_point:
                self._update_self_narrative(title, reflection or meaning)
            logger.info("[biocore] strong event archived: %s mp=%s", title, _memory_point)
        except Exception as exc:
            logger.warning("[biocore] strong event summary failed: %s", exc)
            self._record_llm_telemetry("event_summary", "error", str(exc))

    async def _maybe_archive_events(self, event, core=None):
        """Request-path hook: make deterministic event archive reachable."""
        if not self._llm_allowed("event_ranking"):
            return
        now = time.time()
        if now - float(getattr(self, "_last_event_archive", 0.0)) < 300:
            return
        try:
            doc = self._load_memory(event)
            entries = doc.get("entries") if isinstance(doc, dict) else []
            if not isinstance(entries, list) or not entries:
                return
            self._last_event_archive = now
            await self._archive_ranked_events(event, core, entries)
        except Exception as exc:
            logger.warning("[biocore] request-path event archive failed: %s", exc)

    async def _maybe_archive_strong_event(self, event, core, text=""):
        """Request-path hook: wire the single-event summary path (BUG-01)."""
        if not self._llm_allowed("event_summary"):
            return
        key = str(getattr(event, "unified_msg_origin", "") or "")
        now = time.time()
        try:
            last_map = getattr(self, "_last_strong_event_summary", None)
            if not isinstance(last_map, dict):
                last_map = {}
                self._last_strong_event_summary = last_map
            if now - float(last_map.get(key, 0.0) or 0.0) < 600:
                return
            texts = [str(h.get("text") or "").strip() for h in (getattr(core, "history", None) or [])[-6:]
                     if isinstance(h, dict) and str(h.get("text") or "").strip()]
            if str(text or "").strip():
                texts.append(str(text).strip())
            if not texts:
                return
            last_map[key] = now
            await self._archive_strong_event(event, core, texts, str(text or texts[-1])[:160])
        except Exception as exc:
            logger.warning("[biocore] request-path strong event failed: %s", exc)

    async def _voice_context(self, event) -> str:
        if not getattr(self, "voice_transcription_enabled", True):
            return ""
        try:
            provider = await self.context.get_using_stt_provider_async(
                getattr(event, "unified_msg_origin", "") or "")
            if provider is None:
                return ""
            texts = []
            for m in event.get_messages() or []:
                if not isinstance(m, Record):
                    continue
                ref = str(getattr(m, "url", "") or getattr(m, "file", "") or getattr(m, "path", "") or "").strip()
                if not ref:
                    continue
                try:
                    txt = await provider.get_text(ref)
                    if str(txt or "").strip():
                        texts.append(str(txt).strip()[:300])
                except Exception as exc:
                    logger.warning("[biocore] voice transcribe failed: %s", exc)
            return "；".join(texts)[:600]
        except Exception as exc:
            logger.warning("[biocore] voice context failed: %s", exc)
            return ""

    async def _image_context(self, event) -> str:
        refs = self._image_refs(event)
        if not refs:
            return ""
        if not self._llm_allowed("image_caption"):
            return ""
        # Local llama-server is optional. A general AstrBot vision provider
        # must work without image_llama_* / image_service_port.
        _local_vlm = bool(self.image_llama_server and self.image_llama_model
                          and int(self.image_service_port or 0) > 0)
        if _local_vlm:
            if not await self._ensure_image_service():
                logger.warning("[biocore] local VLM unavailable; falling back to configured vision provider")
        self._image_last_used = time.time()
        cache = self._load_image_cache()
        missing = [r for r in refs if _sha256(r) not in cache]
        if missing:
            try:
                cfg = self.context.get_config()
                provider_settings = cfg.get("provider_settings", {}) if isinstance(cfg, dict) else {}
                prompt = interpretation.image_caption_prompt(
                    provider_settings.get("image_caption_prompt"))
                # Image caption always uses the vision provider, never a text LLM.
                provider = self._vision_provider_for(event)
                if provider is not None:
                    for ref in missing[:3]:
                        try:
                            _ctmo = max(2000, min(20000, int(
                                getattr(self, "image_caption_timeout_ms", 8000) or 8000))) / 1000.0
                            resp = await asyncio.wait_for(
                                provider.text_chat(prompt=prompt, image_urls=[ref]),
                                timeout=_ctmo)
                            caption = interpretation.parse_image_caption(
                                str(getattr(resp, "completion_text", "") or ""))
                        except asyncio.TimeoutError:
                            self._image_caption_timeouts = int(
                                getattr(self, "_image_caption_timeouts", 0) or 0) + 1
                            logger.warning("[biocore] image caption timeout (%sms)", _ctmo * 1000)
                            caption = ""
                        except Exception as exc:
                            logger.warning("[biocore] image caption failed: %s", exc)
                            caption = ""
                        if caption:
                            cache[_sha256(ref)] = {"ref": ref, "caption": caption, "ts": time.time()}
                    self._save_image_cache(cache)
            except Exception as exc:
                logger.warning("[biocore] image provider failed: %s", exc)
        lines = []
        for ref in refs[:3]:
            item = cache.get(_sha256(ref))
            if item and item.get("caption"):
                lines.append(str(item["caption"]))
        self._image_last_used = time.time()
        if not lines:
            return ""
        return "\n".join(lines)

    def _astrbot_tts_default(self):
        try:
            provs = self.context.get_all_tts_providers()
        except Exception:
            provs = []
        p = provs[0] if provs else None
        if p:
            cfg = getattr(p, "provider_config", {}) or {}
            base = str(cfg.get("api_base") or cfg.get("tts_api_base") or "").strip()
            model = str(cfg.get("model") or cfg.get("tts_model") or getattr(p, "model", "") or "").strip()
            key = str(cfg.get("api_key") or cfg.get("tts_api_key") or "").strip()
            if base:
                return {"provider_id": str(cfg.get("id") or ""), "base_url": base,
                        "model": model, "has_key": bool(key), "_key": key}
        for item in self._config_providers():
            if str(item.get("provider_type") or "") != "tts" or item.get("enable") is False:
                continue
            base = str(item.get("api_base") or item.get("tts_api_base") or "").strip()
            model = str(item.get("model") or item.get("tts_model") or "").strip()
            key = str(item.get("api_key") or item.get("tts_api_key") or "").strip()
            if base:
                return {"provider_id": str(item.get("id") or ""), "base_url": base,
                        "model": model, "has_key": bool(key), "_key": key}
        return None

    def _astrbot_image_default(self):
        try:
            provs = self.context.get_all_providers()
        except Exception:
            provs = []
        sources = {str(x.get("id") or ""): x for x in self._config_provider_sources()}
        candidates = []
        for p in provs:
            cfg = getattr(p, "provider_config", {}) or {}
            pid = str(cfg.get("id") or "").lower()
            model = str(getattr(p, "get_model", lambda: "")() or cfg.get("model") or "").lower()
            if "img" in pid or "image" in pid or "img" in model or "image" in model:
                candidates.append((p, cfg))
        if candidates:
            p, cfg = candidates[0]
            src = sources.get(str(cfg.get("provider_source_id") or ""), {})
            base = str(cfg.get("api_base") or src.get("api_base") or "").strip()
            model = str(getattr(p, "get_model", lambda: "")() or cfg.get("model") or "").strip()
            raw = src.get("key") or cfg.get("key") or ""
            if isinstance(raw, list):
                raw = raw[0] if raw else ""
            key = str(raw or "").strip()
            if base:
                return {"provider_id": str(cfg.get("id") or ""), "base_url": base,
                        "model": model, "has_key": bool(key), "_key": key}
        for item in self._config_providers():
            pid = str(item.get("id") or "").lower()
            if item.get("enable") is False or ("img" not in pid and "image" not in pid):
                continue
            src = sources.get(str(item.get("provider_source_id") or ""), {})
            base = str(item.get("api_base") or src.get("api_base") or "").strip()
            model = str(item.get("model") or item.get("id") or "").strip()
            raw = src.get("key") or item.get("key") or ""
            if isinstance(raw, list):
                raw = raw[0] if raw else ""
            key = str(raw or "").strip()
            if base:
                return {"provider_id": str(item.get("id") or ""), "base_url": base,
                        "model": model, "has_key": bool(key), "_key": key}
        return None

    def _astrbot_llm_default(self):
        try:
            provs = self.context.get_all_providers()
        except Exception:
            provs = []
        p = provs[0] if provs else None
        if p:
            cfg = getattr(p, "provider_config", {}) or {}
            base = str(cfg.get("api_base") or "").strip()
            model = str(getattr(p, "get_model", lambda: "")() or cfg.get("model") or "").strip()
            try:
                key = str(p.get_current_key() or "").strip()
            except Exception:
                key = ""
            if base:
                return {"provider_id": str(cfg.get("id") or ""), "base_url": base,
                        "model": model, "has_key": bool(key), "_key": key}
        # fall back to the AstrBot config table (+ provider source)
        sources = {str(x.get("id") or ""): x for x in self._config_provider_sources()}
        for item in self._config_providers():
            if item.get("enable") is False:
                continue
            ptype = str(item.get("provider_type") or "")
            if ptype and ptype != "chat_completion":
                continue
            src = sources.get(str(item.get("provider_source_id") or ""), {})
            base = str(item.get("api_base") or src.get("api_base") or "").strip()
            model = str(item.get("model") or item.get("id") or "").strip()
            raw_key = src.get("key") or item.get("key") or ""
            if isinstance(raw_key, list):
                raw_key = raw_key[0] if raw_key else ""
            key = str(raw_key or "").strip()
            if base:
                return {"provider_id": str(item.get("id") or ""), "base_url": base,
                        "model": model, "has_key": bool(key), "_key": key}
        return None

    def _astrbot_embedding_default(self):
        try:
            provs = self.context.get_all_embedding_providers()
        except Exception:
            provs = []
        p = provs[0] if provs else None
        if p:
            cfg = getattr(p, "provider_config", {}) or {}
            base = str(cfg.get("embedding_api_base") or "").strip()
            model = str(cfg.get("embedding_model") or getattr(p, "model", "") or "").strip()
            key = str(cfg.get("embedding_api_key") or "").strip()
            if base:
                return {"provider_id": str(cfg.get("id") or ""), "base_url": base,
                        "model": model, "has_key": bool(key), "_key": key}
        # fall back to the AstrBot config table
        for item in self._config_providers():
            if str(item.get("provider_type") or "") != "embedding":
                continue
            if item.get("enable") is False:
                continue
            base = str(item.get("embedding_api_base") or "").strip()
            model = str(item.get("embedding_model") or "").strip()
            key = str(item.get("embedding_api_key") or "").strip()
            if base:
                return {"provider_id": str(item.get("id") or ""), "base_url": base,
                        "model": model, "has_key": bool(key), "_key": key}
        return None

    def _astrbot_rerank_default(self):
        try:
            provs = getattr(getattr(self.context, "provider_manager", None),
                            "rerank_provider_insts", []) or []
        except Exception:
            provs = []
        p = provs[0] if provs else None
        if p:
            cfg = getattr(p, "provider_config", {}) or {}
            base = str(cfg.get("rerank_api_base") or "").strip()
            suffix = str(cfg.get("rerank_api_suffix") or "")
            if suffix and base and not base.endswith(suffix):
                base = base.rstrip("/") + "/" + suffix.lstrip("/")
            model = str(cfg.get("rerank_model") or getattr(p, "model", "") or "").strip()
            key = str(cfg.get("rerank_api_key") or "").strip()
            if base:
                return {"provider_id": str(cfg.get("id") or ""), "base_url": base,
                        "model": model, "has_key": bool(key), "_key": key}
        for item in self._config_providers():
            if str(item.get("provider_type") or "") != "rerank":
                continue
            if item.get("enable") is False:
                continue
            base = str(item.get("rerank_api_base") or "").strip()
            suffix = str(item.get("rerank_api_suffix") or "")
            if suffix and base and not base.endswith(suffix):
                base = base.rstrip("/") + "/" + suffix.lstrip("/")
            model = str(item.get("rerank_model") or "").strip()
            key = str(item.get("rerank_api_key") or "").strip()
            if base:
                return {"provider_id": str(item.get("id") or ""), "base_url": base,
                        "model": model, "has_key": bool(key), "_key": key}
        return None

    def _public_api_config(self):
        llm = self._astrbot_llm_default()
        emb = self._astrbot_embedding_default()
        rrk = self._astrbot_rerank_default()
        tts = self._astrbot_tts_default()
        img = self._astrbot_image_default()
        def one(kind, default):
            saved = self.api_config.get(kind) if isinstance(self.api_config.get(kind), dict) else {}
            source = saved.get("source") or ("astrbot" if default else "custom")
            base = saved.get("base_url")
            model = saved.get("model")
            if not base:
                base = (default or {}).get("base_url", "")
            if not model:
                model = (default or {}).get("model", "")
            enabled = saved.get("enabled")
            if enabled is None:
                enabled = bool(default) if kind != "llm" else True
            return {
                "source": source if source in ("astrbot", "custom") else "custom",
                "base_url": base,
                "model": model,
                "key_saved": bool(saved.get("api_key")) or bool((default or {}).get("has_key")),
                "provider_id": (default or {}).get("provider_id", ""),
                "enabled": bool(enabled),
                "voice": str(saved.get("voice") or ""),
                "size": str(saved.get("size") or ""),
                "format": str(saved.get("format") or ""),
            }
        compression = self.api_config.get("compression") if isinstance(self.api_config.get("compression"), dict) else {}
        return {
            "functions": self._functions_public(),
            "llm": one("llm", llm),
            "embedding": one("embedding", emb),
            "rerank": one("rerank", rrk),
            "tts": one("tts", tts),
            "image": one("image", img),
            "compression": {
                "enabled": bool(compression.get("enabled", False)),
                "threshold": int(compression.get("threshold", 6000) or 6000),
                "max_chars": int(compression.get("max_chars", 800) or 800),
            },
        }

    def _functions_public(self) -> dict:
        out = {}
        for _name in LLM_FUNCTIONS:
            _cfg = self._function_cfg(_name)
            out[_name] = {
                "enabled": bool(_cfg["enabled"]),
                "provider": str(_cfg["provider"]),
                "default_enabled": bool(LLM_FUNCTION_DEFAULTS[_name]),
            }
        return out

    def _llm_provider_options(self) -> list:
        out = []
        try:
            for _p in self.context.get_all_providers():
                _cfg = getattr(_p, "provider_config", {}) or {}
                _pid = str(_cfg.get("id") or getattr(_p, "provider_id", "") or "")
                if not _pid:
                    continue
                try:
                    _model = str(getattr(_p, "get_model", lambda: "")() or _cfg.get("model") or "")
                except Exception:
                    _model = str(_cfg.get("model") or "")
                _ptype = str(_cfg.get("provider_type") or getattr(_p, "provider_type", "") or "")
                out.append({"id": _pid, "model": _model, "type": _ptype})
        except Exception:
            out = []
        return out

    @staticmethod
    def _models_url(base: str) -> str:
        b = str(base or "").strip().rstrip("/")
        if b.endswith("/rerank"):
            b = b[:-7].rstrip("/")
        if not b.endswith("/v1"):
            b = b + "/v1"
        return b + "/models"

    async def _fetch_models(self, kind: str, source: str, base_url: str, api_key: str):
        if kind == "llm":
            default = self._astrbot_llm_default()
        elif kind == "embedding":
            default = self._astrbot_embedding_default()
        elif kind == "tts":
            default = self._astrbot_tts_default()
        elif kind == "image":
            default = self._astrbot_image_default()
        else:
            default = self._astrbot_rerank_default()
        if source == "astrbot" and default:
            base_url = default.get("base_url") or base_url
            api_key = default.get("_key") or api_key
        if not base_url:
            return {"status": "error", "message": "no api base"}
        url = self._models_url(base_url)
        def do_request():
            headers = {"Accept": "application/json"}
            if api_key:
                headers["Authorization"] = "Bearer " + api_key
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=20) as resp:
                return json.loads(resp.read().decode("utf-8", "replace"))
        try:
            payload = await asyncio.to_thread(do_request)
        except Exception as exc:
            return {"status": "error", "message": "%s: %s" % (type(exc).__name__, exc)}
        items = payload.get("data") if isinstance(payload, dict) else payload
        if isinstance(items, dict):
            items = items.get("models") or items.get("data") or []
        models = []
        if isinstance(items, list):
            for item in items:
                if isinstance(item, dict):
                    mid = item.get("id") or item.get("model") or item.get("name")
                else:
                    mid = item
                if mid:
                    models.append(str(mid))
        return {"status": "ok", "data": {"models": sorted(set(models))}}

    def _register_page_api(self):
        try:
            register = getattr(self.context, "register_web_api", None)
            if register:
                register("/astrbot_plugin_biocore/page/status", self.page_status, ["GET"],
                         "BioCore dashboard status")
                register("/astrbot_plugin_biocore/page/self_model", self.page_self_model,
                         ["GET", "POST"], "BioCore self model editor")
                register("/astrbot_plugin_biocore/page/toggle", self.page_toggle, ["POST"],
                         "BioCore dashboard toggle")
                register("/astrbot_plugin_biocore/page/api_config", self.page_api_config, ["POST"],
                         "BioCore API config")
                register("/astrbot_plugin_biocore/page/models", self.page_models, ["POST"],
                         "BioCore model list")
                register("/astrbot_plugin_biocore/page/kb_config", self.page_kb_config, ["POST"],
                         "BioCore knowledge base config")
                register("/astrbot_plugin_biocore/page/autonomy", self.page_autonomy, ["POST"],
                         "BioCore autonomy settings")
                register("/astrbot_plugin_biocore/page/persona_compile", self.page_persona_compile, ["POST"],
                         "BioCore one-shot persona compile")
                register("/astrbot_plugin_biocore/page/core_mode", self.page_core_mode, ["POST"],
                         "BioCore core mode switch (off/shadow/primary)")
                register("/astrbot_plugin_biocore/page/core_rollback", self.page_core_rollback, ["POST"],
                         "BioCore one-click rollback to the old engine")
                register("/astrbot_plugin_biocore/page/backup", self.page_backup, ["POST"],
                         "BioCore safe backup (POST + confirm)")
                register("/astrbot_plugin_biocore/page/download/<token>",
                         self.page_download, ["GET"], "BioCore one-time backup download")
                register("/astrbot_plugin_biocore/page/data_export",
                         self.page_data_export, ["POST"], "BioCore JSON export")
                register("/astrbot_plugin_biocore/page/data_delete_token",
                         self.page_data_delete_token, ["POST"],
                         "BioCore one-time delete confirmation token")
                register("/astrbot_plugin_biocore/page/data_delete",
                         self.page_data_delete, ["POST"], "BioCore hard delete")
                register("/astrbot_plugin_biocore/page/restore", self.page_restore, ["POST"],
                         "BioCore core restore")
                register("/astrbot_plugin_biocore/page/insight", self.page_insight, ["POST"],
                         "BioCore manual cross-event insight")
                register("/astrbot_plugin_biocore/page/consolidate", self.page_consolidate, ["POST"],
                         "BioCore memory consolidation")
                register("/astrbot_plugin_biocore/page/event_summary",
                         self.page_event_summary, ["POST"],
                         "BioCore event summary regenerate/edit")
                register("/astrbot_plugin_biocore/page/memory_point_feedback",
                         self.page_memory_point_feedback, ["POST"],
                         "BioCore memory-point feedback (important/unimportant/edit/restore)")
                register("/astrbot_plugin_biocore/page/memory/rollback/<path:session>/<entry_id>",
                         self.page_memory_rollback, ["POST"], "BioCore memory rollback")
                register("/astrbot_plugin_biocore/page/memory/delete/<path:session>/<entry_id>",
                         self.page_memory_delete, ["POST"], "BioCore memory soft delete")
                register("/astrbot_plugin_biocore/page/memory/restore/<path:session>/<entry_id>",
                         self.page_memory_restore, ["POST"], "BioCore memory restore")
                register("/astrbot_plugin_biocore/page/memory/pin/<path:session>/<entry_id>",
                         self.page_memory_pin, ["POST"], "BioCore memory pin/unpin")
        except Exception as exc:
            logger.warning("[biocore] page api register failed: %s", exc)

    def _memory_stats(self):
        sessions = 0
        entries = 0
        try:
            for f in MEMORY_DIR.glob("*.json"):
                sessions += 1
                try:
                    d = json.loads(f.read_text(encoding="utf-8"))
                    entries += len(d.get("entries") or [])
                except Exception:
                    pass
        except Exception:
            pass
        return {"sessions": sessions, "entries": entries}

    async def _kb_available(self):
        try:
            kbs = await self.context.kb_manager.list_kbs()
            return [{"kb_id": str(getattr(k, "kb_id", "")), "kb_name": str(getattr(k, "kb_name", "")),
                     "description": str(getattr(k, "description", "") or "")} for k in (kbs or [])]
        except Exception as exc:
            logger.warning("[biocore] kb list failed: %s", exc)
            return []

    # ---- P0-1/P0-2: safe backup / export / hard delete ----
    def _page_is_local_admin(self, body=None) -> bool:
        """Local request, X-BioCore-Admin header, or body admin_token.

        The host bridge apiPost accepts only (path, body), so the body token is
        the primary remote channel; the header path remains for compatibility.
        """
        try:
            from quart import request
            remote = str(request.remote_addr or "")
            if remote in ("127.0.0.1", "::1", "localhost", ""):
                return True
            token = str(getattr(self, "data_admin_token", "") or "")
            if not token:
                return False
            try:
                if request.headers.get("X-BioCore-Admin") == token:
                    return True
            except Exception:
                pass
            if isinstance(body, dict) and str(body.get("admin_token") or "") == token:
                return True
            return False
        except Exception:
            return False

    @staticmethod
    def _is_secret_name(name) -> bool:
        low = str(name or "").lower()
        return any(x in low for x in ("api_config", ".env", "secret", "credential",
                                      "token.json", "private.key", "id_rsa"))

    def _redact_secrets(self, obj):
        if isinstance(obj, dict):
            out = {}
            for k, v in obj.items():
                if any(x in str(k).lower() for x in ("api_key", "apikey", "token",
                                                     "secret", "password", "api_secret")):
                    out[k] = "***"
                else:
                    out[k] = self._redact_secrets(v)
            return out
        if isinstance(obj, list):
            return [self._redact_secrets(v) for v in obj]
        return obj

    def _safe_backup_zip(self) -> bytes:
        """Backup WITHOUT api_config/keys; JSON key fields redacted."""
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            root = PLUGIN_DIR
            for name in ("main.py", "metadata.yaml", "README.md", "UPDATE.md",
                         "_conf_schema.json", "preview.png"):
                path = root / name
                if path.is_file() and not self._is_secret_name(name):
                    z.write(path, "astrbot_plugin_biocore_standalone/" + name)
            pages = root / "pages"
            if pages.is_dir():
                for path in pages.rglob("*"):
                    if path.is_file() and "__pycache__" not in path.parts                             and not self._is_secret_name(path.name):
                        z.write(path, "astrbot_plugin_biocore_standalone/pages/" +
                                str(path.relative_to(pages)))
            for path in DATA_DIR.rglob("*"):
                if not path.is_file() or "__pycache__" in path.parts:
                    continue
                if self._is_secret_name(path.name):
                    continue
                rel = "data/" + str(path.relative_to(DATA_DIR))
                if path.suffix.lower() == ".json":
                    try:
                        data = self._redact_secrets(json.loads(path.read_text(encoding="utf-8")))
                        z.writestr(rel, json.dumps(data, ensure_ascii=False, indent=1))
                        continue
                    except Exception:
                        pass
                z.write(path, rel)
            z.writestr("BACKUP_INFO.txt",
                       "BioCore safe backup\n"
                       "api_config.json / secret / token files are EXCLUDED; JSON key "
                       "fields are redacted to ***.\n")
        return buf.getvalue()

    async def page_backup(self):
        """P0-1: POST + explicit confirm; returns a one-time download token."""
        from quart import request
        body = await request.get_json(silent=True) or {}
        if not self._page_is_local_admin(body):
            return {"status": "error", "message": "仅本地管理端可备份"}
        if not body.get("confirm"):
            return {"status": "error",
                    "message": "需要二次确认：备份含记忆/状态，但不含 API Key"}
        try:
            data = self._safe_backup_zip()
        except Exception as exc:
            return {"status": "error", "message": str(exc)[:180]}
        stamp = time.strftime("%Y%m%d_%H%M")
        filename = "biocore_safe_" + stamp + ".zip"
        token = _sha256(str(time.time()) + "|" + str(len(data)) + "|" + filename)[:24]
        store = getattr(self, "_download_tokens", {}) or {}
        store[token] = (data, filename, time.time())
        self._download_tokens = dict(list(store.items())[-5:])
        return {"status": "ok", "data": {
            "token": token, "filename": filename, "size": len(data),
            "download_url": "/astrbot_plugin_biocore/page/download/" + token}}

    async def page_download(self, token: str):
        try:
            from quart import Response
        except Exception:
            Response = None
        item = (getattr(self, "_download_tokens", {}) or {}).pop(token, None)
        if not item:
            return {"status": "error", "message": "token invalid or already used"}
        data, filename, ts = item
        if time.time() - float(ts or 0) > 300:
            return {"status": "error", "message": "token expired"}
        if Response is None:
            return {"status": "error", "message": "server cannot stream"}
        return Response(data, mimetype="application/zip", headers={
            "Content-Disposition": "attachment; filename=" + filename,
            "Cache-Control": "no-store"})

    def _data_export_payload(self) -> dict:
        out = {"exported_at": time.time(), "plugin": "astrbot_plugin_biocore",
               "data": {}}
        for path in DATA_DIR.rglob("*"):
            if not path.is_file() or "__pycache__" in path.parts:
                continue
            if self._is_secret_name(path.name):
                continue
            rel = str(path.relative_to(DATA_DIR))
            if path.suffix.lower() == ".json":
                try:
                    out["data"][rel] = self._redact_secrets(
                        json.loads(path.read_text(encoding="utf-8")))
                    continue
                except Exception:
                    pass
            out["data"][rel] = "<binary>"
        return out

    async def page_data_export(self):
        from quart import request
        body = await request.get_json(silent=True) or {}
        if not self._page_is_local_admin(body):
            return {"status": "error", "message": "仅本地管理端可导出"}
        if not body.get("confirm"):
            return {"status": "error", "message": "需要二次确认（导出含个人记忆）"}
        return {"status": "ok", "data": self._data_export_payload()}

    async def page_data_delete_token(self):
        """P2: one-time token for hard-delete confirmation (not a boolean)."""
        from quart import request
        try:
            body = await request.get_json(silent=True) or {}
        except Exception:
            body = {}
        if not self._page_is_local_admin(body):
            return {"status": "error", "message": "仅本地管理端可删除"}
        token = _sha256(str(time.time()) + "|" + str(id(self)))[:24]
        store = getattr(self, "_delete_tokens", {}) or {}
        store[token] = time.time()
        self._delete_tokens = dict(list(store.items())[-5:])
        return {"status": "ok", "data": {"token": token, "expires_in": 300}}

    def _delete_data_scopes(self, scopes):
        """P1-4: hard-delete the requested scopes; tombstone zip first."""
        import shutil
        scopes = scopes or ["memory", "events", "insights", "state",
                            "learning_state", "archives", "persona",
                            "self_model", "image_cache"]
        if isinstance(scopes, str):
            scopes = [scopes]
        mapping = {"memory": ("memory", "users", "sessions"),
                   "events": ("events", "event_archive"),
                   "insights": ("insights", "insight_archive"),
                   "state": ("state", "states"),
                   "learning_state": ("learning", "learning_state"),
                   "archives": ("archives",),
                   "persona": ("persona_profile.json",),
                   "self_model": ("self_model.json",),
                   "image_cache": ("image_cache.json",)}
        removed = []
        tomb_dir = DATA_DIR.parent / "tombstones"
        tomb_dir.mkdir(parents=True, exist_ok=True)
        tomb = tomb_dir / ("deleted_" + time.strftime("%Y%m%d_%H%M%S") + ".zip")
        try:
            # tombstone 脱敏：只写路径 + sha256 + 字节数，绝不写原文/二进制内容。
            entries = []
            for scope in scopes:
                for name in mapping.get(str(scope), (str(scope),)):
                    target = DATA_DIR / name
                    files = []
                    if target.is_file():
                        files = [target]
                    elif target.is_dir():
                        files = [p for p in target.rglob("*") if p.is_file()]
                    for p in files:
                        try:
                            raw = p.read_bytes()
                        except Exception:
                            continue
                        entries.append({
                            "path": "data/" + str(p.relative_to(DATA_DIR)),
                            "status": "已删除",
                            "sha256": hashlib.sha256(raw).hexdigest(),
                            "bytes": len(raw),
                        })
            with zipfile.ZipFile(tomb, "w", zipfile.ZIP_DEFLATED) as z:
                z.writestr("TOMBSTONE.json", json.dumps({
                    "redacted": True,
                    "created_ts": round(time.time(), 3),
                    "entries": entries,
                }, ensure_ascii=False, indent=1))
                z.writestr("README.txt",
                           "tombstone 已脱敏：不保留原文，只有路径/sha256/字节数，无法还原内容。")
            if not entries:
                tomb.unlink(missing_ok=True)
            for scope in scopes:
                for name in mapping.get(str(scope), (str(scope),)):
                    target = DATA_DIR / name
                    if not target.exists():
                        continue
                    if target.is_dir():
                        shutil.rmtree(target, ignore_errors=True)
                    else:
                        target.unlink(missing_ok=True)
                    removed.append(name)
            return {"status": "ok", "data": {
                "scopes": list(scopes), "removed": removed,
                "tombstone": str(tomb) if tomb.exists() else "",
                "tombstone_is_backup": False,
                "tombstone_redacted": True}}
        except Exception as exc:
            return {"status": "error", "message": str(exc)[:180],
                    "data": {"tombstone": str(tomb) if tomb.exists() else ""}}
        return {"status": "error", "message": "delete failed"}

    async def page_data_delete(self):
        from quart import request
        body = await request.get_json(silent=True) or {}
        if not self._page_is_local_admin(body):
            return {"status": "error", "message": "仅本地管理端可删除"}
        token = str(body.get("token") or "")
        store = getattr(self, "_delete_tokens", {}) or {}
        issued = store.get(token)
        if not token or issued is None:
            return {"status": "error",
                    "message": "需要一次性删除确认 token（先调用 data_delete_token）"}
        if time.time() - float(issued or 0) > 300:
            return {"status": "error", "message": "删除 token 已过期"}
        self._delete_tokens.pop(token, None)
        scopes = body.get("scopes")
        return self._delete_data_scopes(scopes)

    async def page_restore(self):
        from quart import request
        import datetime
        body = await request.get_json(silent=True) or {}
        if not self._page_is_local_admin(body):
            return {"status": "error", "message": "仅本地管理端可恢复"}
        raw_b64 = str(body.get("base64") or "")
        if not raw_b64:
            return {"status": "error", "message": "empty backup"}
        try:
            raw = base64.b64decode(raw_b64)
            z = zipfile.ZipFile(io.BytesIO(raw))
        except Exception as exc:
            return {"status": "error", "message": "invalid zip: %s" % exc}
        names = [n for n in z.namelist() if n.startswith("data/") and not n.endswith("/")]
        if not names:
            return {"status": "error", "message": "backup has no data/ entries"}
        # automatic safety backup of current data before overwrite
        try:
            backup_dir = DATA_DIR.parent / "restore_backups"
            backup_dir.mkdir(parents=True, exist_ok=True)
            stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            safety = backup_dir / ("before_restore_" + stamp + ".zip")
            with zipfile.ZipFile(safety, "w", zipfile.ZIP_DEFLATED) as bz:
                for f in DATA_DIR.rglob("*"):
                    if f.is_file() and "__pycache__" not in f.parts:
                        bz.write(f, str(f.relative_to(DATA_DIR)))
        except Exception as exc:
            logger.warning("[biocore] restore safety backup failed: %s", exc)
        count = 0
        skipped_api_config = False
        import tempfile
        _stage = Path(tempfile.mkdtemp(prefix="biocore_restore_stage_"))
        _rollback = Path(tempfile.mkdtemp(prefix="biocore_restore_rollback_"))
        staged_files = {}
        rollback_files = {}
        try:
            for name in names:
                rel = name[len("data/"):]
                if self._is_secret_name(rel.split("/")[-1]) or                         rel.lower().endswith("api_config.json"):
                    # P2: never overwrite the live API keys from a backup.
                    skipped_api_config = True
                    continue
                parts = [x for x in rel.split("/") if x not in ("", ".", "..")]
                if not parts:
                    continue
                rel_clean = "/".join(parts)
                staged = _stage.joinpath(*parts)
                staged.parent.mkdir(parents=True, exist_ok=True)
                with z.open(name) as src, open(staged, "wb") as out:
                    shutil.copyfileobj(src, out)
                staged_files[rel_clean] = staged
                dest = DATA_DIR.joinpath(*parts)
                if dest.exists():
                    snap = _rollback.joinpath(*parts)
                    snap.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(str(dest), str(snap))
                    rollback_files[rel_clean] = snap
            count, _err = self._commit_restore(staged_files, rollback_files)
            if _err:
                return {"status": "error",
                        "message": "restore failed, 已回滚: %s" % _err}
        except Exception as exc:
            logger.warning("[biocore] restore failed: %s", exc)
            return {"status": "error", "message": "restore failed, 已回滚: %s" % exc}
        finally:
            try:
                shutil.rmtree(_stage, ignore_errors=True)
                shutil.rmtree(_rollback, ignore_errors=True)
            except Exception:
                pass
        try:
            self._load_profile()
            self._load_settings()
            self._load_api_config()
            self.cores = {}
        except Exception:
            pass
        logger.info("[biocore] restored %s data files", count)
        return {"status": "ok", "data": {
            "files": count,
            "api_config_skipped": skipped_api_config,
            "message": ("已恢复 %d 个文件；已跳过 api_config（保留当前 Key）" % count)}}

    def _memory_doc_for_session(self, session_key: str) -> tuple[Path, dict]:
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in str(session_key or "default"))[:80]
        path = MEMORY_DIR / (safe + ".json")
        if path.exists():
            try:
                d = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(d, dict):
                    return path, d
            except Exception:
                pass
        return path, {"entries": []}

    def _memory_save_doc_for_session(self, path: Path, doc: dict) -> None:
        MEMORY_DIR.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")

    @staticmethod
    def _memory_entry_id(entry: dict) -> str:
        return _memory_entry_id_of(entry)

    @classmethod
    def _memory_find_entry(cls, entries, entry_id: str) -> dict | None:
        if not isinstance(entries, list):
            return None
        for entry in entries:
            if isinstance(entry, dict) and cls._memory_entry_id(entry) == entry_id:
                return entry
        return None

    async def page_memory_rollback(self, session: str, entry_id: str):
        """Rollback one memory entry to its previous version (dashboard API)."""
        try:
            path, doc = self._memory_doc_for_session(session)
            entries = doc.get("entries") if isinstance(doc.get("entries"), list) else []
            target = self._memory_find_entry(entries, entry_id)
            if target is None:
                return {"status": "error", "message": "memory entry not found", "data": {}}
            if not memory_meta.rollback_entry(target):
                return {"status": "error", "message": "no previous version", "data": {}}
            try:
                _text = str(target.get("text", ""))
                _sens = bool(target.get("sensitive"))
                if not _sens and getattr(self, "safety_enabled", False):
                    _sens = bool(memory_meta.classify_sensitivity(_text).get("sensitive"))
                _vec = await self._embed_text_guarded(_text, _sens)
                if _vec:
                    target["vector"] = _vec
                    target["needs_reindex"] = False
                else:
                    target["needs_reindex"] = True
            except Exception:
                target["needs_reindex"] = True
            target["rollback_ts"] = time.time()
            self._memory_save_doc_for_session(path, doc)
            return {"status": "ok", "data": {"session": session, "id": entry_id, "text": target.get("text", "")[:160]}}
        except Exception as exc:
            return {"status": "error", "message": str(exc)[:180], "data": {}}

    async def page_memory_delete(self, session: str, entry_id: str):
        """Soft-delete one memory entry; keeps a tombstone for audit."""
        _bridge = getattr(self, "_core_bridge", None)
        if _bridge is not None and getattr(_bridge, "enabled", False) and str(getattr(_bridge, "mode", "off")) == "primary":
            try:
                _bridge.forget_via_core(entry_id=entry_id)
            except Exception:
                pass
        try:
            path, doc = self._memory_doc_for_session(session)
            entries = doc.get("entries") if isinstance(doc.get("entries"), list) else []
            target = self._memory_find_entry(entries, entry_id)
            if target is None:
                return {"status": "error", "message": "memory entry not found", "data": {}}
            doc["tombstones"] = (doc.get("tombstones") if isinstance(doc.get("tombstones"), list) else [])[-100:]
            doc["tombstones"].append({
                "id": entry_id, "ts": round(time.time(), 3),
                "status": "已删除",
                "sha256": _sha256(str(target.get("text", "")))[:16],
            })
            doc["entries"] = [e for e in entries if not (isinstance(e, dict) and self._memory_entry_id(e) == entry_id)]
            memory_meta.append_write_log(doc, op="DELETE", entry_id=entry_id,
                                         reason="dashboard", ts=time.time())
            # Propagate the deletion to derived summaries/events/insights.
            try:
                _event = types.SimpleNamespace(unified_msg_origin=session)
                self._propagate_memory_deletion(_event, target, doc, reason="dashboard")
            except Exception:
                pass
            self._memory_save_doc_for_session(path, doc)
            return {"status": "ok", "data": {"session": session, "id": entry_id, "deleted": True}}
        except Exception as exc:
            return {"status": "error", "message": str(exc)[:180], "data": {}}

    async def page_memory_pin(self, session: str, entry_id: str):
        """task-38: pin/unpin one memory entry (pinned rows escape the cap)."""
        from quart import request
        try:
            body = await request.get_json(silent=True) or {}
        except Exception:
            body = {}
        if not getattr(self, "memory_pin_enabled", True):
            return {"status": "error", "message": "pin 功能未开启"}
        try:
            path, doc = self._memory_doc_for_session(session)
            entries = doc.get("entries") if isinstance(doc.get("entries"), list) else []
            target = self._memory_find_entry(entries, entry_id)
            if target is None:
                return {"status": "error", "message": "memory entry not found", "data": {}}
            pinned = bool(body.get("pin", True))
            memory_meta.set_pinned(target, pinned)
            target["pin_ts"] = round(time.time(), 3)
            memory_meta.append_write_log(doc, op="PIN" if pinned else "UNPIN",
                                         entry_id=entry_id, reason="dashboard",
                                         ts=time.time())
            self._memory_save_doc_for_session(path, doc)
            return {"status": "ok", "data": {"session": session, "id": entry_id,
                                             "pin": pinned}}
        except Exception as exc:
            return {"status": "error", "message": str(exc)[:180], "data": {}}

    async def page_memory_restore(self, session: str, entry_id: str):
        """Restore a soft-deleted entry, or recreate one from a tombstone.

        Note: archive/insight redactions made at deletion time are not undone
        (deletion propagation is one-way for derived artifacts).
        """
        try:
            path, doc = self._memory_doc_for_session(session)
            entries = doc.get("entries") if isinstance(doc.get("entries"), list) else []
            target = self._memory_find_entry(entries, entry_id)
            from_tombstone = False
            if target is not None:
                if not memory_meta.restore_entry(target):
                    return {"status": "error", "message": "memory entry is not deleted",
                            "data": {}}
            else:
                tombstones = doc.get("tombstones") if isinstance(doc.get("tombstones"), list) else []
                tomb = next((item for item in tombstones if isinstance(item, dict)
                             and str(item.get("id") or "") == entry_id), None)
                if tomb is None:
                    return {"status": "error", "message": "memory entry not found", "data": {}}
                if not str(tomb.get("text") or "").strip():
                    return {"status": "error",
                            "message": "tombstone 已脱敏，无法从 tombstone 恢复原文",
                            "data": {}}
                target = {"id": entry_id,
                          "text": str(tomb.get("text") or "")[:1200],
                          "role": "user", "ts": time.time(), "hits": 1,
                          "importance": 0.5, "memory_source": "inferred",
                          "memory_confidence": 0.35, "memory_tier": "warm",
                          "last_write_op": "RESTORE",
                          "restored_from_tombstone": True}
                doc["tombstones"] = [item for item in tombstones
                                     if not (isinstance(item, dict)
                                             and str(item.get("id") or "") == entry_id)]
                entries.append(target)
                from_tombstone = True
            try:
                _text = str(target.get("text", ""))
                _sens = bool(target.get("sensitive"))
                if not _sens and getattr(self, "safety_enabled", False):
                    _sens = bool(memory_meta.classify_sensitivity(_text).get("sensitive"))
                _vec = await self._embed_text_guarded(_text, _sens)
                if _vec:
                    target["vector"] = _vec
                    target["needs_reindex"] = False
                else:
                    target["needs_reindex"] = True
            except Exception:
                target["needs_reindex"] = True
            target["restored_ts"] = time.time()
            target["last_write_op"] = "RESTORE"
            memory_meta.append_write_log(
                doc, op="RESTORE", entry_id=entry_id,
                reason=("tombstone" if from_tombstone else "soft_delete"),
                ts=time.time())
            self._memory_save_doc_for_session(path, doc)
            return {"status": "ok", "data": {"session": session, "id": entry_id,
                                            "text": str(target.get("text") or "")[:160],
                                            "restored": True,
                                            "from_tombstone": from_tombstone}}
        except Exception as exc:
            return {"status": "error", "message": str(exc)[:180], "data": {}}

    async def page_consolidate(self):
        """Force one memory consolidation pass over all local sessions."""
        results = []
        try:
            files = sorted(MEMORY_DIR.glob("*.json"))
        except Exception:
            files = []
        if getattr(self, "_consolidating", False):
            return {"status": "ok", "data": {"files": 0, "message": "already running"}}
        self._consolidating = True
        try:
            for f in files:
                key = f.stem
                ev = types.SimpleNamespace(unified_msg_origin=key)
                try:
                    core = self._core(ev)
                    await self._consolidate_memory(ev, core, force=True)
                    results.append(key)
                except Exception as exc:
                    logger.warning("[biocore] manual consolidation failed: %s", exc)
        finally:
            self._consolidating = False
            self._last_consolidation = time.time()
        return {"status": "ok", "data": {"files": len(results), "sessions": len(files)}}

    def _working_set_preview(self, key: str) -> dict:
        """Bounded working-set exposure for the dashboard/evals (no new mechanism).

        S3: also exposes the read-time TTL (G12) and how many ids are still
        fresh (touched within the TTL), so the UI never has to guess.
        """
        try:
            doc = self._load_memory(types.SimpleNamespace(unified_msg_origin=str(key or "")))
            doc = doc if isinstance(doc, dict) else {}
            ws = doc.get("working_set") if isinstance(doc.get("working_set"), list) else []
            ids = [str(x) for x in (ws or []) if str(x)][-8:]
            fresh = 0
            if ids:
                by_id = {str(e.get("id") or ""): e for e in (doc.get("entries") or [])
                         if isinstance(e, dict) and str(e.get("id") or "")}
                _now = time.time()
                for _id in ids:
                    entry = by_id.get(_id)
                    if entry is None:
                        continue
                    try:
                        anchor = max(float(entry.get("last_recall", 0) or 0),
                                     float(entry.get("last_used", 0) or 0),
                                     float(entry.get("ts", 0) or 0))
                    except Exception:
                        anchor = 0.0
                    # Legacy entries without timestamps are treated as fresh.
                    if anchor <= 0 or (_now - anchor) <= memory_meta.WORKING_SET_TTL_SECONDS:
                        fresh += 1
            return {"capacity": 8, "count": len(ids), "ids": ids,
                    "ttl_seconds": int(memory_meta.WORKING_SET_TTL_SECONDS),
                    "fresh_count": fresh}
        except Exception:
            return {"capacity": 8, "count": 0, "ids": [],
                    "ttl_seconds": int(memory_meta.WORKING_SET_TTL_SECONDS),
                    "fresh_count": 0}

    async def page_status(self):
        _personas = []
        try:
            _pm = getattr(self.context, "persona_manager", None)
            if _pm is not None:
                for _p in (await _pm.get_all_personas()):
                    _pid = str(getattr(_p, "persona_id", "") or "")
                    _pname = str(getattr(_p, "name", "") or _pid)
                    if _pid:
                        _personas.append({"id": _pid, "name": _pname})
        except Exception:
            _personas = []
        cores = []
        for key, core in list(self.cores.items())[:20]:
            cores.append({
                "key": key,
                "snapshot": core.snapshot(),
                "intent": {**core.intent(), "plan": interpretation.plan(core)},
                "working_set": self._working_set_preview(key),
            })
        if not cores:
            # The in-memory cache is empty after a restart. Load persisted
            # states so the dashboard does not silently fall back to demo data.
            try:
                files = sorted(STATE_DIR.glob("*.json"), key=lambda f: f.stat().st_mtime, reverse=True)[:20]
            except Exception:
                files = []
            for path in files:
                try:
                    state = json.loads(path.read_text(encoding="utf-8"))
                    core = BioCore(self.profile)
                    core.load_state(state)
                    cores.append({
                        "key": path.stem,
                        "snapshot": core.snapshot(),
                        "intent": {**core.intent(), "plan": interpretation.plan(core)},
                        "working_set": self._working_set_preview(path.stem),
                    })
                except Exception:
                    continue
        _data = {
            "enabled": self.enabled,
            "inject_intent": self.inject_intent,
            "proactive_reply": self.proactive_reply,
            "memory_dedup_embedding": self.memory_dedup_embedding,
            "memory_worthiness_enabled": bool(
                getattr(self, "memory_worthiness_enabled", True)),
            "hybrid_retrieval": bool(getattr(self, "hybrid_retrieval", True)),
            "safety_enabled": bool(getattr(self, "safety_enabled", False)),
            # GA-UI read-only: core bridge health (CoreBridge.health()); additive field.
            "core": (self._core_bridge.health() if getattr(self, "_core_bridge", None) is not None
                     else {"enabled": False, "mode": "off", "circuit_open": False,
                           "fail_count": 0, "last_error": "", "store": ""}),
            "llm_memory_candidates": bool(
                getattr(self, "llm_memory_candidates", True)),
            "we_memory_enabled": bool(getattr(self, "we_memory_enabled", False)),
            "bc_prompt_mode": str(getattr(self, "bc_prompt_mode", "telemetry") or "telemetry"),
            "summary_max_chars": int(getattr(self, "summary_max_chars", 0) or 0),
            "llm_only_reply_summary": bool(
                getattr(self, "llm_only_reply_summary", True)),
            "insight_auto_enabled": bool(getattr(self, "insight_auto_enabled", False)),
            "autonomy": {
                "enabled": bool(getattr(self, "proactive_autonomy", False)),
                "send": bool(getattr(self, "proactive_send", False)),
                "threshold": round(float(getattr(self, "autonomy_threshold", 0.6) or 0.6), 3),
                "max_chars": int(getattr(self, "autonomy_max_chars", 120) or 120),
                "state": {k: v for k, v in (self._proactive_autonomy or {}).items()
                          if k in ("ready", "threshold", "max_chars", "impulse",
                                   "impulse_ema", "sent", "last_sent_ts")}
                         if isinstance(getattr(self, "_proactive_autonomy", None), dict) else {},
            },
            "persona_loaded": bool(self.persona_text),
            "persona_id": str(getattr(self, "persona_id", "") or ""),
            "personas": _personas,
            "llm_functions": self._functions_public(),
            "llm_providers": self._llm_provider_options(),
            "profile": self.profile or dict(DEFAULT_PROFILE),
            "api_config": self._public_api_config(),
            "memory": self._memory_stats(),
            # Read-only dashboard contract (bounded): memory entries per
            # session with provenance/confidence/write-op metadata, tombstone
            # audit rows, and per-user relationship state/trajectory/maps.
            "memory_index": _memory_index_rows(MEMORY_DIR),
            "relationships": _relationship_rows(USER_DIR),
            "last_memory_meta": {
                "calibration_delta": 0.0, "calibration_sources": 0,
                **dict(getattr(self, "_last_memory_meta", {}) or {})},
            "last_memory_trace": {**DEFAULT_MEMORY_TRACE,
                                  **dict(getattr(self, "_last_memory_trace", {}) or {})},
            # Paper mechanisms also at top level for dashboard/API consumers.
            "circadian_alertness": round(float(getattr(cores[0], "circadian_alertness", 0.5)), 3) if cores else 0.5,
            "allostatic_load": round(float(getattr(cores[0], "allostatic_load", 0.0)), 3) if cores else 0.0,
            "homeostasis": dict(getattr(cores[0], "homeostasis", {}) or {}) if cores else {},
            # L-T02/L-T03..L-T12 read-only runtime surface (bounded, no prompt text)
            "last_cause_trace": [dict(x) for x in (getattr(self, "_last_cause_trace", []) or [])[:8]
                                 if isinstance(x, dict)],
            "last_strategy_hint": str(getattr(self, "_last_strategy_hint", "") or "")[:140],
            # task-36 read-only projections are appended ONLY when their opt-in
            # switches are ON (P1-2: default OFF => no new page/status fields).
            "kb_config": {"enabled": bool(getattr(self, "kb_enabled", False)),
                          "names": list(getattr(self, "kb_names", []))},
            "kb_available": await self._kb_available(),
            "astrbot_llm": {k: v for k, v in (self._astrbot_llm_default() or {}).items() if not k.startswith("_")},
            "astrbot_embedding": {k: v for k, v in (self._astrbot_embedding_default() or {}).items() if not k.startswith("_")},
            "astrbot_rerank": {k: v for k, v in (self._astrbot_rerank_default() or {}).items() if not k.startswith("_")},
            "astrbot_tts": {k: v for k, v in (self._astrbot_tts_default() or {}).items() if not k.startswith("_")},
            "astrbot_image": {k: v for k, v in (self._astrbot_image_default() or {}).items() if not k.startswith("_")},
            "cores": cores,
            "self_model": dict(self.self_model or {}),
            "events": [dict(_ev,
                            effective_merge_count=self._decayed_merge_count(_ev))
                       for _ev in self._event_archive(30, read_only=True)
                       if isinstance(_ev, dict)],
            "insights": self._insights(5),
        }
        # P1-2: default-OFF telemetry/token/consistency add no keys at all.
        if getattr(self, "llm_telemetry_enabled", False):
            _data["llm_telemetry"] = {
                "enabled": True,
                "counters": dict(((getattr(self, "_llm_telemetry", {}) or {}).get("counters") or {})),
                "recent": [dict(x) for x in (((getattr(self, "_llm_telemetry", {}) or {}).get("recent") or []))[:10]
                           if isinstance(x, dict)]}
        if getattr(self, "token_usage_enabled", False):
            _data["token_usage"] = {
                "enabled": True,
                "available": bool(((getattr(self, "_token_usage", {}) or {}).get("available", False))),
                "sessions": {str(k)[:80]: dict(v) for k, v in
                             list((((getattr(self, "_token_usage", {}) or {}).get("sessions") or {})).items())[:10]
                             if isinstance(v, dict)}}
        if (getattr(self, "reply_consistency_enabled", False)
                and cores and isinstance(getattr(cores[0], "reply_consistency", None), dict)):
            _data["reply_consistency"] = dict(cores[0].reply_consistency)
        # 1.3.1 model-layer read-only panels (each one gated by its switch).
        if (getattr(self, "bc_trace_enabled", False)
                and isinstance(getattr(self, "_last_injection_trace", None), dict)):
            _data["injection_trace"] = dict(self._last_injection_trace)
            _data["parse_stats"] = dict(interpretation.PARSE_STATS)
        if (getattr(self, "think_selfcheck_trace_enabled", True)
                and isinstance(getattr(self, "_last_reverse_check", None), dict)):
            _data["reverse_check"] = dict(self._last_reverse_check)
        if (getattr(self, "think_repeat_guard_enabled", False)
                and isinstance(getattr(self, "_repeat_guard", None), dict)):
            _data["repeat_guard"] = dict(self._repeat_guard)
        if getattr(self, "sycophancy_check_enabled", True):
            _syco = None
            if cores and isinstance(getattr(cores[0], "sycophancy_check", None), dict):
                _syco = dict(cores[0].sycophancy_check)
            if _syco is not None:
                _data["sycophancy_check"] = _syco
        if (getattr(self, "path_monitor_enabled", False)
                and isinstance(getattr(self, "_path_monitor", None), dict)):
            _data["path_monitor"] = dict(self._path_monitor)
        if getattr(self, "think_reflect_enabled", False):
            _data["think_reflect"] = {
                "hint": str(getattr(self, "_reflect_hint", "") or "")[:140],
                "stats": {str(k)[:80]: dict(v) for k, v in
                          list((getattr(self, "_reflect_stats", {}) or {}).items())[:10]
                          if isinstance(v, dict)}}
        if getattr(self, "token_budget_enabled", True):
            _tb = getattr(self, "_token_budget", {}) or {}
            _data["token_budget"] = {
                "enabled": True,
                "today": dict(_tb.get("today") or {}),
                "calls": int(_tb.get("calls", 0) or 0),
                "sessions": {str(k)[:80]: dict(v) for k, v in
                             list((_tb.get("sessions") or {}).items())[:10]
                             if isinstance(v, dict)},
                "prices": {"input_per_1m": float(getattr(self, "cost_input_per_1m", 2.0) or 0.0),
                           "output_per_1m": float(getattr(self, "cost_output_per_1m", 8.0) or 0.0),
                           "cache_per_1m": float(getattr(self, "cost_cache_per_1m", 0.5) or 0.0)},
                "savings_mode": bool(getattr(self, "savings_mode", False))}
        if any(getattr(self, k, False) for k in (
                "learning_bandit_enabled", "learning_relationship_enabled",
                "learning_worthiness_enabled")):
            _data["learning_state"] = {str(k)[:80]: dict(v) for k, v in
                                         (getattr(self, "_learning", {}) or {}).items()
                                         if isinstance(v, dict)}
        if (getattr(self, "relationship_chain_enabled", False)
                or getattr(self, "gottman_enabled", False)):
            _rd = getattr(cores[0], "relationship_dynamics", None) if cores else None
            if isinstance(_rd, dict):
                _data["relationship_dynamics"] = dict(_rd)
        if (getattr(self, "big5_effect_enabled", False) and cores
                and isinstance(getattr(cores[0], "big5_effect", None), dict)):
            _data["big5_effect"] = dict(cores[0].big5_effect)
        if getattr(self, "rerank_enabled", False):
            _data["rerank_stats"] = dict(getattr(self, "_rerank_stats", {}) or {})
        # P0-3 / P1-7: security + migration notices (read-only banners).
        if not getattr(self, "safety_enabled", False):
            _data["security_notice"] = {
                "safety_enabled": False,
                "message": "safety_enabled=false：公开部署建议保持开启；私人使用可关。"
                           "当前关闭敏感掩码/跨会话隔离/低置信拒答/投毒过滤。"}
        try:
            _marker = DATA_DIR / "migration_seen.json"
            if not _marker.exists():
                self._migration_note = (
                    "1.3.0 默认变化：memory_worthiness / memory_pin / "
                    "bc_budget(浪费治理) / F1 trace 默认开启；可在插件配置逐项关闭。")
                _marker.parent.mkdir(parents=True, exist_ok=True)
                _marker.write_text(json.dumps({"seen": True, "ts": time.time()}),
                                   encoding="utf-8")
        except Exception:
            pass
        if self._migration_note:
            _data["migration_note"] = self._migration_note
        _bg = getattr(self, "_bg_llm_usage", {}) or {}
        _data["background_budget"] = {
            "day": str(_bg.get("day") or ""),
            "calls": int(_bg.get("calls", 0) or 0),
            "cost": round(float(_bg.get("cost", 0.0) or 0.0), 6),
            "daily_calls": int(getattr(self, "bg_llm_daily_calls", 200) or 200),
            "daily_cost": float(getattr(self, "bg_llm_daily_cost", 2.0) or 2.0)}
        if int(getattr(self, "_corrupt_backups", 0) or 0):
            _data["corrupt_backups"] = int(self._corrupt_backups)
        _data["env_checks"] = dict(getattr(self, "_env_checks", {}) or {})
        return {"status": "ok", "data": _data}

    async def page_self_model(self):
        from quart import request
        if request.method == "POST":
            body = await request.get_json(silent=True) or {}
            for key in ("who_am_i", "boundaries", "consistency", "narrative"):
                if key not in body:
                    continue
                val = body.get(key)
                if key in ("boundaries", "consistency"):
                    if isinstance(val, str):
                        val = [x.strip() for x in val.splitlines() if x.strip()]
                    self.self_model[key] = [str(x)[:300] for x in (val or [])[:10]]
                else:
                    self.self_model[key] = str(val or "")[:1500]
            self._save_self_model()
        return {"status": "ok", "data": {"self_model": self.self_model}}

    async def page_toggle(self):
        from quart import request
        data = await request.get_json(silent=True) or {}
        key = str(data.get("key") or "").strip()
        _fn_enabled = {("%s_enabled" % _name): _name for _name in LLM_FUNCTIONS}
        _fn_provider = {("%s_provider" % _name): _name for _name in LLM_FUNCTIONS}
        if key in _fn_enabled or key in _fn_provider:
            _name = _fn_enabled.get(key) or _fn_provider.get(key)
            _cur = dict(self.llm_functions.get(_name) or {})
            if key in _fn_enabled:
                _cur["enabled"] = bool(data.get("value"))
            else:
                _cur["provider"] = str(data.get("value") or "follow_llm").strip() or "follow_llm"
            _cur.pop("embedding_provider", None)
            _cur.pop("rerank_provider", None)
            self.llm_functions[_name] = _cur
            self.api_config["functions"] = dict(self.llm_functions)
            self._save_api_config()
            return {"status": "ok", "data": {"key": key, "value": _cur.get("enabled") if key in _fn_enabled else _cur.get("provider")}}
        if key not in ("proactive_reply", "memory_dedup_embedding", "inject_intent",
                       "hybrid_retrieval", "safety_enabled", "llm_memory_candidates",
                       "llm_only_reply_summary", "persona_id",
                       "insight_auto_enabled"):
            return {"status": "error", "message": "unknown setting"}
        if key == "persona_id":
            _val = str(data.get("value") or "").strip()
            self.persona_id = _val
            self._save_settings()
            await self._persist_plugin_config({key: _val})
            return {"status": "ok", "data": {"key": key, "value": _val}}
        if key == "llm_only_reply_summary":
            # Legacy master switch: keep it readable, but migrate all per-function
            # routes once instead of treating it as the only switch.
            self.llm_only_reply_summary = bool(data.get("value"))
            _legacy = bool(self.llm_only_reply_summary)
            for _name in LLM_FUNCTIONS:
                self.llm_functions[_name] = {
                    "enabled": (LLM_FUNCTION_DEFAULTS[_name] if _legacy else True),
                    "provider": str((self.llm_functions.get(_name) or {}).get("provider") or "follow_llm"),
                }
            self.api_config["functions"] = dict(self.llm_functions)
            self._save_api_config()
            self._save_settings()
            await self._persist_plugin_config({key: bool(self.llm_only_reply_summary)})
            return {"status": "ok", "data": {"key": key, "value": self.llm_only_reply_summary}}
        if key == "safety_enabled":
            self.safety_enabled = bool(data.get("value"))
            self.cross_session_memory = not self.safety_enabled
            self.sensitive_memory_protection = self.safety_enabled
            self._save_settings()
            await self._persist_plugin_config({key: self.safety_enabled})
            logger.info("[biocore] safety_enabled=%s", self.safety_enabled)
            return {"status": "ok", "data": {"key": key, "value": self.safety_enabled}}
        setattr(self, key, bool(data.get("value")))
        self._save_settings()
        await self._persist_plugin_config({key: bool(getattr(self, key))})
        logger.info("[biocore] setting %s=%s", key, getattr(self, key))
        return {"status": "ok", "data": {"key": key, "value": getattr(self, key)}}

    async def generate_manual_insight(self) -> dict:
        """Manual long-term insight (dashboard button), bypass threshold once.

        Never writes a deterministic fallback: when the insight LLM switch is
        off it only returns a message telling the user to enable it.
        """
        if not self._llm_allowed("insight"):
            return {"generated": False, "insight": "",
                    "message": "请先开启「长期模式洞察」LLM 开关再生成"}
        events = self._event_archive(12)
        if not events:
            return {"generated": False, "insight": "", "message": "还没有归档事件"}
        core = next(iter(self.cores.values()), None)
        if core is None:
            core = BioCore(dict(DEFAULT_PROFILE))
        key = next(iter(self.cores), "") or ""
        ev = types.SimpleNamespace(unified_msg_origin=key)
        ok = await self._generate_insight(ev, core, events[:6])
        insight = ""
        try:
            if INSIGHT_ARCHIVE_PATH.exists():
                lines = [x for x in INSIGHT_ARCHIVE_PATH.read_text(encoding="utf-8").splitlines() if x.strip()]
                if lines:
                    insight = str(json.loads(lines[-1]).get("insight") or "")
        except Exception:
            insight = ""
        if ok:
            try:
                # A manual generation also advances the auto dedupe state so
                # the background trigger does not immediately duplicate it.
                now = time.time()
                latest_ts = max([float(e.get("ts", 0) or 0) for e in events] or [0.0])
                seen = [str(e.get("id") or "") for e in events if str(e.get("id") or "")]
                self._save_insight_state({"last_run_ts": now, "last_event_ts": latest_ts,
                                          "seen_ids": seen[-100:]})
            except Exception:
                pass
        return {"generated": bool(ok), "insight": insight, "events": len(events),
                "message": "" if ok else "生成失败，请查看日志"}

    async def page_insight(self):
        """Manual '生成长期洞察' button: bypass threshold/cooldown once."""
        from quart import request
        _ = await request.get_json(silent=True) or {}
        return {"status": "ok", "data": await self.generate_manual_insight()}

    async def page_api_config(self):
        from quart import request
        body = await request.get_json(silent=True) or {}
        for kind in ("llm", "embedding", "rerank", "tts", "image"):
            incoming = body.get(kind)
            if not isinstance(incoming, dict):
                continue
            source = str(incoming.get("source") or "custom").strip()
            if source not in ("astrbot", "custom"):
                source = "custom"
            old = self.api_config.get(kind) if isinstance(self.api_config.get(kind), dict) else {}
            key = str(incoming.get("api_key") or "").strip()
            if not key:
                key = str(old.get("api_key") or "")
            entry = {
                "source": source,
                "base_url": str(incoming.get("base_url") or "").strip(),
                "api_key": key,
                "model": str(incoming.get("model") or "").strip(),
                "enabled": bool(incoming.get("enabled", True)),
            }
            for extra in ("voice", "size", "format"):
                if extra in incoming:
                    entry[extra] = str(incoming.get(extra) or "").strip()
            self.api_config[kind] = entry
        _incoming_functions = body.get("functions")
        if isinstance(_incoming_functions, dict):
            for _name in LLM_FUNCTIONS:
                _item = _incoming_functions.get(_name)
                if not isinstance(_item, dict):
                    continue
                _cur = dict(self.llm_functions.get(_name) or {})
                if "enabled" in _item:
                    _cur["enabled"] = bool(_item.get("enabled"))
                if "provider" in _item:
                    _cur["provider"] = str(_item.get("provider") or "follow_llm").strip() or "follow_llm"
                _cur.pop("embedding_provider", None)
                _cur.pop("rerank_provider", None)
                self.llm_functions[_name] = _cur
            self.api_config["functions"] = dict(self.llm_functions)
        comp = body.get("compression")
        if isinstance(comp, dict):
            self.api_config["compression"] = {
                "enabled": bool(comp.get("enabled", False)),
                "threshold": max(1000, int(comp.get("threshold", 6000) or 6000)),
                "max_chars": max(120, int(comp.get("max_chars", 800) or 800)),
            }
        self._save_api_config()
        logger.info("[biocore] api config saved")
        return {"status": "ok", "data": self._public_api_config()}

    async def page_kb_config(self):
        from quart import request
        body = await request.get_json(silent=True) or {}
        self.kb_enabled = bool(body.get("enabled", False))
        names = body.get("names") if isinstance(body.get("names"), list) else []
        self.kb_names = [str(x).strip() for x in names if str(x).strip()]
        self._save_settings()
        await self._persist_plugin_config({"kb_enabled": self.kb_enabled,
                                           "kb_names": self.kb_names})
        logger.info("[biocore] kb config enabled=%s names=%s", self.kb_enabled, self.kb_names)
        return {"status": "ok", "data": {"enabled": self.kb_enabled, "names": self.kb_names}}

    async def page_autonomy(self):
        """Autonomy settings page: validate + persist proactive_* config."""
        from quart import request
        body = await request.get_json(silent=True) or {}
        try:
            from .biocore_model import autonomy_mode as _autonomy
        except Exception:
            from biocore_model import autonomy_mode as _autonomy
        try:
            from .biocore_model import core_mode as _core_mode
        except Exception:
            from biocore_model import core_mode as _core_mode
        try:
            _core_mode.authorize(self, body)
            return await _autonomy.apply(self, body)
        except _autonomy.AutonomyError as error:
            _core_mode.http_abort(int(getattr(error, "status", 400)))

    async def page_persona_compile(self):
        """One-shot persona compile (reuses the existing _compile_profile; no logic change)."""
        from quart import request
        body = await request.get_json(silent=True) or {}
        try:
            from .biocore_model import core_mode as _core_mode
        except Exception:
            from biocore_model import core_mode as _core_mode
        try:
            _core_mode.authorize(self, body)
        except _core_mode.CoreModeError as error:
            _core_mode.http_abort(int(getattr(error, "status", 400)))
        if not self._llm_allowed("persona_compile"):
            return {"ok": False, "error": "llm_disabled", "message": "需要 LLM（跟随主 LLM）"}
        try:
            await self._compile_profile(None)
        except Exception as error:
            return {"ok": False, "error": "compile_failed", "message": type(error).__name__}
        version = str(getattr(self, "_persona_compiled_hash", "") or "")[:8]
        return {"ok": True, "compiled": True, "version": version}

    async def page_core_mode(self):
        from quart import request
        body = await request.get_json(silent=True) or {}
        try:
            from .biocore_model import core_mode as _core_mode
        except Exception:
            from biocore_model import core_mode as _core_mode
        try:
            _core_mode.authorize(self, body)
            return await _core_mode.apply(self, body.get("mode"))
        except _core_mode.CoreModeError as error:
            _core_mode.http_abort(int(getattr(error, "status", 400)))

    async def page_core_rollback(self):
        from quart import abort, request
        body = await request.get_json(silent=True) or {}
        try:
            from .biocore_model import core_mode as _core_mode
        except Exception:
            from biocore_model import core_mode as _core_mode
        try:
            _core_mode.authorize(self, body)
            return await _core_mode.rollback(self)
        except _core_mode.CoreModeError as error:
            _core_mode.http_abort(int(getattr(error, "status", 400)))

    async def page_models(self):
        from quart import request
        body = await request.get_json(silent=True) or {}
        kind = str(body.get("kind") or "embedding").strip()
        source = str(body.get("source") or "custom").strip()
        return await self._fetch_models(kind, source,
                                        str(body.get("base_url") or ""),
                                        str(body.get("api_key") or ""))

    @staticmethod
    def _ipv4_json(url: str, headers: dict, payload: dict, timeout: float = 12.0) -> dict:
        parsed = urlparse(url)
        host = parsed.hostname or ""
        if not host:
            raise ValueError("invalid url")
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")

        class _IPv4HTTPSConnection(http.client.HTTPSConnection):
            def connect(self):
                infos = socket.getaddrinfo(self.host, self.port, socket.AF_INET, socket.SOCK_STREAM)
                ip = infos[0][4][0]
                sock = socket.create_connection((ip, self.port), self.timeout)
                self.sock = self._context.wrap_socket(sock, server_hostname=self.host)

        if parsed.scheme == "https":
            conn = _IPv4HTTPSConnection(host, port, timeout=timeout,
                                         context=ssl.create_default_context())
        else:
            conn = http.client.HTTPConnection(host, port, timeout=timeout)
        try:
            conn.request("POST", path, body=body, headers=headers)
            resp = conn.getresponse()
            raw = resp.read()
            if resp.status >= 400:
                raise RuntimeError("http %s: %s" % (resp.status, raw[:300].decode("utf-8", "replace")))
            return json.loads(raw.decode("utf-8", "replace"))
        finally:
            conn.close()

    def _embedding_runtime_config(self):
        saved = self.api_config.get("embedding") if isinstance(self.api_config.get("embedding"), dict) else {}
        if saved.get("source") == "custom" and saved.get("base_url"):
            return {"base_url": saved.get("base_url"), "api_key": saved.get("api_key", ""),
                    "model": saved.get("model", "")}
        d = self._astrbot_embedding_default()
        if d and d.get("base_url"):
            return {"base_url": d.get("base_url"), "api_key": d.get("_key", ""),
                    "model": d.get("model", "")}
        if saved.get("base_url"):
            return {"base_url": saved.get("base_url"), "api_key": saved.get("api_key", ""),
                    "model": saved.get("model", "")}
        return None

    def _embed_skip_sensitive(self, sensitive) -> bool:
        """Whether a tagged-sensitive payload must be withheld from embedding.

        Privacy filtering belongs to the safety switch (default OFF), so the
        1.2.98 behaviour stays a bitwise no-op unless ``safety_enabled`` is on.
        """
        # P1-2: sensitive text is withheld from external embeddings by default.
        return bool(sensitive) and not bool(
            getattr(self, "embedding_sensitive_allowed", False))

    async def _embed_text_guarded(self, text: str, sensitive: bool = False):
        """Embedding for already-stored memory/event text (M1 privacy gate).

        When safety is on and the payload is tagged sensitive the text is NEVER
        sent to the embedding provider: the caller receives ``None`` and keeps
        the entry/text untouched (it just has no vector). Default (safety off)
        is a no-op, identical to ``_embed_text(text)``. The TypeError fallback
        keeps one-argument ``_embed_text`` overrides used by legacy evals working.
        """
        try:
            return await self._embed_text(
                text, sensitive=self._embed_skip_sensitive(sensitive))
        except TypeError:
            return await self._embed_text(text)

    async def _embedding_for(self, kind: str, text: str, sensitive: bool = False):
        """Embedding for one function; always follows the API 接入 default.

        Per-function embedding model selection was removed by user request:
        every function uses the same global embedding configuration. ``kind``
        is kept for call-site clarity and tests.
        """
        try:
            return await self._embed_text(text, sensitive=sensitive)
        except TypeError:
            # Backward-compatible test/legacy override without the sensitive kwarg.
            return await self._embed_text(text)

    async def _rerank_scores(self, kind: str, query: str, documents: list):
        """Optional global rerank scores keyed by candidate index (None = local).

        Event ranking never asks the user to pick a model: it follows the
        API 接入 / AstrBot default rerank provider and falls back to the
        deterministic local ranking when no provider is configured or the call
        fails. ``kind`` is kept for call-site clarity and tests.
        """
        try:
            _provs = getattr(getattr(self.context, "provider_manager", None),
                             "rerank_provider_insts", []) or []
        except Exception:
            _provs = []
        _target = _provs[0] if _provs else None
        if _target is None:
            return None
        if getattr(self, "safety_enabled", False):
            # P1-2: safety on => no rerank payload leaves the process.
            return None
        try:
            _call = _target.rerank(query, [str(d) for d in documents],
                                   top_n=len(documents))
            _rto = float(getattr(self, "outbound_timeout_ms", 3000)) / 1000.0
            if _SERVICES is not None:
                _results = await _SERVICES.rerank(_call, _rto)
            else:
                _results = await asyncio.wait_for(_call, timeout=_rto)
            out = {}
            for _r in (_results or []):
                try:
                    _idx = int(getattr(_r, "index", None))
                    _score = float(getattr(_r, "relevance_score", 0.0) or 0.0)
                except Exception:
                    continue
                out[_idx] = max(0.0, min(1.0, _score))
            return out or None
        except Exception as exc:
            logger.warning("[biocore] global rerank failed; fallback to local ranking: %s", exc)
            return None

    async def _embed_text(self, text: str, sensitive: bool = False):
        text = (text or "").strip()
        if not text or sensitive:
            return None
        # P1-5: direct callers often omit the sensitive flag; classify at the
        # single entry point so sensitive payloads never leave by default.
        if not bool(getattr(self, "embedding_sensitive_allowed", False)):
            try:
                if memory_meta.classify_sensitivity(text).get("sensitive"):
                    return None
            except Exception:
                pass
        conf = self._embedding_runtime_config()
        if not conf:
            return None
        model = str(conf.get("model") or "").strip()
        # M4: the cache key hashes exactly the payload that is sent (one
        # truncation constant for both), so two texts that only differ after the
        # truncation point can never share a stale vector.
        payload_text = text[:EMBED_TEXT_MAX_CHARS]
        # P1-1: cache key includes base_url + model + configured dimension.
        base = str(conf.get("base_url") or "").rstrip("/")
        if base.endswith("/embeddings"):
            base = base[:-11]
        _dim_hint = str(conf.get("dimensions") or conf.get("dim") or "")
        _sig = (base + "|" + model + "|" + _dim_hint)
        if getattr(self, "_embed_cache_sig", None) != _sig:
            EMBED_CACHE.clear()
            self._embed_cache_sig = _sig
        cache_key = (base, model, _dim_hint, _sha256(payload_text))
        _cache_on = bool(getattr(self, "embedding_cache_enabled", True))
        if _cache_on and cache_key in EMBED_CACHE:
            EMBED_CACHE.move_to_end(cache_key)
            return EMBED_CACHE[cache_key]
        url = base + "/embeddings"
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if conf.get("api_key"):
            headers["Authorization"] = "Bearer " + str(conf.get("api_key"))
        payload = {"model": model, "input": [payload_text], "encoding_format": "float"}
        try:
            # Embedding timeout is a config key (embedding_timeout_ms, default
            # 1500 ms) so a remote provider's real p95 can be accommodated;
            # a timed-out call returns None and never blocks the reply loop.
            _timeout_ms = getattr(self, "embedding_timeout_ms", EMBED_TIMEOUT_MS_DEFAULT)
            try:
                _timeout_s = max(0.1, min(15.0, float(_timeout_ms) / 1000.0))
            except Exception:
                _timeout_s = EMBED_TIMEOUT_S
            _call = asyncio.to_thread(self._ipv4_json, url, headers, payload, _timeout_s)
            if _SERVICES is not None:
                data = await _SERVICES.embed(_call, _timeout_s)
            else:
                data = await asyncio.wait_for(_call, timeout=_timeout_s)
            vec = data["data"][0]["embedding"]
            if not isinstance(vec, list) or not vec:
                return None
            # P2: dimension mismatch is REJECTED (not logged-and-used).
            try:
                _expected_dim = int(conf.get("dimensions") or conf.get("dim") or 0)
            except Exception:
                _expected_dim = 0
            if _expected_dim and len(vec) != _expected_dim:
                global EMBED_DIM_MISMATCH
                EMBED_DIM_MISMATCH += 1
                logger.warning("[biocore] embedding dimension rejected: got %d expected %d",
                               len(vec), _expected_dim)
                return None
            if _cache_on:
                EMBED_CACHE[cache_key] = vec
                EMBED_CACHE.move_to_end(cache_key)
                while len(EMBED_CACHE) > EMBED_CACHE_MAX:
                    EMBED_CACHE.popitem(last=False)
            return vec
        except Exception as exc:
            logger.warning("[biocore] embedding failed: %s", exc)
            return None

    @staticmethod
    def _cosine(a, b) -> float:
        if not a or not b:
            return 0.0
        if len(a) != len(b):
            # P1-1: dimension mismatch is an anomaly, never a silent zero.
            global EMBED_DIM_MISMATCH
            EMBED_DIM_MISMATCH += 1
            logger.warning("[biocore] embedding dimension mismatch: %d vs %d",
                           len(a), len(b))
            return 0.0
        dot = sum(x * y for x, y in zip(a, b))
        na = math.sqrt(sum(x * x for x in a))
        nb = math.sqrt(sum(y * y for y in b))
        return dot / (na * nb) if na and nb else 0.0

    def _dedupe_sentences(self, text: str) -> str:
        """C-S1 deterministic sentence dedup (char-bigram Jaccard >= 0.92).

        M5: only the deterministic fallback is implemented. The LIT/spec
        "embedding 0.90" + quote/code-block whitelist variants are NOT
        implemented and are no longer claimed in ACC/LIT.
        """
        if not getattr(self, "sentence_dedup_enabled", False):
            return text
        try:
            import re as _re
            parts = [p for p in _re.split(r"(?<=[。！？；！？;\n])", str(text or "")) if p.strip()]
            kept = []

            def _bigrams(s):
                s = "".join(_re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", s))
                return {s[i:i + 2] for i in range(max(0, len(s) - 1))} if len(s) >= 2 else {s}

            def _jac(a, b):
                if not a and not b:
                    return 1.0
                return len(a & b) / max(1, len(a | b))

            for sent in parts:
                must = bool(_re.search(r"[0-9０-９]|不|没|别|未|无", sent))
                dup = False
                if not must:
                    b = _bigrams(sent)
                    for prev in kept:
                        if _jac(b, _bigrams(prev)) >= SENTENCE_DEDUP_THRESHOLD:
                            dup = True
                            break
                if not dup:
                    kept.append(sent)
            out = "".join(kept).strip()
            return out or str(text or "")
        except Exception:
            return text

    @staticmethod
    def _usable_memory_text(text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return False
        if t.startswith("注意，你正在社交媒体"):
            return False
        if t.startswith("[BioCore]"):
            return False
        return True

    def _memory_path(self, event):
        key = str(getattr(event, "unified_msg_origin", "default") or "default")
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in key)[:80]
        MEMORY_DIR.mkdir(parents=True, exist_ok=True)
        return MEMORY_DIR / (safe + ".json")

    def _memory_module_engine(self, event):
        """Thin AstrBot adapter: per-session shadow engine (default OFF)."""
        if not getattr(self, "memory_module_enabled", False) or MemoryEngine is None:
            return None
        try:
            key = str(getattr(event, "unified_msg_origin", "default") or "default")
            engine = getattr(self, "_memory_module_engines", {}).get(key)
            if engine is None:
                base = self._memory_path(event)
                path = base.with_suffix(base.suffix + ".module.json")
                engine = MemoryEngine(path=path, affect=None, embedder=None)
                self._memory_module_engines[key] = engine
            return engine
        except Exception:
            return None

    def _load_memory(self, event):
        try:
            d = json.loads(self._memory_path(event).read_text(encoding="utf-8"))
            if isinstance(d, dict) and isinstance(d.get("entries"), list):
                d["entries"] = [e for e in d["entries"]
                                if isinstance(e, dict)
                                and self._usable_memory_text(str(e.get("text", "")))]
                try:
                    for entry in d["entries"]:
                        entry.setdefault("inhibition", 0.0)
                        entry.setdefault("suppression_count", 0)
                        entry.setdefault("memory_tier", "warm")
                        # Lazy migration: pre-provenance data is direct user/
                        # model input, not "unknown". This runs for every old
                        # entry on load, then persists on the next save.
                        if not entry.get("memory_source") and not entry.get("memory_confidence"):
                            entry["memory_source"] = "direct"
                            entry["memory_confidence"] = 0.7
                            entry["legacy_backfilled"] = True
                    if int(d.get("schema_version", 0) or 0) < MEMORY_SCHEMA_VERSION:
                        d["schema_version"] = MEMORY_SCHEMA_VERSION
                except Exception:
                    pass
                return d
        except Exception:
            try:
                _p = self._memory_path(event)
                if _p.exists():
                    _bak = _p.with_suffix(_p.suffix + ".corrupt.bak")
                    _bak.write_bytes(_p.read_bytes())
                    self._corrupt_backups = int(getattr(self, "_corrupt_backups", 0) or 0) + 1
                    logger.warning("[biocore] memory JSON corrupt; backup saved to %s", _bak)
            except Exception:
                pass
        return {"entries": []}

    def _merge_memory_doc(self, doc, latest) -> dict:
        """Merge concurrently-written entries into the consolidation doc (BUG-03)."""
        if not isinstance(doc, dict):
            return doc
        if not isinstance(latest, dict):
            return doc
        cur = doc.get("entries") if isinstance(doc.get("entries"), list) else []
        new = latest.get("entries") if isinstance(latest.get("entries"), list) else []
        known_ids = {str(x.get("id") or "") for x in cur if isinstance(x, dict)}
        known_keys = {(str(x.get("text") or ""), round(float(x.get("ts", 0) or 0), 3))
                      for x in cur if isinstance(x, dict)}
        for entry in new:
            if not isinstance(entry, dict):
                continue
            eid = str(entry.get("id") or "")
            key = (str(entry.get("text") or ""), round(float(entry.get("ts", 0) or 0), 3))
            if (eid and eid in known_ids) or (not eid and key in known_keys):
                continue
            cur.append(entry)
            if eid:
                known_ids.add(eid)
            known_keys.add(key)
        doc["entries"] = cur
        if isinstance(latest.get("write_log"), list):
            logs = doc.get("write_log") if isinstance(doc.get("write_log"), list) else []
            for row in latest["write_log"]:
                if isinstance(row, dict) and row not in logs:
                    logs.append(row)
            doc["write_log"] = logs[-200:]
        if isinstance(latest.get("working_set"), list):
            ws = doc.get("working_set") if isinstance(doc.get("working_set"), list) else []
            for item in latest["working_set"]:
                if str(item) and str(item) not in {str(x) for x in ws}:
                    ws.append(str(item))
            doc["working_set"] = ws[-32:]
        return doc

    def _save_memory(self, event, doc):
        try:
            if isinstance(doc, dict):
                doc["schema_version"] = MEMORY_SCHEMA_VERSION
            self._memory_path(event).write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")
        except Exception as exc:
            logger.warning("[biocore] memory save failed: %s", exc)

    def _memory_bio(self, core):
        if core is None:
            return None
        return core

    def _memory_importance(self, core, role: str) -> float:
        if core is None:
            return 0.5
        salience = 0.25 + 0.35 * float(getattr(core, "a", 0.5)) + 0.25 * abs(float(getattr(core, "v", 0.0)))
        salience += 0.15 * (1.0 - float(getattr(core, "trust", 0.5)))
        if role == "assistant":
            salience *= 0.9
        return max(0.15, min(1.0, salience))

    @staticmethod
    def _restabilize_if_expired(entry: dict, now=None) -> bool:
        """Nader reconsolidation: an expired labile window restabilizes.

        Recall is the moment the memory is re-touched, so it is also the
        moment a stale destabilized window must be closed and timestamped.
        """
        try:
            if not isinstance(entry, dict):
                return False
            if entry.get("reconsolidation_state") != "destabilized":
                return False
            _now = time.time() if now is None else float(now)
            if float(entry.get("destabilized_until", 0) or 0) >= _now:
                return False
            entry["reconsolidation_state"] = "restabilized"
            entry["restabilized_ts"] = _now
            return True
        except Exception:
            return False


    def _memory_score_parts(self, core, entry: dict, cosine: float, *,
                            query_text: str = "", hybrid: bool = False,
                            sensitive_protect: bool = False) -> dict:
        """Return the deterministic score plus its bounded component factors.

        L-T02/C-T01: storing the factors here lets the runtime expose an
        auditable retrieval-contribution trace without the LLM ever generating
        one and without changing the ranking math.
        """
        # G8: slow 30-day decay with a 0.15 floor, computed on read only.
        importance = memory_meta.effective_importance(entry)
        age = max(0.0, time.time() - float(entry.get("ts", 0) or 0))
        age_days = age / 86400.0
        _retention_model = getattr(core, "retention_model", "power_law") if core is not None else "power_law"
        # Task-20 P0-3: power law / multi-scale retention (both kept; single=legacy).
        if _retention_model in ("power_law", "multi_scale"):
            recency = memory_meta.retention_weight(age_days, _retention_model)
        else:
            recency = 1.0 / math.pow(1.0 + max(0.0, age_days) * 0.35, 0.55)
        try:
            recall_count = int(entry.get("recall_count", 0) or 0)
        except Exception:
            recall_count = 0
        # G7: co-recall counts are read through a 30-day half-life decay so
        # an old association cannot stay permanently boosted.
        assoc = memory_meta.decayed_assoc(entry)
        try:
            due = 1.15 if 0 < float(entry.get("next_review_ts", 0) or 0) <= time.time() else 1.0
        except Exception:
            due = 1.0
        try:
            stability = max(0.2, float(entry.get("stability_days", 1.0) or 1.0))
        except Exception:
            stability = 1.0
        retention = math.exp(-age_days / stability)
        try:
            _d = ACT_R_DECAY
            _b = math.log(max(1e-9, (age_days + 0.05) ** (-_d)))
            base = 1.0 / (1.0 + math.exp(-(_b + 1.0)))
        except Exception:
            base = 0.5
        try:
            # G9: read-time decay so an old self-model match cannot stay maxed.
            schema = memory_meta.effective_schema_congruence(entry)
        except Exception:
            schema = 0.0
        inhibition = memory_meta.retrieval_inhibition(entry)
        regulation = str(getattr(core, "regulation", "none") or "none") if core is not None else "none"
        regulation_mod = memory_meta.regulation_memory_modifier(entry, regulation)
        lexical_mod = 1.0
        if hybrid and query_text:
            try:
                entry_text = str(entry.get("text") or "")
                variants = memory_meta.expand_query(query_text)
                lexical = max(memory_meta.lexical_overlap(variant, entry_text)
                              for variant in variants) if variants else 0.0
                lexical_mod = 1.0 + 0.12 * lexical
            except Exception:
                lexical_mod = 1.0
        sensitive_mod = 1.0
        if sensitive_protect:
            sensitive_mod = memory_meta.sensitivity_weight(entry)
        source_weight = memory_meta.retrieval_weight(entry)
        score = (cosine * (0.40 + 0.60 * importance) * recency
                 * (0.65 + 0.35 * retention)
                 * (0.85 + 0.15 * base)
                 * (1.0 + 0.10 * math.log1p(max(0, recall_count)))
                 * due
                 * (1.0 + 0.05 * math.log1p(max(0, assoc)))
                 * source_weight
                 * (1.0 + 0.10 * schema)
                 * (1.0 - 0.15 * inhibition)
                 * regulation_mod
                 * lexical_mod
                 * sensitive_mod)
        # C-S2: retrieval salience 0.9-1.1 x mask (Seeley 2007 inspired; not attention).
        _sal_factor = 1.0
        if getattr(self, "salience_boost_enabled", False):
            try:
                _c = max(0.0, min(1.0, float(cosine)))
                if _c > 0.0:
                    _sal_factor = 0.90 + 0.20 * _c
                    score *= _sal_factor
            except Exception:
                _sal_factor = 1.0
        # Batch4 L18: Anderson & Reder 1999 (10.1037/0096-3445.128.2.186)
        # fan penalty S=S-ln(fan): score *= 1/(1+g*ln(1+assoc+links)), floor.
        if getattr(self, "fan_penalty_enabled", False):
            try:
                _links = entry.get("links") if isinstance(entry.get("links"), list) else []
                try:
                    _raw_assoc = sum(int(v) for v in (entry.get("assoc") or {}).values())
                except Exception:
                    _raw_assoc = 0
                _fan = min(int(getattr(self, "fan_cap", 32) or 32), _raw_assoc + len(_links))
                _pen = max(float(getattr(self, "fan_floor", 0.70)),
                           1.0 / (1.0 + float(getattr(self, "fan_gain", 0.10)) * math.log1p(max(0, _fan))))
                score *= _pen
            except Exception:
                pass
        return {
            "score": float(score),
            "salience": round(_sal_factor, 4),
            "cosine": round(float(cosine), 6),
            "importance": round(importance, 4),
            "recency": round(recency, 4),
            "retention": round(0.65 + 0.35 * retention, 4),
            "base": round(0.85 + 0.15 * base, 4),
            "recall_boost": round(1.0 + 0.10 * math.log1p(max(0, recall_count)), 4),
            "assoc_boost": round(1.0 + 0.05 * math.log1p(max(0, assoc)), 4),
            "due": round(due, 4),
            "source_weight": round(float(source_weight), 4),
            "schema": round(schema, 4),
            "inhibition": round(float(inhibition), 4),
            "regulation": round(float(regulation_mod), 4),
            "lexical": round(float(lexical_mod), 4),
            "sensitive": round(float(sensitive_mod), 4),
        }

    def _memory_trace_components(self, parts: dict) -> dict:
        """Read-only ranking factors for the retrieval trace (M6).

        ``salience`` is exposed only when C-S2 is enabled, so the default-off
        trace stays byte-identical to 1.2.98; the factor itself is always 1.0
        when the switch is off.
        """
        keys = ("recency", "retention", "schema", "inhibition", "regulation",
                "lexical", "sensitive", "source_weight")
        out = {k: parts[k] for k in keys if k in parts}
        if getattr(self, "salience_boost_enabled", False) and "salience" in parts:
            out["salience"] = parts["salience"]
        return out

    def _memory_score(self, core, entry: dict, cosine: float, *,
                      query_text: str = "", hybrid: bool = False,
                      sensitive_protect: bool = False) -> float:
        parts = self._memory_score_parts(
            core, entry, cosine, query_text=query_text,
            hybrid=hybrid, sensitive_protect=sensitive_protect)
        score = float(parts.get("score", 0.0))
        try:
            trace = getattr(core, "_last_memory_trace", None) if core is not None else None
            if isinstance(trace, dict):
                eid = str(entry.get("id") or "")
                if eid and eid in [str(x) for x in (trace.get("entry_ids") or [])]:
                    valence = max(-1.0, min(1.0, float(trace.get("valence", 0.0) or 0.0)))
                    score *= 1.0 + 0.04 * valence
        except Exception:
            pass
        return max(0.0, score)

    def _attention_gate_admit(self, score: float, entry_id: str = "") -> bool:
        """L17 hard/probabilistic gate (Anderson et al. 2004, 10.1037/0033-295X.111.4.1036)."""
        try:
            _a = math.log(max(1e-9, float(score)))
            _tau = math.log(RETRIEVAL_THRESHOLD) + float(getattr(self, "attention_gate_shift", 0.0) or 0.0)
            _s = max(1e-6, float(getattr(self, "attention_gate_s", 0.30) or 0.30))
            _p = 1.0 / (1.0 + math.exp(-((_a - _tau) / _s)))
            if str(getattr(self, "attention_gate_mode", "hard")) == "probabilistic":
                _seed = int(getattr(self, "attention_seed", 0) or 0)
                if _seed > 0:
                    _h = 0
                    for _ch in str(entry_id):
                        _h = (_h * 131 + ord(_ch)) % 2147483647
                    _rng = __import__("random").Random(_seed * 1000003 + _h)
                else:
                    _rng = __import__("random").Random()
                return float(_rng.random()) < _p
            return _p >= 0.5
        except Exception:
            return float(score) >= RETRIEVAL_THRESHOLD

    def _working_set_capacity(self, core) -> int:
        """Batch4 L19: Cowan 2001 capacity (default 8 legacy; flag -> cowan)."""
        if getattr(self, "cowan_capacity_enabled", False):
            return max(3, min(6, int(getattr(self, "cowan_capacity", 4) or 4)))
        return 8  # task-51: working-set capacity stays legacy 8; top-k=3 separately

    def _memory_top_k(self, core) -> int:
        """task-51: default recall top-k = 3 (not only in savings mode).

        Attention/stress still modulates downward (2..3); cowan-style capacity
        remains an engineering proxy (Ma 2014), never an absolute "4".
        """
        k = 3
        if core is not None:
            if float(getattr(core, "stress", 0.0)) > 0.65:
                k -= 1
            if float(getattr(core, "energy", 1.0)) < 0.35:
                k -= 1
            if float(getattr(core, "attention", 0.5)) < 0.3:
                k -= 1
        k = max(2, min(3, k))
        if getattr(self, "attention_topk_cap_enabled", False):
            k = min(k, int(getattr(self, "attention_topk_cap", 4) or 4))
        return k

    def _memory_thresholds(self, core):
        compression = self.api_config.get("compression") if isinstance(self.api_config.get("compression"), dict) else {}
        threshold = max(1000, int(compression.get("threshold", 6000) or 6000))
        limit = max(120, int(compression.get("max_chars", 800) or 800))
        if core is not None:
            stress = float(getattr(core, "stress", 0.0))
            threshold = int(threshold * (1.0 + 0.5 * stress))
            limit = int(limit * (1.0 + 0.2 * stress))
        return bool(compression.get("enabled")), threshold, limit

    @staticmethod
    def _select_overflow_archive(entries, room, importance_max=0.5):
        """task-38: pick low-importance unpinned rows for deterministic archive."""
        rows = [e for e in (entries or []) if isinstance(e, dict)]
        rows.sort(key=lambda e: float(e.get("ts", 0) or 0))
        try:
            keep_n = max(0, int(room or 0))
        except Exception:
            keep_n = 80
        keep = rows[-keep_n:] if keep_n else []
        overflow = []
        for row in rows:
            if row in keep:
                continue
            try:
                importance = float(row.get("importance", 0.5) or 0.5)
            except Exception:
                importance = 0.5
            if importance < float(importance_max) and not memory_meta.is_pinned(row):
                overflow.append(row)
            else:
                keep.append(row)
        keep.sort(key=lambda e: float(e.get("ts", 0) or 0))
        return keep, overflow

    def _calibration_step(self, error, samples=1) -> float:
        """task-38: adaptive calibration weight (default OFF => fixed 0.05)."""
        if getattr(self, "calibration_adaptive_enabled", False):
            return memory_meta.calibration_adaptive_delta(error, samples)
        return 0.05

    def _trim_memory(self, doc, core=None):
        entries = doc.get("entries")
        if not isinstance(entries, list):
            entries = []
            doc["entries"] = entries
        if not entries:
            return
        enabled, threshold, summary_limit = self._memory_thresholds(core)
        _pinned, _rest = memory_meta.split_pinned(entries)
        if not enabled:
            # task-38: pinned facts escape the 80-entry cap (no pin => legacy).
            if getattr(self, "memory_overflow_compact_enabled", False) and not _pinned:
                _keep, _overflow = self._select_overflow_archive(_rest, 80)
                if _overflow:
                    _archive = doc.get("overflow_archive")
                    _archive = _archive if isinstance(_archive, list) else []
                    doc["overflow_archive"] = (_archive + _overflow)[-100:]
                    entries[:] = sorted(_keep, key=lambda e: float(e.get("ts", 0) or 0))
                    return
            if _pinned:
                _room = max(0, 80 - len(_pinned))
                _tail = _rest[-_room:] if _room > 0 else []
                entries[:] = sorted(_pinned + _tail,
                                    key=lambda e: float(e.get("ts", 0) or 0))
            else:
                entries[:] = entries[-80:]
            return
        # Keep summarized originals for provenance; only trim active entries.
        # Pinned facts are always retained regardless of the active cap.
        _archived = [e for e in entries if e.get("summarized")]
        _active = [e for e in _rest if not e.get("summarized")]
        _active = _active[-200:]
        entries[:] = sorted(_archived + _pinned + _active,
                            key=lambda e: float(e.get("ts", 0) or 0))

    def _schedule_consolidation(self, event, core=None):
        enabled, threshold, _ = self._memory_thresholds(core)
        if not enabled:
            return
        try:
            doc = self._load_memory(event)
            total = sum(len(str(e.get("text", ""))) for e in (doc.get("entries") or []))
            if total <= threshold:
                return
        except Exception:
            return
        if getattr(self, "_consolidating", False):
            return
        if time.time() - float(getattr(self, "_last_consolidation", 0.0)) < 300:
            return
        self._last_consolidation = time.time()
        self._consolidating = True
        asyncio.create_task(self._consolidate_memory(event, core))

    async def _consolidate_memory(self, event, core=None, force=False):
        try:
            doc = self._load_memory(event)
            entries = doc.get("entries")
            if not isinstance(entries, list) or len(entries) < 2:
                return
            enabled, threshold, _ = self._memory_thresholds(core)
            if not enabled and not force:
                return
            total = sum(len(str(e.get("text", ""))) for e in entries)
            if total <= threshold and not force:
                return
            _delay_s = int(getattr(self, "event_summary_delay_hours", 6) or 0) * 3600
            try:
                _last_summary = float(doc.get("last_event_summary_ts", 0) or 0)
            except Exception:
                _last_summary = 0.0
            if not force and _delay_s > 0 and (_last_summary <= 0 or time.time() - _last_summary < _delay_s):
                if _last_summary <= 0:
                    doc["last_event_summary_ts"] = time.time()
                    self._save_memory(event, doc)
                return
            doc["last_event_summary_ts"] = time.time()
            _summary_use_llm = self._llm_allowed("memory_summary")
            provider = await self._provider_for("memory_summary", event) if _summary_use_llm else None
            now = time.time()
            _segments = self._segment_event_texts(entries)
            if not _segments:
                _segments = [[str(e.get("text", "")).strip() for e in entries if str(e.get("text", "")).strip()]]
            _attachments = []
            for _e in entries:
                try:
                    _attachments.extend(_e.get("attachments") or [])
                except Exception:
                    pass
            used = set()
            groups = []
            for i, e in enumerate(entries):
                if i in used or e.get("role") == "summary":
                    continue
                group = [i]
                used.add(i)
                for j in range(i + 1, len(entries)):
                    if j in used or entries[j].get("role") == "summary":
                        continue
                    if self._cosine(e.get("vector") or [], entries[j].get("vector") or []) >= 0.86:
                        group.append(j)
                        used.add(j)
                if len(group) >= 2:
                    # BUG-06: summarize in batches, never drop entries beyond 8.
                    for _off in range(0, len(group), 8):
                        _chunk = group[_off:_off + 8]
                        if len(_chunk) >= 2:
                            groups.append(_chunk)
                if len(groups) >= 9:
                    break
            if not groups:
                if time.time() - float(getattr(self, "_last_event_archive", 0.0)) > 300:
                    self._last_event_archive = time.time()
                    await self._archive_ranked_events(event, core, entries)
                    await self._maybe_archive_insight(event, core, "compression")
                return
            changed = False
            for group in groups:
                _raw_texts = [self._mask_if_safety(str(entries[i].get("text", "")).strip()) for i in group
                              if str(entries[i].get("text", "")).strip()]
                # Dedupe near-identical memories before spending summary tokens;
                # grouping above already uses embedding cosine (>=0.86).
                texts = memory_meta.dedupe_texts(_raw_texts, threshold=0.88, limit=0)
                if len(texts) < 2:
                    continue
                payload = {"summary": "", "candidates": []}
                if _summary_use_llm and provider is not None:
                    prompt = interpretation.memory_summary_prompt(texts)
                    try:
                        resp = await self._bg_llm_direct(
                            "memory_summary", provider, prompt,
                            timeout_ms=getattr(self, "summary_llm_timeout_ms", 8000))
                        payload = interpretation.parse_memory_summary_payload(
                            str(getattr(resp, "completion_text", "") or ""),
                            getattr(self, "summary_max_chars", 0))
                    except Exception as exc:
                        logger.warning("[biocore] memory summary failed: %s", exc)
                        self._record_llm_telemetry("memory_summary", "error", str(exc))
                else:
                    # Deterministic extractive summary from embedding-grouped and
                    # deduped representatives; no LLM involved.
                    payload["summary"] = "；".join(texts[:5])
                summary = self._mask_if_safety(self._summary_cap(str(payload.get("summary") or "")))
                candidates = payload.get("candidates") or []
                if not getattr(self, "llm_memory_candidates", True):
                    candidates = []
                if not summary:
                    continue
                # M1: a summary of tagged-sensitive memories is withheld from
                # the provider when safety is on (default off => unchanged).
                _summary_sens = memory_meta.classify_sensitivity(summary)
                _group_sensitive = any(bool(entries[i].get("sensitive")) for i in group)
                vec = await self._embed_text_guarded(
                    summary, _group_sensitive or bool(_summary_sens.get("sensitive")))
                if not vec:
                    continue
                importance = max(float(entries[i].get("importance", 0.5) or 0.5) for i in group)
                _sum_id = "sum_" + str(int(now)) + "_" + str(len(entries))
                for i in sorted(group, reverse=True):
                    _old = entries[i]
                    _old["summarized"] = True
                    _old["summary_id"] = _sum_id
                    _old["summarized_ts"] = now
                _src_prov = []
                for i in group:
                    _p = entries[i].get("provenance") if isinstance(entries[i], dict) else None
                    if isinstance(_p, dict):
                        _src_prov.append(_p)
                _summary_prov = {
                    "sender_id": "summary", "sender_name": "她",
                    "session": str(getattr(event, "unified_msg_origin", "") or ""),
                    "ts": now, "message_refs": [],
                    "sources": [{
                        "sender_id": str(_p.get("sender_id") or ""),
                        "sender_name": str(_p.get("sender_name") or ""),
                        "session": str(_p.get("session") or ""),
                        "ts": float(_p.get("ts", 0) or 0),
                        "message_refs": list(_p.get("message_refs") or [])[:6],
                    } for _p in _src_prov][-24:],
                }
                _summary_source = "inferred"
                _summary_conf = memory_meta.initial_confidence(_summary_source, importance)
                entries.append({"id": _sum_id, "text": self._summary_cap(summary), "role": "summary",
                                "scope": "session",
                                "vector": vec, "ts": now, "hits": 1,
                                "importance": importance, "last_used": now,
                                "summary_id": _sum_id, "provenance": _summary_prov,
                                "memory_source": _summary_source,
                                "memory_confidence": _summary_conf,
                                "memory_tier": "warm", "conflict": False,
                                "last_write_op": "ADD", "last_write_ts": now,
                                "write_ops": {"ADD": 1}, "schema_congruence": 0.0,
                                "self_defining": False, "inhibition": 0.0,
                                "suppression_count": 0,
                                "encoding_regulation": str(getattr(core, "regulation", "none") or "none"),
                                "encoding_emotion": str((getattr(core, "labels", {}) or {}).get("emotion") or "neutral"),
                                "encoding_emotion_secondary": self._secondary_emotion(core),
                                "sensitive": bool(_summary_sens.get("sensitive")),
                                "pii_types": list(_summary_sens.get("types") or []),
                                "sensitivity": float(_summary_sens.get("score") or 0.0)})
                memory_meta.append_write_log(doc, op="ADD", entry_id=_sum_id,
                                             reason="summary", ts=now)
                # LLM proposes candidate facts; the deterministic policy here
                # decides ADD/UPDATE/NOOP and can never DELETE. Confidence is
                # capped below direct-user confidence by memory_meta.
                _cand_applied = 0
                for _cand in (candidates or [])[:memory_meta.CANDIDATE_MAX]:
                    try:
                        _ctext = str(_cand.get("text") or "").strip()
                        if len(_ctext) < 4:
                            continue
                        _cvec = await self._embed_text(_ctext)
                        if not _cvec:
                            continue
                        _best, _best_cos = None, 0.0
                        for _ce in entries:
                            if not isinstance(_ce, dict) or _ce.get("deleted") or _ce.get("summarized"):
                                continue
                            _cos = self._cosine(_cvec, _ce.get("vector") or [])
                            if _cos > _best_cos:
                                _best, _best_cos = _ce, _cos
                        _res = memory_meta.apply_memory_candidate(
                            entries, _cand, match=_best, cosine=_best_cos,
                            vector=_cvec, now=now, provenance=_summary_prov)
                        _entry = _res.get("entry")
                        if _res.get("op") in ("ADD", "UPDATE") and isinstance(_entry, dict):
                            self._apply_memory_encoding(_entry, core, now, _ctext)
                            memory_meta.append_write_log(
                                doc, op=_res["op"], entry_id=str(_entry.get("id") or ""),
                                reason="candidate", ts=now)
                            _cand_applied += 1
                    except Exception:
                        continue
                if _cand_applied:
                    logger.info("[biocore] llm memory candidates applied=%s", _cand_applied)
                changed = True
            if changed:
                await self._archive_ranked_events(event, core, entries)
                await self._maybe_archive_insight(event, core, "compression")
                try:
                    self._merge_memory_doc(doc, self._load_memory(event))
                except Exception:
                    pass
                self._trim_memory(doc, core)
                if core is not None:
                    try:
                        core.integrate_noise("memory_summary", attention=0.004,
                                             energy=-0.002)
                    except Exception:
                        pass
                self._save_memory(event, doc)
                logger.info("[biocore] memory consolidated groups=%s entries=%s", len(groups), len(entries))
        finally:
            self._consolidating = False


    @staticmethod
    def _memory_command_line(cmd: dict) -> str:
        """Deterministic one-line data hint describing an executed memory command."""
        cmd = cmd or {}
        op = str(cmd.get("op") or "NOOP")
        target = str(cmd.get("target") or "").strip()[:40]
        if op == "PENDING":
            return "- 待确认：用户要求删除关于「%s」的记忆；用户回复“确认”后才执行。" % target
        if op == "DELETE":
            return "- 已删除关于「%s」的记忆（软删除，可恢复）。" % target
        if op == "RESTORE":
            return "- 已恢复最近删除的一条记忆。"
        if op == "ROLLBACK":
            _text = str((cmd.get("entry") or {}).get("text") or "")[:40]
            return "- 已把一条记忆回滚到上一版本：%s" % _text
        reason = str(cmd.get("reason") or "")
        if reason == "ambiguous":
            return "- 删除请求匹配到多条记忆，未执行；需要用户说得更具体。"
        if reason == "vague_target":
            return "- 删除请求缺少具体对象，未执行；需要用户说明要删除哪条记忆。"
        if reason == "no_match":
            # Silent: ordinary sentences containing delete words must not inject
            # a fake memory line into the prompt.
            return ""
        if reason == "no_restore_target":
            return "- 没有可恢复的已删除记忆。"
        if reason == "no_rollback_target":
            return "- 没有可回滚的记忆修改。"
        return ""

    def _self_schema_texts(self, core) -> list:
        """Bounded self-schema corpus for deterministic schema congruence."""
        texts = list(getattr(self, "schema_texts", []) or [])
        try:
            model = self.self_model or {}
            for key in ("who_am_i", "narrative"):
                value = str(model.get(key) or "").strip()
                if value:
                    texts.append(value)
            for key in ("boundaries", "consistency"):
                for item in (model.get(key) or []):
                    item = str(item or "").strip()
                    if item:
                        texts.append(item)
            if core is not None:
                for key in ("core_self", "narrative_self"):
                    value = str(getattr(core, key, "") or "").strip()
                    if value:
                        texts.append(value)
                for item in (getattr(core, "autobiography", []) or [])[-8:]:
                    if isinstance(item, dict):
                        value = str(item.get("title") or item.get("meaning") or "").strip()
                        if value:
                            texts.append(value)
        except Exception:
            pass
        return texts[:24]

    def _apply_memory_encoding(self, entry, core, now, text="") -> None:
        """Store deterministic encoding context: schema, regulation, affect."""
        if not isinstance(entry, dict):
            return
        try:
            schema = memory_meta.schema_congruence(
                text or str(entry.get("text") or ""), self._self_schema_texts(core))
            previous = 0.0
            try:
                previous = float(entry.get("schema_congruence", 0.0) or 0.0)
            except Exception:
                previous = 0.0
            entry["schema_congruence"] = round(max(previous, schema), 4)
            entry["self_defining"] = bool(
                memory_meta.is_self_defining(entry, entry["schema_congruence"]))
        except Exception:
            pass
        if core is not None:
            try:
                entry["encoding_regulation"] = str(getattr(core, "regulation", "none") or "none")
                entry["encoding_emotion"] = str((getattr(core, "labels", {}) or {}).get("emotion") or "neutral")
                entry["encoding_emotion_secondary"] = self._secondary_emotion(core)
                entry["encoding_valence"] = round(float(getattr(core, "v", 0.0) or 0.0), 3)
                entry["encoding_arousal"] = round(float(getattr(core, "a", 0.5) or 0.5), 3)
            except Exception:
                pass
        _body = text or str(entry.get("text") or "")
        try:
            sensitivity = memory_meta.classify_sensitivity(_body)
            entry["sensitive"] = bool(sensitivity.get("sensitive"))
            entry["pii_types"] = list(sensitivity.get("types") or [])
            entry["sensitivity"] = float(sensitivity.get("score") or 0.0)
        except Exception:
            pass
        try:
            poison = memory_meta.detect_poisoning(_body)
            entry["poison_risk"] = bool(poison.get("poison_risk"))
            entry["poison_signals"] = list(poison.get("signals") or [])
            entry["poison_score"] = float(poison.get("risk") or 0.0)
            if entry["poison_risk"]:
                try:
                    entry["memory_confidence"] = min(
                        float(entry.get("memory_confidence", 0.5) or 0.5), 0.25)
                except Exception:
                    entry["memory_confidence"] = 0.25
        except Exception:
            pass
        # Memory permission scope: user facts may be shared across the same
        # sender's sessions; assistant summaries stay session-local.
        _role = str(entry.get("role") or "user")
        entry.setdefault("scope", "session" if _role in ("assistant", "summary") else "user")
        try:
            entry["verification"] = memory_meta.verify_entry(entry)
        except Exception:
            pass
        entry.setdefault("inhibition", 0.0)
        entry.setdefault("suppression_count", 0)


    # ------------------------------------------------------------------
    # Privacy / deletion semantics
    # ------------------------------------------------------------------
    def _redact_archive_text(self, needle: str, session: str = "") -> int:
        """Redact a deleted memory text from event archives and insights.

        Best-effort, bounded and atomic per file: matching event fields and
        source_texts are replaced/dropped, insight rows are replaced. Source
        ids/message refs are left intact because they carry no raw text.
        """
        needle = str(needle or "").strip()
        if len(needle) < 4:
            return 0
        replacement = "[已删除]"
        fields = ("title", "event", "central_details", "peripheral_details",
                  "meaning_to_her", "reflection", "event_key")
        total = 0

        def _mutate_event(obj):
            nonlocal total
            hit = False
            for field in fields:
                value = obj.get(field)
                if isinstance(value, str) and needle in value:
                    obj[field] = value.replace(needle, replacement)
                    hit = True
            sources = obj.get("source_texts")
            if isinstance(sources, list):
                kept = [str(x) for x in sources if needle not in str(x)]
                if len(kept) != len(sources):
                    obj["source_texts"] = kept
                    obj["source_redacted"] = True
                    hit = True
            if hit:
                total += 1
            return hit

        try:
            self._rewrite_jsonl_atomic(EVENT_ARCHIVE_PATH, _mutate_event)
            if session:
                safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in str(session))[:80]
                self._rewrite_jsonl_atomic(EVENT_SESSION_DIR / safe / "events.jsonl",
                                           _mutate_event)
        except Exception:
            pass

        def _mutate_insight(obj):
            nonlocal total
            value = obj.get("insight")
            if isinstance(value, str) and needle in value:
                obj["insight"] = value.replace(needle, replacement)
                total += 1
                return True
            return False

        try:
            self._rewrite_jsonl_atomic(INSIGHT_ARCHIVE_PATH, _mutate_insight)
        except Exception:
            pass
        return total

    def _propagate_memory_deletion(self, event, entry, doc, reason: str = "user_delete") -> None:
        """Propagate one memory deletion to derived summaries/events/insights."""
        try:
            if not isinstance(entry, dict) or not isinstance(doc, dict):
                return
            raw_text = str(entry.get("text") or "")
            needle = raw_text.split("\n[再巩固]")[0].strip()
            if len(needle) < 4:
                return
            now = time.time()
            # 1) summaries derived from the deleted entry in the same doc.
            for summary in (doc.get("entries") or []):
                if not isinstance(summary, dict) or summary.get("role") != "summary":
                    continue
                text = str(summary.get("text") or "")
                if needle not in text:
                    continue
                summary["text"] = text.replace(needle, "[已删除]")[:1200]
                summary["source_deleted"] = True
                try:
                    summary["memory_confidence"] = min(
                        float(summary.get("memory_confidence", 0.4) or 0.4), 0.25)
                except Exception:
                    summary["memory_confidence"] = 0.25
                memory_meta.append_write_log(doc, op="REDACT",
                                             entry_id=str(summary.get("id") or ""),
                                             reason="summary_derived", ts=now)
            # 2) event archive + insights.
            session = str(getattr(event, "unified_msg_origin", "") or "")
            changed = self._redact_archive_text(needle, session)
            if changed:
                memory_meta.append_write_log(
                    doc, op="REDACT", entry_id=str(entry.get("id") or ""),
                    reason="%s:%d" % (reason, changed), ts=now)
        except Exception as exc:
            logger.warning("[biocore] deletion propagation failed: %s", exc)

    def _cross_session_memory_entries(self, event) -> list:
        """Active memories from the same sender's other sessions (opt-in).

        Requires `cross_session_memory` and a sender id whose user file has a
        bounded `sessions` list (written by `_touch_user`). Returns
        [(session_key, entry), ...] and never mutates other docs.
        """
        if not getattr(self, "cross_session_memory", False):
            return []
        try:
            sid, _name = self._speaker(event)
            if not sid:
                return []
            path = self._user_path(event)
            if not path.exists():
                return []
            user = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(user, dict):
                return []
            current = str(getattr(event, "unified_msg_origin", "") or "")
            out = []
            for key in (user.get("sessions") or [])[-20:]:
                key = str(key or "").strip()
                if not key or key == current:
                    continue
                safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in key)[:80]
                mpath = MEMORY_DIR / (safe + ".json")
                if not mpath.exists():
                    continue
                try:
                    other = json.loads(mpath.read_text(encoding="utf-8"))
                except Exception:
                    continue
                if not isinstance(other, dict):
                    continue
                for entry in (other.get("entries") or [])[-200:]:
                    if not isinstance(entry, dict):
                        continue
                    if entry.get("deleted") or entry.get("summarized"):
                        continue
                    out.append((key, entry))
            return out
        except Exception:
            return []

    def _apply_memory_trace(self, core, entries) -> dict:
        """Bounded memory-trace -> body nudge from recalled entries; trace read-only."""
        if core is None:
            return {}
        selected = [e for e in (entries or []) if isinstance(e, dict)][:8]
        if not selected:
            return {}
        total_w = 0.0
        val_sum = 0.0
        loop_count = 0
        ids = []
        for entry in selected:
            try:
                imp = max(0.05, min(1.0, float(entry.get("importance", 0.5) or 0.5)))
            except Exception:
                imp = 0.5
            try:
                val = float(entry.get("encoding_valence", entry.get("valence", 0.0)) or 0.0)
            except Exception:
                val = 0.0
            val = max(-1.0, min(1.0, val))
            val_sum += val * imp
            total_w += imp
            try:
                loop_count += max(0, int(entry.get("open_loop", 0) or 0))
            except Exception:
                pass
            eid = str(entry.get("id") or "")[:20]
            if eid:
                ids.append(eid)
        avg_val = (val_sum / total_w) if total_w > 0 else 0.0
        v_delta = max(-0.05, min(0.05, 0.05 * avg_val))
        stress_delta = max(-0.02, min(0.05, 0.005 * abs(avg_val) + 0.01 * min(3, loop_count)))
        try:
            core.apply_memory_trace(v_delta, stress_delta)
        except Exception:
            pass
        trace = {"count": len(selected), "valence": round(avg_val, 3),
                 "stress_delta": round(stress_delta, 4),
                 "entry_ids": ids[:8], "ts": round(time.time(), 3)}
        self._last_memory_trace = trace
        try:
            if interpretation is not None and hasattr(interpretation, 'leak_guard_snapshot'):
                trace['leak_guard'] = interpretation.leak_guard_snapshot()
        except Exception:
            pass

            core._last_memory_trace = trace
        except Exception:
            pass
        return trace

    async def _memory_recall(self, event, text: str, core=None, extra: str = "", vec=None, voice: str = "", user_data=None) -> str:
        self._last_memory_meta = {"count": 0, "confidence": 0.0, "source": "unknown",
                                  "abstain": False, "tiers": {}, "answer_confidence": 0.0,
                                  "gate": "none", "conflicts": 0}
        if not self.memory_dedup_embedding or not self._usable_memory_text(text):
            return ""
        _bridge = getattr(self, "_core_bridge", None)
        self._core_shadow_state = None
        if _bridge is not None and _bridge.enabled and _bridge.mode in ("shadow", "primary"):
            try:
                _start = time.time(); _rows = _bridge.recall(text, limit=3); _latency = time.time() - _start
                if _bridge.mode == "primary" and isinstance(_rows, dict) and _rows.get("ok") is True:
                    _text = _bridge.rows_to_text(_rows.get("results") or [])
                    if _text:
                        self._last_memory_meta["source"] = "core"
                        return _text
                if _bridge.mode == "shadow":
                    _ids = [str(r.get("id")) for r in ((_rows or {}).get("results") or []) if isinstance(r, dict)]
                    self._core_shadow_state = {"query": text, "core_ids": _ids, "latency_core": _latency, "start": time.time()}
            except Exception:
                pass
        doc = self._load_memory(event)
        entries = doc.get("entries")
        if not isinstance(entries, list):
            entries = []
            doc["entries"] = entries
        # Explicit memory write commands (DELETE/RESTORE/ROLLBACK) run before
        # retrieval. A staged delete only executes on an explicit confirmation
        # turn; the command text is never stored as a new memory.
        try:
            _cmd = memory_meta.handle_delete_command(doc, text, time.time())
        except Exception:
            _cmd = {"handled": False}
        if _cmd.get("handled"):
            if str(_cmd.get("op") or "") == "DELETE":
                _b = getattr(self, "_core_bridge", None)
                if _b is not None and getattr(_b, "enabled", False) and str(getattr(_b, "mode", "off")) == "primary":
                    try:
                        _b.forget_via_core(query=str(_cmd.get("query") or text or ""))
                    except Exception:
                        pass
                try:
                    self._propagate_memory_deletion(
                        event, _cmd.get("entry"), doc, reason="nl_delete")
                except Exception:
                    pass
            self._save_memory(event, doc)
            self._last_memory_meta = {"count": 0, "confidence": 0.0, "source": "unknown",
                                      "abstain": False, "tiers": {}, "answer_confidence": 0.0,
                                      "gate": "none", "conflicts": 0,
                                      "write_op": str(_cmd.get("op") or "NOOP")}
            return self._memory_command_line(_cmd)
        if vec is None:
            vec = await self._embed_text(text)
        if not vec:
            return ""
        # M1 shadow adapter (default OFF): engine recall is read-only trace.
        _mod_engine = self._memory_module_engine(event)
        if _mod_engine is not None:
            try:
                self._memory_module_last_recall = _mod_engine.recall(
                    text, budget=3, vector=vec)
            except Exception:
                self._memory_module_last_recall = None
        scored = []
        retrieval_pairs = []
        duplicate = None
        now = time.time()
        _just_restabilized = set()
        _working_set = doc.get("working_set") if isinstance(doc.get("working_set"), list) else []
        # task-38: temporal validity filter (default OFF; missing invalid_at is
        # treated as valid, so old data keeps the legacy behaviour).
        _temporal = bool(getattr(self, "temporal_validity_enabled", False))
        _mood = bool(getattr(self, "mood_congruence_enabled", False))
        _mood_factor = 1.0
        if _mood:
            try:
                _mood_factor = self._mood_multiplier(getattr(core, "v", 0.0))
            except Exception:
                _mood_factor = 1.0
        for e in entries:
            if e.get("summarized") or e.get("deleted"):
                continue
            if _temporal and not memory_meta.entry_is_valid(e, now):
                continue
            if getattr(self, "safety_enabled", False) and e.get("poison_risk"):
                continue
            if self._restabilize_if_expired(e, now):
                _just_restabilized.add(id(e))
            cosine = self._cosine(vec, e.get("vector") or [])
            score = self._memory_score(
                core, e, cosine, query_text=text,
                hybrid=bool(getattr(self, "hybrid_retrieval", True)),
                sensitive_protect=bool(getattr(self, "sensitive_memory_protection", True)))
            try:
                score *= memory_meta.working_set_boost(
                e, _working_set, ttl_seconds=memory_meta.WORKING_SET_TTL_SECONDS)
            except Exception:
                pass
            if _mood and score:
                score *= _mood_factor
            retrieval_pairs.append((e, cosine))
            if cosine >= 0.93:
                duplicate = e
            # ACT-R partial matching + retrieval threshold (named constants).
            if cosine >= PARTIAL_MATCH_THRESHOLD:
                _threshold = RETRIEVAL_THRESHOLD
                if (getattr(core, "conflict_gate_enabled", False)
                        and float(getattr(core, "conflict_ema", 0.0) or 0.0) >= 0.60):
                    _threshold += 0.05
                _admit = score >= _threshold
                if getattr(self, "attention_gate_enabled", False):
                    _admit = self._attention_gate_admit(score, str(e.get("id") or ""))
                if _admit:
                    scored.append((score, e))
        _sid, _sname = self._speaker(event)
        _source = memory_meta.source_for_input(text=text, extra=extra, voice=voice)
        # Mem0 UPDATE path: an explicit correction is an update request even
        # when embedding similarity is below the exact-duplicate threshold.
        # Only the conservative correction detector can nominate this target.
        _update_target = None
        _explicit_update = False
        if duplicate is None:
            try:
                _scored_ids = {id(_entry) for _score, _entry in scored}
                _best = None
                for _pair in retrieval_pairs:
                    _cand, _cos = _pair
                    if id(_cand) not in _scored_ids:
                        continue
                    if _cos < MEMORY_UPDATE_MATCH_THRESHOLD:
                        continue
                    if not memory_meta.detect_conflict(_cand.get("text", ""), text):
                        continue
                    if _best is None or _cos > _best[1]:
                        _best = (_cand, _cos)
                if _best is not None:
                    _update_target = _best[0]
            except Exception:
                _update_target = None
        if duplicate is None and _update_target is not None:
            duplicate = _update_target
            _explicit_update = True
        if duplicate is not None:
            _entry_age = max(0.0, (now - float(duplicate.get("ts", now) or now)) / 86400.0)
            duplicate["ts"] = now
            duplicate["last_used"] = now
            duplicate["hits"] = int(duplicate.get("hits", 0)) + 1
            if _sid:
                duplicate["sender_id"] = _sid
            if _sname:
                duplicate["sender_name"] = _sname
            if extra:
                duplicate["image_caption"] = str(extra).strip()[:1600]
            if voice:
                duplicate["voice_text"] = str(voice).strip()[:1200]
            duplicate["memory_source"] = memory_meta.merge_sources(duplicate.get("memory_source"), _source)
            duplicate["memory_confidence"] = memory_meta.update_confidence(
                duplicate.get("memory_confidence"),
                duplicate["memory_source"],
                hits=int(duplicate.get("hits", 0) or 0),
                review_count=int(duplicate.get("review_count", 0) or 0),
                age_days=_entry_age,
            )
            if not isinstance(duplicate.get("destination"), dict):
                duplicate["destination"] = memory_meta.build_destination(_sid, _sname)
            _conflict = (memory_meta.detect_conflict(duplicate.get("text", ""), text)
                         or _explicit_update)
            if _conflict:
                _old_text = str(duplicate.get("text", ""))
                memory_meta.merge_version(duplicate, _old_text)
                _new_text = str(text or "").strip()[:1200]
                if _new_text and _new_text != _old_text:
                    duplicate["text"] = _new_text
                    duplicate["vector"] = vec
                    duplicate["vec_updated_ts"] = now
                duplicate["conflict"] = True
                duplicate["conflict_resolved"] = bool(_explicit_update)
                try:
                    # G1/L12: key the sample by memory provenance so the
                    # bounded confidence consumer can match entries later.
                    self._record_calibration(
                        event,
                        memory_meta.normalize_source(duplicate.get("memory_source")),
                        duplicate.get("memory_confidence", 0.5),
                        0.0,
                    )
                except Exception:
                    pass
                if _explicit_update:
                    # The user explicitly corrected the fact: trust the newer
                    # direct statement, but keep the old version for rollback.
                    try:
                        _base_conf = float(duplicate.get("memory_confidence", 0.5) or 0.5)
                    except Exception:
                        _base_conf = 0.5
                    duplicate["memory_confidence"] = round(max(_base_conf, 0.78), 4)
                else:
                    try:
                        duplicate["memory_confidence"] = min(float(duplicate.get("memory_confidence", 0.5) or 0.5), 0.55)
                    except Exception:
                        duplicate["memory_confidence"] = 0.55
            if not duplicate.get("id"):
                duplicate["id"] = _sha256(str(duplicate.get("text", ""))[:300])[:12]
            duplicate["memory_tier"] = memory_meta.memory_tier(duplicate, now)
            _write_op = memory_meta.classify_write_op(
                duplicate, {"text": text[:1200]}, 1.0, conflict=_conflict or bool(duplicate.get("conflict"))
            )
            duplicate["last_write_op"] = _write_op
            _ops = duplicate.get("write_ops") if isinstance(duplicate.get("write_ops"), dict) else {}
            _ops[_write_op] = int(_ops.get(_write_op, 0) or 0) + 1
            duplicate["write_ops"] = _ops
            duplicate["provenance"] = self._memory_provenance(event, now)
            duplicate["last_write_ts"] = now
            self._apply_memory_encoding(duplicate, core, now, text)
            if _write_op != "NOOP":
                memory_meta.append_write_log(doc, op=_write_op, entry_id=duplicate.get("id", ""),
                                             reason="conflict" if _conflict else "duplicate", ts=now)
        else:
            _importance = self._memory_importance(core, "user")
            _new_entry = {"id": _sha256(str(text)[:300])[:12], "text": text[:1200],
                          "role": "user", "vector": vec, "ts": now, "hits": 1,
                          "sender_id": _sid, "sender_name": _sname,
                          "attachments": self._attachments_from_messages(event),
                          "image_caption": str(extra or "").strip()[:1600],
                          "voice_text": str(voice or "").strip()[:1200],
                          "provenance": self._memory_provenance(event, now),
                          "importance": _importance,
                          "memory_source": _source,
                          "memory_confidence": memory_meta.initial_confidence(_source, _importance),
                          "destination": memory_meta.build_destination(_sid, _sname),
                          "conflict": False,
                          "last_write_op": "ADD",
                          "last_write_ts": now,
                          "write_ops": {"ADD": 1},
                          "memory_tier": "hot",
                          "schema_congruence": 0.0,
                          "self_defining": False,
                          "inhibition": 0.0,
                          "suppression_count": 0,
                          "last_used": now, "next_review_ts": now + 86400, "review_count": 0}
            self._apply_memory_encoding(_new_entry, core, now, text)
            entries.append(_new_entry)
            memory_meta.append_write_log(doc, op="ADD", entry_id=_new_entry["id"],
                                         reason="new", ts=now)
            self._trim_memory(doc, core)
        # Task-15: memory write fill feeds L1 energy/social noise.
        if core is not None:
            try:
                core.integrate_noise("memory_write", energy=0.003, social=0.002)
            except Exception:
                pass
        self._save_memory(event, doc)
        try:
            _recent_ids = [str(_e.get("id") or "") for _e in entries[-3:]
                           if isinstance(_e, dict)]
            doc["working_set"] = memory_meta.update_working_set(
                doc.get("working_set") if isinstance(doc.get("working_set"), list) else [],
                _recent_ids, capacity=self._working_set_capacity(core),
                priorities={str(_e.get("id") or ""): float(_e.get("importance", 0.5) or 0.5)
                            for _e in entries
                            if isinstance(_e, dict) and str(_e.get("id") or "")})
            self._save_memory(event, doc)
        except Exception:
            pass
        self._schedule_consolidation(event, core)
        # task-37/38: recall budget cap, emotion gating and optional rerank are
        # all default OFF; with every switch off this block is the legacy path.
        _top_k = self._memory_top_k(core)
        if getattr(self, "memory_recall_budget_enabled", False):
            try:
                _top_k = min(_top_k, max(1, int(getattr(self, "recall_top_k", 3) or 3)))
            except Exception:
                pass
        if (getattr(self, "rumination_effect_enabled", False) and core is not None
                and float(getattr(core, "rumination_ema", 0.0) or 0.0) >= 0.60):
            _top_k = max(1, _top_k - 1)
        if getattr(self, "emotion_gating_enabled", False) and core is not None:
            try:
                _gate = self._emotion_gate_params(
                    getattr(core, "stress", 0.0), getattr(core, "v", 0.0))
                if _gate["active"]:
                    _top_k = min(_top_k, int(_gate["top_k_cap"] or 2))
                    _floor = RETRIEVAL_THRESHOLD + float(_gate["threshold_bonus"] or 0.0)
                    scored = [(s, e) for s, e in scored if float(s) >= _floor]
            except Exception:
                pass
        if getattr(self, "rerank_enabled", False) and len(scored) > 1:
            try:
                _n = min(max(1, int(getattr(self, "rerank_top_n", 5) or 5)),
                         len(scored))
                _head = scored[:_n]
                _docs = [str(e.get("text") or "")[:300] for _s, e in _head]
                _rs = await self._rerank_scores("memory_recall", text, _docs)
                if _rs:
                    _head = sorted(
                        [(_rs.get(i, 0.0), e) for i, (_s, e) in enumerate(_head)],
                        key=lambda x: x[0], reverse=True)
                    scored = _head + scored[_n:]
                    self._rerank_stats = {"calls": int(
                        getattr(self, "_rerank_stats", {}).get("calls", 0) or 0) + 1,
                        "last_n": _n, "fallback": 0}
                else:
                    self._rerank_stats = dict(
                        getattr(self, "_rerank_stats", {}) or {}, fallback=int(
                            (getattr(self, "_rerank_stats", {}) or {}).get("fallback", 0) or 0) + 1)
            except Exception:
                pass
        scored.sort(key=lambda x: x[0], reverse=True)
        top = memory_meta.select_top(
            scored, _top_k,
            lambda_=(0.72 if getattr(self, "hybrid_retrieval", True) else 1.0))
        try:
            self._apply_memory_trace(core, [e for _s, e in top])
        except Exception as exc:
            logger.warning("[biocore] memory trace apply failed: %s", exc)
        # L-T02 / C-T01: auditable retrieval-contribution trace (deterministic,
        # bounded to 8 rows, no text beyond the entry id). This is a trace of
        # ranking factors, not a claim of psychological causation, and it is
        # never produced by the LLM.
        try:
            _cos_by_id = {id(_e): _cos for _e, _cos in retrieval_pairs}
            _trace = []
            for _rank, (_score, _entry) in enumerate(top[:8], start=1):
                _eid = str(_entry.get("id") or "").strip()[:20]
                if not _eid:
                    continue
                _parts = self._memory_score_parts(
                    core, _entry, _cos_by_id.get(id(_entry), 0.0),
                    query_text=text,
                    hybrid=bool(getattr(self, "hybrid_retrieval", True)),
                    sensitive_protect=bool(getattr(self, "sensitive_memory_protection", False)))
                _trace.append({
                    "entry_id": _eid,
                    "rank": _rank,
                    "score": round(float(_score), 4),
                    "cosine": _parts["cosine"],
                    "importance": _parts["importance"],
                    "source": str(_entry.get("memory_source") or "direct")[:12],
                    "tier": str(_entry.get("memory_tier") or "warm")[:8],
                    "conflict": bool(_entry.get("conflict")),
                    "components": self._memory_trace_components(_parts),
                })
            self._last_cause_trace = _trace
            self._last_memory_entries = [str(e.get("id") or "")
                                         for _s, e in top if str(e.get("id") or "")][:8]
            doc["last_recall_trace"] = _trace
            self._save_memory(event, doc)
        except Exception as _trace_exc:
            logger.warning("[biocore] recall trace failed: %s", _trace_exc)
        # Nader reconsolidation + Ebbinghaus review: recalling an item makes
        # it labile, strengthens it slightly, and schedules the next review.
        _intervals = [1, 2, 4, 7, 15, 30, 60]
        _ids = []
        for _score, e in top:
            if id(e) in _just_restabilized:
                # The expired labile window was just closed in this pass; do
                # not re-open it on the same recall.
                continue
            try:
                e["recall_count"] = int(e.get("recall_count", 0) or 0) + 1
                e["last_recall"] = now
                e["reconsolidated_ts"] = now
                e["destabilized_until"] = now + float(getattr(self, "reconsolidation_seconds", 600.0))
                e["reconsolidation_state"] = "destabilized"
                _imp = float(e.get("importance", 0.5) or 0.5)
                e["importance"] = max(0.0, min(1.0, _imp + 0.015))
                _rc = int(e.get("review_count", 0) or 0) + 1
                e["review_count"] = _rc
                _st = max(1.0, min(365.0, float(e.get("stability_days", 1.0) or 1.0) * 1.8))
                e["stability_days"] = round(_st, 3)
                _days = max(_intervals[min(_rc - 1, len(_intervals) - 1)], _st)
                e["next_review_ts"] = now + _days * 86400
                # Keep the persisted id stable: dashboard delete/rollback and
                # write_log reference it; only assign one for legacy entries.
                _eid = str(e.get("id") or "").strip()
                if not _eid:
                    _eid = _sha256(str(e.get("text", ""))[:300])[:12]
                    e["id"] = _eid
                e["last_recall_regulation"] = str(getattr(core, "regulation", "none") or "none")
                _ids.append(e)
            except Exception:
                pass
        # ACT-R-style spreading activation: co-recalled items become associated.
        for _i in range(len(_ids)):
            for _j in range(_i + 1, len(_ids)):
                try:
                    _a = _ids[_i].setdefault("assoc", {})
                    _b = _ids[_j].setdefault("assoc", {})
                    _aid = _ids[_i].get("id") or str(_i)
                    _bid = _ids[_j].get("id") or str(_j)
                    _a[_bid] = int(_a.get(_bid, 0)) + 1
                    _b[_aid] = int(_b.get(_aid, 0)) + 1
                except Exception:
                    pass
        # Memory graph links (A-MEM-like): co-recalled memories get weighted
        # directed links; the working set keeps a bounded read set per session.
        _link_lines = []
        _consistency = memory_meta.answer_consistency(top)
        try:
            for _i in range(len(_ids)):
                for _j in range(_i + 1, len(_ids)):
                    _aid = str(_ids[_i].get("id") or "").strip()
                    _bid = str(_ids[_j].get("id") or "").strip()
                    if _aid and _bid:
                        memory_meta.add_link(_ids[_i], _bid, now=now)
                        memory_meta.add_link(_ids[_j], _aid, now=now)
            _ws_current = doc.get("working_set") if isinstance(doc.get("working_set"), list) else _working_set
            doc["working_set"] = memory_meta.update_working_set(
                _ws_current, [str(e.get("id") or "") for _score, e in top],
                capacity=self._working_set_capacity(core),
                priorities={str(_e.get("id") or ""): float(_e.get("importance", 0.5) or 0.5)
                            for _e in entries
                            if isinstance(_e, dict) and str(_e.get("id") or "")})
            _top_ids = {id(e) for _score, e in top}
            _by_id = {str(e.get("id") or ""): e for e in entries
                      if isinstance(e, dict) and str(e.get("id") or "")}
            for _score, e in top:
                _chain_budget = bool(getattr(self, "chain_budget_enabled", False))
                for _lid in memory_meta.linked_ids(
                        e, limit=2, now=now,
                        min_weight=(0.5 if _chain_budget else 1.0)):
                    _nb = _by_id.get(_lid)
                    if _nb is None or id(_nb) in _top_ids:
                        continue
                    if _nb.get("deleted") or _nb.get("summarized"):
                        continue
                    if getattr(self, "safety_enabled", False) and _nb.get("poison_risk"):
                        continue
                    _nb_text = str(_nb.get("text") or "").strip().replace("\n", " ")
                    if not _nb_text:
                        continue
                    if getattr(self, "safety_enabled", False) and _nb.get("sensitive"):
                        _nb_text = memory_meta.mask_sensitive(_nb_text)
                    _link_lines.append("- 关联记忆：%s" % _nb_text[:200])
            try:
                _umo = str(getattr(event, "unified_msg_origin", "") or "")
                _chain_lines = self._chain_event_lines(_umo, text, limit=2)
                if _chain_lines:
                    _link_lines.extend(_chain_lines)
            except Exception:
                pass
            self._save_memory(event, doc)
        except Exception:
            _link_lines = []
            _consistency = 1.0
        # Retrieval-induced forgetting: similar memories that lost this
        # competition become temporarily inhibited (they are not deleted and
        # the inhibition decays over days).
        try:
            memory_meta.apply_retrieval_inhibition(
                retrieval_pairs, [str(e.get("id") or "") for _score, e in top], now)
        except Exception:
            pass
        try:
            self._save_memory(event, doc)
        except Exception:
            pass
        # Opt-in cross-session recall: promote the same sender's memories from
        # other sessions into this session (marked, capped, never leaking to
        # other senders). Default off in config.
        _foreign_lines = []
        try:
            if getattr(self, "cross_session_memory", False):
                _known_texts = {str(e.get("text") or "") for e in entries
                                if isinstance(e, dict) and not e.get("deleted")}
                _foreign = []
                for _skey, _entry in self._cross_session_memory_entries(event):
                    _etext = str(_entry.get("text") or "").strip()
                    if not _etext or _etext in _known_texts:
                        continue
                    if getattr(self, "safety_enabled", False):
                        if _entry.get("sensitive"):
                            continue
                        if str(_entry.get("role") or "") in ("assistant", "summary"):
                            continue
                        if str(_entry.get("scope") or "user") == "session":
                            continue
                    _evec = _entry.get("vector") or []
                    _ecos = self._cosine(vec, _evec) if _evec else 0.0
                    if _ecos < PARTIAL_MATCH_THRESHOLD:
                        continue
                    _escore = self._memory_score(core, _entry, _ecos)
                    if _escore < RETRIEVAL_THRESHOLD:
                        continue
                    _foreign.append((_escore, _skey, _entry))
                _foreign.sort(key=lambda item: item[0], reverse=True)
                for _escore, _skey, _entry in _foreign[:2]:
                    _copy = dict(_entry)
                    _copy["id"] = _sha256(_skey + "|" + str(_entry.get("text"))[:200])[:12]
                    _copy["shared_from_session"] = _skey
                    _copy["ts"] = now
                    _copy["hits"] = 1
                    _copy["last_used"] = now
                    _copy["memory_tier"] = "warm"
                    try:
                        _copy["memory_confidence"] = min(
                            0.55, float(_entry.get("memory_confidence", 0.6) or 0.6))
                    except Exception:
                        _copy["memory_confidence"] = 0.5
                    if not _copy.get("memory_source"):
                        _copy["memory_source"] = "inferred"
                    entries.append(_copy)
                    _known_texts.add(_etext)
                    _foreign_lines.append("- （其他会话）%s：%s" % (
                        str(_copy.get("memory_source") or "inferred"), _etext[:200]))
                    memory_meta.append_write_log(doc, op="ADD",
                                                 entry_id=_copy["id"],
                                                 reason="cross_session", ts=now)
                if _foreign_lines:
                    self._save_memory(event, doc)
        except Exception:
            _foreign_lines = []
        # G1/L12: bounded calibration -> confidence consumer. The recalled
        # top entries get a <=0.05 per-source adjustment (relationship.
        # calibration EWMA matched on memory_source) on a transient copy; the
        # stored entries and ranking are untouched, so hit@k cannot regress.
        _calibration_meta = {}
        _meta_top = top
        try:
            _calibration = self._relationship_of(user_data).get("calibration")
            if isinstance(_calibration, dict) and _calibration.get("sources") and top:
                _adjusted_top = []
                _deltas = []
                for _score, _entry in top:
                    _delta = memory_meta.calibration_confidence_delta(
                        _calibration, _entry.get("memory_source"))
                    if _delta:
                        _copy = dict(_entry)
                        try:
                            _base_conf = float(_copy.get("memory_confidence", 0.5) or 0.5)
                        except Exception:
                            _base_conf = 0.5
                        _copy["memory_confidence"] = round(
                            max(0.0, min(1.0, _base_conf + _delta)), 4)
                        _adjusted_top.append((_score, _copy))
                        _deltas.append(_delta)
                    else:
                        _adjusted_top.append((_score, _entry))
                if _deltas:
                    _meta_top = _adjusted_top
                    _calibration_meta = {
                        "calibration_delta": round(sum(_deltas) / len(_deltas), 4),
                        "calibration_entries": len(_deltas),
                    }
        except Exception:
            _meta_top = top
            _calibration_meta = {}
        self._last_memory_meta = memory_meta.summarize_recall(
            _meta_top, now, consistency=_consistency)
        if _calibration_meta:
            self._last_memory_meta.update(_calibration_meta)
        # Task-15: recall hit/confidence feeds L1 noise (no-op when off).
        if core is not None:
            try:
                _cnt = int(self._last_memory_meta.get("count", 0) or 0)
                _conf = float(self._last_memory_meta.get("confidence", 0.0) or 0.0)
                core.integrate_noise(
                    "memory_recall",
                    attention=0.006 * min(1.0, _cnt / 3.0),
                    valence=0.004 * (_conf - 0.5))
            except Exception:
                pass
        _gate = str(self._last_memory_meta.get("gate") or "none")
        lines = []
        for score, e in top:
            _entry_role = str(e.get("role") or "user")
            role = "你(已总结)" if _entry_role == "summary" else ("你" if _entry_role == "assistant" else "用户")
            if _entry_role not in ("assistant", "summary"):
                who = str(e.get("sender_name") or e.get("sender_id") or "").strip()
                if who:
                    role = who
            snippet = str(e.get("text", "")).strip().replace("\n", " ")
            if getattr(self, "sentence_dedup_enabled", False):
                snippet = self._dedupe_sentences(snippet)
            if getattr(self, "safety_enabled", False) and snippet and e.get("sensitive"):
                snippet = memory_meta.mask_sensitive(snippet)
            if snippet:
                _cap = 220
                if getattr(self, "memory_recall_budget_enabled", False):
                    try:
                        _cap = max(40, min(240, int(
                            getattr(self, "recall_single_chars", 120) or 120)))
                    except Exception:
                        _cap = 120
                lines.append("- %s：%s" % (role, snippet[:_cap]))
        lines.extend(_link_lines)
        lines.extend(_foreign_lines)
        memory_text = "\n".join(lines)
        if getattr(self, "safety_enabled", False) and _gate == "force":
            self._last_memory_meta["withheld"] = True
            self._last_memory_meta["abstain"] = True
            return ""
        _shadow = getattr(self, "_core_shadow_state", None)
        if _shadow and getattr(self, "_core_bridge", None) is not None:
            try:
                _old = list(getattr(self, "_last_memory_entries", []) or [])
                self._core_bridge.record_shadow(_shadow["query"], _old, _shadow["core_ids"], time.time() - _shadow["start"], _shadow["latency_core"])
            except Exception:
                pass
            self._core_shadow_state = None
        return memory_text

    async def _remember(self, event, text: str, role: str = "user", core=None):
        if not self.memory_dedup_embedding or not self._usable_memory_text(text):
            return
        text = str(text).strip()
        if len(text) < 4:
            return
        _bridge = getattr(self, "_core_bridge", None)
        if _bridge is not None and _bridge.enabled and _bridge.mode == "primary":
            try:
                if _bridge.remember(text, role=role, importance=0.5, scope="session:" + str(getattr(event, "unified_msg_origin", "") or "")) is not None:
                    return
            except Exception:
                pass
        vec = await self._embed_text(text)
        if not vec:
            return
        # M1 shadow adapter (default OFF): same event into the module engine.
        _mod_engine = self._memory_module_engine(event)
        if _mod_engine is not None:
            try:
                _mod_engine.remember(MemoryEvent(
                    text=text, role=role,
                    session=str(getattr(event, "unified_msg_origin", "") or ""),
                    ts=time.time(), vector=list(vec), importance=0.5))
            except Exception:
                pass
        doc = self._load_memory(event)
        entries = doc.get("entries")
        if not isinstance(entries, list):
            entries = []
            doc["entries"] = entries
        now = time.time()
        for e in entries:
            if e.get("summarized") or e.get("deleted"):
                continue
            self._restabilize_if_expired(e, now)
            _cos = self._cosine(vec, e.get("vector") or [])
            # Nader reconsolidation: a recalled memory is labile for a window;
            # new related information can update it before restabilization.
            try:
                _window = float(e.get("destabilized_until", 0) or 0)
            except Exception:
                _window = 0.0
            if _window > now and _cos >= 0.80:
                _old_text = str(e.get("text", ""))
                e["text"] = (_old_text + "\n[再巩固] " + text)[:1200]
                try:
                    _ov = [float(x) for x in (e.get("vector") or [])]
                    e["vector"] = [0.8 * a + 0.2 * b for a, b in zip(_ov, vec)]
                except Exception:
                    pass
                e["reconsolidated_ts"] = now
                e["reconsolidation_count"] = int(e.get("reconsolidation_count", 0) or 0) + 1
                e["reconsolidation_state"] = "rewritten"
                e["destabilized_until"] = 0
                self._save_memory(event, doc)
                return
            if _cos >= 0.93:
                e["ts"] = now
                e["last_used"] = now
                e["hits"] = int(e.get("hits", 0)) + 1
                self._save_memory(event, doc)
                return
        _sid, _sname = self._speaker(event)
        if role == "assistant":
            _prov = {"sender_id": "self", "sender_name": "她",
                     "session": str(getattr(event, "unified_msg_origin", "") or ""),
                     "ts": now, "message_refs": []}
        else:
            _prov = self._memory_provenance(event, now)
        entries.append({"text": text[:1200], "role": role, "vector": vec,
                        "ts": now, "hits": 1,
                        "sender_id": _sid if role == "user" else "",
                        "sender_name": _sname if role == "user" else "",
                        "attachments": self._attachments_from_messages(event) if role == "user" else [],
                        "provenance": _prov,
                        "importance": self._memory_importance(core, role),
                        "last_used": now, "next_review_ts": now + 86400, "review_count": 0})
        self._apply_memory_encoding(entries[-1], core, now, text)
        memory_meta.append_write_log(doc, op="ADD", entry_id=str(entries[-1].get("id") or ""),
                                     reason=role, ts=now)
        self._trim_memory(doc, core)
        self._save_memory(event, doc)
        self._schedule_consolidation(event, core)

    # ------------------------------------------------------------------
    # A4 continuity opener ("上次聊到").
    #
    # Deterministic only: no LLM call, no new line, no reply generation. The
    # three data sources are already persisted bio data:
    #   1) the latest consolidated memory summary / last archived session event
    #      (fallback: self_timeline past / autobiography title);
    #   2) unfinished open loops captured *before* the current turn;
    #   3) relationship state (closeness/conflict/repair/phase/absence).
    # It is injected only when the user returns after A4_CONTINUITY_GAP_SECONDS
    # and at least one of the three sources is non-empty.
    # ------------------------------------------------------------------
    def _record_continuity_feedback(self, event, continuity) -> None:
        """Persist A4 continuity usage/feedback into the memory doc (bounded)."""
        if not isinstance(continuity, dict) or not continuity:
            return
        try:
            doc = self._load_memory(event)
            loops = continuity.get("open_loops") if isinstance(continuity.get("open_loops"), list) else []
            doc["last_continuity"] = {
                "ts": round(time.time(), 3),
                "summary": str(continuity.get("summary") or "")[:80],
                "open_loops": [str(x.get("text") or "")[:60] for x in loops[:3] if isinstance(x, dict)],
                "relationship_used": bool(continuity.get("relationship")),
            }
            doc["continuity_feedback_count"] = int(doc.get("continuity_feedback_count", 0) or 0) + 1
            self._save_memory(event, doc)
            try:
                for loop in (getattr(self, "_continuity_last_loops", None) or [])[:3]:
                    if isinstance(loop, dict):
                        loop["last_mentioned_ts"] = time.time()
            except Exception:
                pass
        except Exception as exc:
            logger.warning("[biocore] continuity feedback write failed: %s", exc)

    def _continuity_summary(self, event, core):
        """Return a bounded last-session summary text, or "" when none exists."""
        try:
            doc = self._load_memory(event)
            entries = doc.get("entries") if isinstance(doc, dict) else []
            summaries = [e for e in (entries or [])
                         if isinstance(e, dict)
                         and str(e.get("role") or "") == "summary"
                         and str(e.get("text") or "").strip()]
            if summaries:
                summaries.sort(key=lambda e: float(e.get("ts", 0) or 0), reverse=True)
                text = str(summaries[0].get("text") or "")
                text = text.split("\n[再巩固]")[0]
                text = re.sub(r"\s+", " ", text).strip()
                if text:
                    return text[:80]
        except Exception:
            pass
        try:
            last = self._last_session_event(
                str(getattr(event, "unified_msg_origin", "") or ""))
            if isinstance(last, dict):
                title = str(last.get("title") or "").strip()
                detail = str(last.get("meaning_to_her")
                             or last.get("reflection")
                             or last.get("event") or "").strip()
                text = (title + ("：" + detail if detail else "")).strip()
                text = re.sub(r"\s+", " ", text)
                if text:
                    return text[:80]
        except Exception:
            pass
        try:
            timeline = getattr(core, "self_timeline", {}) if core is not None else {}
            past = timeline.get("past") if isinstance(timeline, dict) else None
            for item in reversed(past or []):
                text = re.sub(r"\s+", " ", str(item or "")).strip()
                if text:
                    return text[:80]
        except Exception:
            pass
        try:
            for item in reversed(list(getattr(core, "autobiography", []) or [])):
                if isinstance(item, dict):
                    text = str(item.get("title") or item.get("meaning") or "").strip()
                    if text:
                        return re.sub(r"\s+", " ", text)[:80]
        except Exception:
            pass
        return ""

    def _continuity_context(self, event, core, user_data, prior_loops=None):
        """Build raw A4 continuity data; returns {} when there is no history."""
        data = user_data if isinstance(user_data, dict) else {}
        absence = data.get("absence") if isinstance(data.get("absence"), dict) else {}
        try:
            gap_days = float(absence.get("gap_days", 0.0) or 0.0)
        except Exception:
            gap_days = 0.0
        if gap_days * 86400.0 < A4_CONTINUITY_GAP_SECONDS:
            return {}
        summary = self._continuity_summary(event, core)
        loops = []
        try:
            source = prior_loops if isinstance(prior_loops, list) else (
                getattr(core, "open_loops", []) if core is not None else [])
            open_loops = []
            for item in (source or []):
                if not isinstance(item, dict):
                    continue
                if str(item.get("status") or "open") != "open":
                    continue
                text = str(item.get("text") or "").strip()
                if not text:
                    continue
                due = str(item.get("due_hint") or "")
                try:
                    seen = float(item.get("last_mentioned_ts")
                                 or item.get("created_ts") or 0.0)
                except Exception:
                    seen = 0.0
                open_loops.append((0 if due in ("soon", "tomorrow") else 1,
                                   -seen, text[:60], due))
            open_loops.sort(key=lambda row: (row[0], row[1]))
            for _rank, _neg_ts, text, due in open_loops[:A4_CONTINUITY_MAX_LOOPS]:
                loops.append({"text": text, "due_hint": due})
        except Exception:
            loops = []
        relationship = data.get("relationship") if isinstance(data.get("relationship"), dict) else {}
        state = relationship.get("state") if isinstance(relationship.get("state"), dict) else {}
        rel = {}
        if state:
            for key in ("closeness", "conflict", "repair"):
                try:
                    rel[key] = round(max(0.0, min(1.0, float(state.get(key, 0.0) or 0.0))), 3)
                except Exception:
                    pass
            repair_state = relationship.get("repair_state")
            if isinstance(repair_state, dict):
                phase = str(repair_state.get("phase") or "stable")
                if phase and phase != "stable":
                    rel["phase"] = phase
            bucket = str(absence.get("bucket") or "")
            if bucket and bucket != "same_day":
                rel["absence"] = bucket
        if not summary and not loops and not rel:
            return {}
        return {"summary": summary, "loops": loops, "relationship": rel}

    @filter.on_llm_request()
    async def on_llm_request(self, event: AstrMessageEvent, req: ProviderRequest):
        if not self.enabled or not self.inject_intent:
            return
        await self._ensure_profile(event)
        core = self._core(event)
        try:
            self._seed_trust_from_user(event, core)
        except Exception:
            pass
        # A4: capture open loops from *before* this turn so the continuity
        # opener cannot echo a loop created by the current message.
        _prior_open_loops = [dict(x) for x in (getattr(core, "open_loops", []) or [])
                             if isinstance(x, dict)]
        text = str(getattr(event, "message_str", "") or "").strip()
        if not text:
            text = str(getattr(req, "prompt", "") or "")
        if not text:
            for item in reversed(getattr(req, "contexts", []) or []):
                if isinstance(item, dict) and item.get("role") == "user":
                    c = item.get("content")
                    if isinstance(c, str):
                        text = c
                        break
        # P1-2: unconditional before any branch that reads it.
        _learn_session = str(getattr(event, "unified_msg_origin", "default") or "default")
        # The core must observe the incoming message; otherwise v/a/stress and
        # fallback labels only change when the model emits a hidden <biocore> tag.
        _query_vec = None
        if text and self.memory_dedup_embedding:
            try:
                _query_vec = await self._embed_text(text)
            except Exception:
                _query_vec = None
        if text:
            core.observe(text, embedding=_query_vec)
            # task-43: deterministic L1 scalars (read-only state; behaviour
            # effects are separately gated and default OFF). No LLM/token cost.
            try:
                core.update_conflict_ema(
                    text, novelty=float(core.appraisal.get("novelty", 0.0) or 0.0))
                core.update_rumination_ema(
                    text, emotion=str((core.labels or {}).get("emotion") or "neutral"),
                    intensity=float(core._intensity()),
                    novelty=float(core.appraisal.get("novelty", 0.0) or 0.0))
                core.apply_identity_threat(text)
            except Exception:
                pass
        _user_data = self._touch_user(event, core)
        # Task-15: readiness is computed by L1 only when autonomy is enabled;
        # remember private sessions and start the P0-1 generator lazily.
        if (getattr(self, "proactive_autonomy", False)
                or getattr(self, "autonomy_loop_enabled", False)):
            try:
                self._update_autonomy_readiness(core, _user_data)
                if self._is_private_event(event):
                    self._register_autonomy_session(event)
                    self._ensure_autonomy_task()
            except Exception:
                pass
        _continuity = {}
        try:
            _continuity = self._continuity_context(event, core, _user_data,
                                                   prior_loops=_prior_open_loops)
        except Exception as exc:
            logger.warning("[biocore] continuity context failed: %s", exc)
            _continuity = {}
        try:
            self._record_continuity_feedback(event, _continuity)
        except Exception:
            pass
        _img = await self._image_context(event)
        _voice = await self._voice_context(event)
        _mem = await self._memory_recall(event, text, core, _img, vec=_query_vec, voice=_voice,
                                         user_data=_user_data)
        try:
            asyncio.create_task(self._maybe_archive_events(event, core))
            asyncio.create_task(self._maybe_archive_strong_event(event, core, text))
        except Exception:
            pass
        try:
            _recent_turns = [str(h.get("text") or "") for h in (core.history or [])[-6:]]
            core.bind_goal_context(memory_text=_mem, self_model=self.self_model,
                                   recent=_recent_turns, text=text)
        except Exception:
            pass
        _events = self._event_context(event)
        # L-T02..L-T12: one bounded strategy/cause/receipt token, plus optional
        # proposal-only LLM refinements (each function default OFF).
        _events_raw = self._event_archive(9)
        # Phase-1 text mode: 1-2 strongest event links (no-op for other modes).
        _event_links = []
        if (str(getattr(self, "bc_prompt_mode", "telemetry")).lower() == "text"
                and _bc_render is not None):
            try:
                _event_links = _bc_render.derive_event_links(
                    _events_raw, now=time.time())
            except Exception:
                _event_links = []
        _strategy_hint = ""
        try:
            _strategy_hint = await self._maybe_llm_hints(
                event, core, _user_data, _events_raw,
                getattr(self, "_last_memory_meta", {}) or {}, text)
        except Exception as exc:
            logger.warning("[biocore] strategy hint failed: %s", exc)
        try:
            await self._maybe_tom_probe(event, core, text, _user_data,
                                        getattr(self, "_last_memory_meta", {}) or {})
        except Exception as exc:
            logger.warning("[biocore] tom probe call failed: %s", exc)
        # task-35: proposal-only outputs get ONE deterministic [BC] consumer;
        # only built when the corresponding function switch is ON => the
        # default (all proposal functions OFF) renders nothing (1.2.99 parity).
        try:
            _proposal = {}
            _rel_data = self._relationship_of(_user_data)
            if self._llm_allowed("relationship_impression"):
                _proposal["impression"] = _rel_data
            if self._llm_allowed("tom_probe"):
                _proposal["tom"] = (_user_data.get("belief_state")
                                    if isinstance(_user_data, dict) else {})
            if self._llm_allowed("diary"):
                _diary = (self.self_model.get("diary")
                          if isinstance(getattr(self, "self_model", None), dict) else None)
                if isinstance(_diary, list) and _diary and isinstance(_diary[-1], dict):
                    _proposal["diary"] = str(_diary[-1].get("date") or "today")
            if self._llm_allowed("relationship_narrative"):
                _narr = (self.self_model.get("relationship_narratives")
                         if isinstance(getattr(self, "self_model", None), dict) else None)
                if isinstance(_narr, list) and _narr and isinstance(_narr[-1], dict):
                    _proposal["narrative"] = str(_narr[-1].get("text") or "")[:40]
            _proposal_hint = interpretation.proposal_hint_block(**_proposal) if _proposal else ""
            if _proposal_hint:
                _strategy_hint = interpretation.combine_strategy_hint(
                    _strategy_hint, _proposal_hint)
        except Exception as exc:
            logger.warning("[biocore] proposal hint failed: %s", exc)
        # task-35: workspace token only when the autonomy loop is enabled.
        _ws_token = ""
        try:
            if getattr(core, "autonomy_loop_enabled", False):
                _loop_state = getattr(core, "autonomy_loop", None)
                if isinstance(_loop_state, dict):
                    _ws_token = str(_loop_state.get("workspace_token") or "")[:16]
        except Exception:
            _ws_token = ""
        # task-35: refusal posture -> brevity (L2 truncation), default OFF.
        _brevity = "normal"
        if getattr(self, "refusal_brevity_enabled", False):
            try:
                _brevity = str(core.refusal_posture(
                    self._relationship_of(_user_data)).get("brevity") or "normal")
            except Exception:
                _brevity = "normal"
            if _brevity != "normal" and _strategy_hint:
                _strategy_hint = _strategy_hint[:60 if _brevity == "short" else 90]
        if getattr(self, "learning_bandit_enabled", False):
            try:
                _pending = (getattr(self, "_learning_pending", {}) or {}).pop(_learn_session, None)
                if isinstance(_pending, dict):
                    _same_emo = str(_pending.get("emotion") or "") == str(
                        (getattr(core, "labels", {}) or {}).get("emotion") or "")
                    _reward = self._learning_reward(
                        _pending.get("reply_len", 0), len(str(text or "")),
                        same_emotion=_same_emo)
                    self._learning_bandit_update(core, _learn_session, _reward)
            except Exception:
                pass
        self._last_user_text = str(text or "")
        if any(getattr(self, k, False) for k in (
                "learning_bandit_enabled", "learning_relationship_enabled",
                "learning_worthiness_enabled")):
            try:
                self._learning_publish(core, _learn_session)
            except Exception:
                pass
        # 1.3.1: consume last round's F3/F2 hints (bounded, inside strategy_hint).
        # P1-1: the F1 "avoid X" hint is separate (only when hint switch is ON)
        # and is NOT merged into strategy_hint.
        for _extra_hint in (getattr(self, "_repeat_hint", ""),
                            getattr(self, "_reflect_hint", "")):
            if _extra_hint:
                _strategy_hint = interpretation.combine_strategy_hint(
                    _strategy_hint, _extra_hint)
        _pending_f1_hint = str(getattr(self, "_reverse_check_hint", "") or "")[:140]
        if not getattr(self, "think_selfcheck_hint_enabled", False):
            _pending_f1_hint = ""
        self._reverse_check_hint = ""
        self._repeat_hint = ""
        self._reflect_hint = ""
        if getattr(self, "expression_chain_enabled", False):
            try:
                _expr_hint = self._expression_hint(core, _learn_session, text)
                if _expr_hint:
                    _strategy_hint = interpretation.combine_strategy_hint(
                        _strategy_hint, _expr_hint)
            except Exception:
                pass
        _kb = ""
        if getattr(self, "kb_enabled", False) and getattr(self, "kb_names", None) and self._usable_memory_text(text):
            try:
                _r = await asyncio.wait_for(
                    self.context.kb_manager.retrieve(query=text, kb_names=self.kb_names, top_m_final=3),
                    timeout=10.0)
                _kb = str((_r or {}).get("context_text") or "").strip()
            except Exception as exc:
                logger.warning("[biocore] kb retrieve failed: %s", exc)
        _base = str(getattr(req, "system_prompt", "") or "")
        # Fixed legend: once per system prompt, never inside the per-turn [BC].
        if (str(getattr(self, "bc_prompt_mode", "telemetry")).lower() == "text"
                and getattr(self, "bc_text_legend_enabled", True)
                and _bc_render is not None):
            try:
                _legend = _bc_render.text_legend()
                if _legend and _legend.split("\n")[0] not in _base:
                    _base = (_base + "\n\n" + _legend).strip()
            except Exception:
                pass
        _sid, _sname = self._speaker(event)
        _speaker = (("%s（%s）" % (_sname or "未知", _sid)) if _sid else (_sname or ""))
        _open_loops_due = sum(
            1 for _loop in (getattr(core, "open_loops", None) or [])
            if isinstance(_loop, dict)
            and str(_loop.get("status") or "open") == "open"
            and str(_loop.get("due_hint") or "") in ("soon", "tomorrow"))
        _render_args = (
            core,
            _mem.replace("[BioCore Memory]", "").strip(),
            _events.replace("[BioCore Events]", "").strip(),
            self.self_model,
            _user_data,
            _img.replace("[BioCore Image]", "").strip(),
            _kb,
            _speaker,
            _voice,
        )
        _render_kwargs = dict(
            memory_meta=getattr(self, "_last_memory_meta", {}) or {},
            open_loops=getattr(core, "open_loops", None),
            open_loops_due=_open_loops_due,
            answer_confidence=(getattr(self, "_last_memory_meta", {}) or {}).get("answer_confidence"),
            strategy_hint=_strategy_hint,
            continuity=_continuity,
            prompt_mode=getattr(self, "bc_prompt_mode", "telemetry"),
            workspace_token=_ws_token,
            brevity=_brevity,
        )
        # Phase-1 modularisation: render lives in biocore_model.render; the
        # interpretation wrapper stays for old imports/eval.
        if _bc_render is not None:
            _compact = _bc_render.render_compact(
                *_render_args, event_links=_event_links, **_render_kwargs).strip()
        else:
            _compact = interpretation.render_compact(
                *_render_args, **_render_kwargs).strip()
        # Deterministic behaviour rules (no LLM) replace per-turn enhancement calls.
        if bool(getattr(self, "prompt_rules_enabled", True)):
            try:
                from .biocore_model import prompt_rules as _prompt_rules
            except Exception:
                _prompt_rules = None
            if _prompt_rules is not None:
                try:
                    _rel = self._relationship_of(_user_data)
                    _affect = {"valence": float(getattr(core, "v", 0.0) or 0.0),
                               "arousal": float(getattr(core, "a", 0.0) or 0.0),
                               "trust": float(_rel.get("trust", 0.5) or 0.5)}
                    _certainty = (getattr(self, "_last_memory_meta", {}) or {}).get("answer_confidence")
                    _rules = _prompt_rules.render_rules(_affect, _rel, _certainty if _certainty is not None else 0.7)
                    if _rules:
                        _compact = (_compact + "\n" + _rules).strip()
                except Exception:
                    pass
        # 1.3.1: deterministic [BC] budget + duplicate-line removal.
        _umo = str(getattr(event, "unified_msg_origin", "default") or "default")
        _budget_chars = (int(getattr(self, "bc_budget_chars", 700) or 700)
                         if getattr(self, "bc_budget_enabled", True) else 0)
        try:
            _hist_n = max(1, int(getattr(self, "bc_dedupe_history", 5) or 5))
        except Exception:
            _hist_n = 5
        _dedupe_on = bool(getattr(self, "bc_dedupe_enabled", True))
        if not getattr(self, "bc_budget_enabled", True):
            # P1-2: budget OFF => full bypass: no apply_bc_budget, no reorder,
            # no dedupe, no extract_hint_line (legacy hint position preserved).
            _block = _compact
            if _pending_f1_hint:
                _block = (_block + "\n[BH] " + _pending_f1_hint).strip()
            _inj = {"budget_enabled": False, "chars": len(_block),
                    "tokens_estimate": interpretation.estimate_bc_tokens(_block),
                    "truncated": [], "dropped_duplicates": [],
                    "essential_chars": 0, "optional_chars": 0,
                    "essential_over_budget": False, "alert": "",
                    "hint_line": _pending_f1_hint,
                    "format_version": interpretation.BC_FORMAT_VERSION}
            _compact = _block
        else:
            _compact, _inj = interpretation.compose_bc_block(
                _compact, budget_chars=_budget_chars,
                history=list(getattr(self, "_bc_history", []) or [])[-_hist_n:],
                dedupe=_dedupe_on,  # task-51: never reorder (memory-layer order wins)
                hints_enabled=bool(getattr(self, "bc_hints_enabled", True)),
                f1_hint=_pending_f1_hint, budget_enabled=True)
        _inj["ts"] = round(time.time(), 3)
        _inj["session"] = _umo
        self._last_injection_trace = _inj
        if getattr(self, "bc_trace_enabled", False):
            try:
                core.injection_trace = dict(_inj, text=_compact[:4000])
                _tn = interpretation.thought_note(
                    {"labels": getattr(core, "labels", {}),
                     "intensity": float(core._intensity())},
                    memory_count=int(((getattr(self, "_last_memory_meta", {}) or {}).get("count", 0) or 0)),
                    hint=_strategy_hint[:40], now=time.time())
                self._thought_note_current = str(_tn.get("text") or "")
                core.thought_note = self._thought_note_current
            except Exception:
                pass
        if getattr(self, "token_budget_enabled", True):
            try:
                _req_text = (str(getattr(req, "prompt", "") or "")
                             + _base + _compact)
                self._record_token_budget(
                    _umo, input_tokens=interpretation.estimate_text_tokens(_req_text),
                    estimated=True, count_call=False)
            except Exception:
                pass
        if _compact:
            self._bc_history = (list(getattr(self, "_bc_history", []) or [])
                                + [_compact])[-20:]
            # Market compliance: never mutate req.system_prompt. Inject the
            # single [BC]/[BH] block as a temporary content part instead.
            self._attach_compact(req, _compact)

    def _attach_compact(self, req, block) -> bool:
        """Market compliance: inject via a TEMP content part only.

        Never touches req.system_prompt. If TextPart is unavailable the
        injection is skipped (warning logged), never falling back to
        system_prompt mutation.
        """
        try:
            from astrbot.core.agent.message import TextPart
        except Exception as exc:
            logger.warning("[biocore] TextPart unavailable; skip [BC] injection: %s", exc)
            return False
        try:
            parts = getattr(req, "extra_user_content_parts", None)
            if parts is None:
                req.extra_user_content_parts = []
                parts = req.extra_user_content_parts
            if not isinstance(parts, list):
                logger.warning("[biocore] extra_user_content_parts unsupported; skip [BC]")
                return False
            part = TextPart(text=str(block))
            try:
                part.mark_as_temp()
            except Exception:
                pass
            parts.append(part)
            return True
        except Exception as exc:
            logger.warning("[biocore] temp content part injection failed: %s", exc)
            return False

    @filter.on_llm_response()
    async def on_llm_response(self, event: AstrMessageEvent, response: LLMResponse):
        if not self.enabled:
            return
        core = self._core(event)
        _reply = str(getattr(response, "completion_text", "") or "")
        _clean, _meta = interpretation.parse_response(_reply)
        if _meta:
            core.apply_affect(_meta)
        # 1.3.4: always write the cleaned text back. Unknown labels drop the
        # affect update, but the visible reply must still be sanitized.
        if _clean != _reply:
            try:
                response.completion_text = _clean
                chain = getattr(response, "result_chain", None)
                if chain is not None and getattr(chain, "chain", None):
                    for comp in chain.chain:
                        if hasattr(comp, "text"):
                            comp.text = _clean
            except Exception:
                pass
        _reply = _clean
        # P1-3: opt-in REAL truncation when the L1 refusal posture is active.
        # Default OFF => the reply/result_chain are untouched (1.2.99 parity).
        if getattr(self, "refusal_brevity_enabled", False):
            try:
                _posture = core.refusal_posture(
                    self._relationship_of(self._user_record(event)))
                if str(_posture.get("mode") or "comply") in ("negotiate", "decline"):
                    _cap = max(40, min(400, int(
                        getattr(self, "refusal_brevity_max_chars", 160) or 160)))
                    _cut = self._truncate_at_sentence(_reply, _cap)
                    if _cut != _reply:
                        _reply = _cut
                        response.completion_text = _reply
                        _chain = getattr(response, "result_chain", None)
                        if _chain is not None and getattr(_chain, "chain", None):
                            for _comp in _chain.chain:
                                if hasattr(_comp, "text"):
                                    _comp.text = _reply
            except Exception:
                pass
        # task-36: opt-in read-only reply-consistency projection (default OFF).
        if getattr(self, "reply_consistency_enabled", False):
            try:
                core.reply_consistency = core.evaluate_reply_consistency(_reply)
            except Exception:
                pass
        # task-36: provider usage counters (only when the provider reports it;
        # otherwise the projection stays "available": false -- never guessed).
        if getattr(self, "token_usage_enabled", False):
            try:
                _usage = self._extract_token_usage(response)
                if _usage:
                    self._record_token_usage(
                        str(getattr(event, "unified_msg_origin", "default") or "default"),
                        _usage)
            except Exception:
                pass
        _umo = str(getattr(event, "unified_msg_origin", "default") or "default")
        # P1-1: F1 split — trace writes state only (default ON, no token cost);
        # hint (default OFF) is the only path that injects next round.
        _f1_trace = bool(getattr(self, "think_selfcheck_trace_enabled", True))
        _f1_hint_on = bool(getattr(self, "think_selfcheck_hint_enabled", False))
        if _f1_trace or _f1_hint_on:
            try:
                _rc = interpretation.reverse_check(
                    _reply,
                    core_state={"intensity": float(core._intensity()),
                                "v": float(getattr(core, "v", 0.0) or 0.0),
                                "stress": float(getattr(core, "stress", 0.0) or 0.0)},
                    previous_replies=list(getattr(self, "_recent_replies", []) or [])[-3:],
                    low_confidence=bool((getattr(self, "_last_memory_meta", {}) or {}).get("abstain")),
                    boundary_pressure=float(getattr(core, "boundary_pressure", 0.0) or 0.0))
                self._last_reverse_check = _rc
                if _f1_trace:
                    core.reverse_check = _rc
                # P2: disabled hint must not leave a stale pending line.
                self._reverse_check_hint = (str(_rc.get("hint") or "")[:140]
                                            if _f1_hint_on else "")
            except Exception:
                self._reverse_check_hint = ""
        else:
            # both switches off mid-flight: drop any pending F1 hint.
            self._reverse_check_hint = ""
        # task-39 F3: repeat guard (default OFF) — mark only, never rewrite.
        if getattr(self, "think_repeat_guard_enabled", False):
            try:
                _rg = interpretation.repeat_guard(
                    _reply, list(getattr(self, "_recent_replies", []) or [])[-3:])
                self._repeat_guard = _rg
                if _rg.get("flag") == "repeat":
                    self._repeat_streak = int(getattr(self, "_repeat_streak", 0) or 0) + 1
                else:
                    self._repeat_streak = 0
                # §6: hint only after 2 consecutive repeats.
                self._repeat_hint = ("不要重复上一句，换一种说法"
                                     if self._repeat_streak >= 2 else "")
            except Exception:
                pass
        # task-39 F2: triggered reflection (default OFF, silent fallback).
        if getattr(self, "think_reflect_enabled", False):
            try:
                await self._maybe_think_reflect(event, core, _reply, text)
            except Exception:
                pass
        # §6: read-only sycophancy / risky-agreement trace (never rewrites text).
        if getattr(self, "sycophancy_check_enabled", True):
            try:
                _syco = interpretation.sycophancy_check(
                    _reply,
                    core_state={"intensity": float(core._intensity())},
                    risky=bool((getattr(core, "labels", {}) or {}).get("emotion")
                               in ("anger", "fear")))
                core.sycophancy_check = _syco
            except Exception:
                pass
                # task-54/55: relationship chain + Big5 effect + bandit pending (default OFF).
        try:
            if (getattr(self, "relationship_chain_enabled", False)
                    or getattr(self, "gottman_enabled", False)
                    or getattr(self, "big5_effect_enabled", False)
                    or getattr(self, "learning_relationship_enabled", False)):
                self._apply_relationship_chain(
                    event, core, str(getattr(self, "_last_user_text", "") or ""), _reply)
            if getattr(self, "learning_bandit_enabled", False):
                self._learning_pending[_umo] = {
                    "reply_len": len(_reply),
                    "emotion": str((getattr(core, "labels", {}) or {}).get("emotion") or ""),
                    "ts": time.time()}
                self._learning_publish(core, _umo)
        except Exception:
            pass
# task-37 token/cost measurement (read-only; real usage else estimate).
        if getattr(self, "token_budget_enabled", True):
            try:
                _usage = self._extract_token_usage(response)
                if _usage:
                    self._record_token_budget(
                        _umo,
                        output_tokens=int(_usage.get("completion_tokens", 0) or 0),
                        cached_tokens=int(_usage.get("cached_tokens", 0) or 0),
                        estimated=False, core=core)
                else:
                    self._record_token_budget(
                        _umo, output_tokens=interpretation.estimate_text_tokens(_reply),
                        estimated=True, core=core)
            except Exception:
                pass
        # task-39/40: path-dependence monitors (default OFF, read-only).
        if getattr(self, "path_monitor_enabled", False):
            try:
                _labels = list(getattr(self, "_label_history", []) or [])
                _labels.append(str((getattr(core, "labels", {}) or {}).get("emotion") or ""))
                self._label_history = _labels[-8:]
                self._path_monitor = interpretation.path_dependence_metrics(
                    list(getattr(self, "_recent_replies", []) or []) + [_reply],
                    self._label_history,
                    [str(_e.get("big_summary") or "")
                     for _e in self._event_archive(2) if isinstance(_e, dict)])
                core.path_monitor = dict(self._path_monitor)
            except Exception:
                pass
        # thought note lives for this turn only: clear before the next round.
        core.thought_note = None
        self._thought_note_current = ""
        if _reply:
            self._recent_replies = ([str(_reply)]
                                    + list(getattr(self, "_recent_replies", []) or []))[:5]
        # Final exit guard (double insurance): sanitize once more before output.
        try:
            _final = _sanitize_output(_reply)
            if _final != _reply:
                _reply = _final
                response.completion_text = _reply
                _chain = getattr(response, "result_chain", None)
                if _chain is not None and getattr(_chain, "chain", None):
                    for _comp in _chain.chain:
                        if hasattr(_comp, "text"):
                            _comp.text = _reply
        except Exception:
            pass
        try:
            core.record_reply(_reply, _meta)
        except Exception:
            pass
        try:
            homeostasis.metabolize_reply(core, _reply)
        except Exception:
            pass
        try:
            if _reply:
                asyncio.create_task(self._remember(event, _reply, "assistant", core))
        except Exception:
            pass
        try:
            STATE_DIR.mkdir(parents=True, exist_ok=True)
            key = str(getattr(event, "unified_msg_origin", "default") or "default")
            safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in key)[:80]
            (STATE_DIR / (safe + ".json")).write_text(
                json.dumps(core.snapshot(), ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            pass
        # L-T01/L-T08/L-T12: background proposal-only tasks. They self-check
        # the per-function switch + cooldown, so default OFF means zero calls.
        try:
            asyncio.create_task(self._maybe_relationship_impression(event, core))
            asyncio.create_task(self._maybe_diary(event, core))
            asyncio.create_task(self._maybe_relationship_narrative(event, core))
        except Exception:
            pass
